<template>
  <div class="app-container">
    <!-- 粒子背景 -->
    <ParticleBackground :current-index="currentIndex" />
    
    <!-- 主界面 -->
    <div v-if="!showDetail && !showSensingDetail && !showDataDetail && !showModelDetail && !showDecisionDetail" class="main-interface">
      <!-- 界面容器 -->
      <div class="interface-container" :style="{ transform: `translateX(-${currentIndex * 100}%)` }">
        <OverviewView v-for="(view, index) in views" 
                      :key="index" 
                      :data="view" 
                      :is-active="index === currentIndex"
                      @reset="handleReset"
                      @demo="handleDemo"
                      @enter-system="handleEnterSystem"
                      @view-detail="handleViewDetail"
        />
      </div>
      
      <!-- 翻页按钮 -->
      <div class="pagination-buttons">
        <button class="page-btn prev-btn" @click="prevPage" :disabled="currentIndex === 0">
          <span class="arrow">‹</span>
        </button>
        <button class="page-btn next-btn" @click="nextPage" :disabled="currentIndex === views.length - 1">
          <span class="arrow">›</span>
        </button>
      </div>
      
      <!-- 导航指示器 -->
      <NavigationIndicators 
        :total="views.length" 
        :current="currentIndex" 
        @switch="switchInterface"
      />
    </div>
    
    <!-- 系统概览详情页面 -->
    <SystemOverviewDetail v-else-if="showDetail" @back="handleBackFromDetail" />
    
    <!-- 传感层详情页面 -->
    <SensingLayerDetail v-else-if="showSensingDetail" @back="handleBackFromSensingDetail" />
    
    <!-- 数据层详情页面 -->
    <DataLayerDetail v-else-if="showDataDetail" @back="handleBackFromDataDetail" />
    
    <!-- 模型层详情页面 -->
    <ModelLayerDetail v-else-if="showModelDetail" @back="handleBackFromModelDetail" />
    
    <!-- 决策执行层详情页面 -->
    <DecisionLayerDetail v-else-if="showDecisionDetail" @back="handleBackFromDecisionDetail" />
  </div>
</template>

<script setup>
import { ref } from 'vue'
import ParticleBackground from './components/ParticleBackground.vue'
import NavigationIndicators from './components/NavigationIndicators.vue'
import OverviewView from './components/OverviewView.vue'
import SystemOverviewDetail from './components/SystemOverviewDetail.vue'
import SensingLayerDetail from './components/SensingLayerDetail.vue'
import DataLayerDetail from './components/DataLayerDetail.vue'
import ModelLayerDetail from './components/ModelLayerDetail.vue'
import DecisionLayerDetail from './components/DecisionLayerDetail.vue'
// 状态管理
const currentIndex = ref(0)
const showDetail = ref(false)
const showSensingDetail = ref(false)
const showDataDetail = ref(false)
const showModelDetail = ref(false)
const showDecisionDetail = ref(false)
let demoInterval = null

const views = [
  {
    title: '系统概览',
    subtitle: 'System Overview',
    description: '西部煤炭开发智能矿压感知预警与保水充填韧性减灾协同调控体系',
    cards: [
      { title: '实时监测节点', value: '42', desc: '覆盖主采工作面与回采通道' },
      { title: '累计监测数据', value: '12.4TB', desc: '稳定运行超过270天' },
      { title: '风险预警准确率', value: '92%', desc: '成功识别高风险区域5处' }
    ],
    buttonText: '进入系统',
    color: '#06B6D4'
  },
  {
    title: '传感层',
    subtitle: 'Sensing Layer',
    description: '自移式多源监测钻孔机器人实现井下复杂环境自主定位与多模态数据采集',
    cards: [
      { title: '监测参数', value: '8+', desc: '应力、声发射、红外热像等多源数据' },
      { title: '钻孔深度', value: '50m', desc: '最大探测深度' },
      { title: '定位精度', value: '±0.1m', desc: '自主导航定位误差' }
    ],
    buttonText: '查看详细数据',
    color: '#00D9C0'
  },
  {
    title: '数据层',
    subtitle: 'Data Layer',
    description: '多模态数据融合构建扰动煤岩"成分-结构-属性"关系模型',
    cards: [
      { title: '数据融合算法', value: '12种', desc: '多源异构数据融合处理' },
      { title: '数据处理速度', value: '100ms', desc: '实时数据响应时间' },
      { title: '数据存储容量', value: '100TB+', desc: '矿山历史数据存储' }
    ],
    buttonText: '数据可视化',
    color: '#3B82F6'
  },
  {
    title: '模型层',
    subtitle: 'Model Layer',
    description: '生成式AI大模型实现矿压分布"区域-块度-链"式响应规律分析',
    cards: [
      { title: 'AI模型数量', value: '5个', desc: '多尺度矿压预测模型' },
      { title: '预测准确率', value: '94.6%', desc: '矿压风险预测精度' },
      { title: '模型迭代周期', value: '14天', desc: '自适应学习更新' }
    ],
    buttonText: '模型参数设置',
    color: '#10B981'
  },
  {
    title: '决策执行层',
    subtitle: 'Decision Layer',
    description: '韧性调控框架下实现冲击地压精准防控与保水充填协同减灾',
    cards: [
      { title: '防控方案', value: '8套', desc: '自适应防治策略库' },
      { title: '响应时间', value: '30分钟', desc: '从预警到执行完成' },
      { title: '减灾效果', value: '85%', desc: '冲击能量削减率' }
    ],
    buttonText: '执行调控方案',
    color: '#F59E0B'
  }
]

function switchInterface(index) {
  currentIndex.value = index
}

function prevPage() {
  if (currentIndex.value > 0) {
    currentIndex.value--
  }
}

function nextPage() {
  if (currentIndex.value < views.length - 1) {
    currentIndex.value++
  }
}

function handleReset() {
  // 停止自动演示
  stopDemo()
  // 跳转到第一页
  currentIndex.value = 0
}

function handleDemo(isRunning) {
  console.log('Demo', isRunning ? 'started' : 'stopped')
  
  if (isRunning) {
    // 开始自动演示
    startDemo()
  } else {
    // 停止自动演示
    stopDemo()
  }
}

function startDemo() {
  // 只有当demoInterval为null时才设置定时器，避免多次设置
  if (!demoInterval) {
    // 设置新的定时器，每隔3秒切换到下一个页面
    demoInterval = setInterval(() => {
      if (currentIndex.value < views.length - 1) {
        currentIndex.value++
      } else {
        currentIndex.value = 0
      }
    }, 3000)
  }
}

function stopDemo() {
  if (demoInterval) {
    clearInterval(demoInterval)
    demoInterval = null
  }
}

function handleEnterSystem() {
  showDetail.value = true
  showSensingDetail.value = false
}

function handleViewDetail(buttonText) {
  console.log('Button clicked:', buttonText)
  if (buttonText === '查看详细数据') {
    showSensingDetail.value = true
    showDetail.value = false
    showDataDetail.value = false
    showModelDetail.value = false
  } else if (buttonText === '进入系统') {
    showDetail.value = true
    showSensingDetail.value = false
    showDataDetail.value = false
    showModelDetail.value = false
  } else if (buttonText === '数据可视化') {
    showDataDetail.value = true
    showDetail.value = false
    showSensingDetail.value = false
    showModelDetail.value = false
  } else if (buttonText === '模型参数设置') {
    showModelDetail.value = true
    showDetail.value = false
    showSensingDetail.value = false
    showDataDetail.value = false
    showDecisionDetail.value = false
  } else if (buttonText === '执行调控方案') {
    showDecisionDetail.value = true
    showDetail.value = false
    showSensingDetail.value = false
    showDataDetail.value = false
    showModelDetail.value = false
  }
  // 可以添加其他页面的处理逻辑
}

function handleBackFromDetail() {
  showDetail.value = false
}

function handleBackFromSensingDetail() {
  showSensingDetail.value = false
}

function handleBackFromDataDetail() {
  showDataDetail.value = false
}

function handleBackFromModelDetail() {
  showModelDetail.value = false
}

function handleBackFromDecisionDetail() {
  showDecisionDetail.value = false
}

// 暴露方法供子组件调用
defineExpose({
  switchInterface
})
</script>

<style scoped>
.app-container {
  position: relative;
  width: 100%;
  height: 100vh;
  overflow: hidden;
}

.interface-container {
  display: flex;
  width: 100%;
  height: 100%;
  transition: transform 0.5s ease-in-out;
}

.pagination-buttons {
  position: absolute;
  top: 50%;
  left: 0;
  right: 0;
  display: flex;
  justify-content: space-between;
  padding: 0 30px;
  transform: translateY(-50%);
  z-index: 10;
}

.page-btn {
  width: 60px;
  height: 60px;
  border-radius: 50%;
  background-color: rgba(255, 255, 255, 0.1);
  border: 2px solid rgba(255, 255, 255, 0.3);
  color: #FFFFFF;
  font-size: 24px;
  cursor: pointer;
  transition: all 0.3s ease;
  display: flex;
  align-items: center;
  justify-content: center;
}

.page-btn:hover:not(:disabled) {
  background-color: rgba(6, 182, 212, 0.2);
  border-color: #06B6D4;
  transform: scale(1.1);
}

.page-btn:disabled {
  opacity: 0.3;
  cursor: not-allowed;
}

.arrow {
  font-weight: bold;
  display: block;
  width: 100%;
  text-align: center;
}

.prev-btn .arrow {
  margin-right: 4px;
}

.next-btn .arrow {
  margin-left: 4px;
}

@media (max-width: 768px) {
  .pagination-buttons {
    padding: 0 15px;
  }
  
  .page-btn {
    width: 45px;
    height: 45px;
    font-size: 20px;
  }
}

@media (prefers-reduced-motion: reduce) {
  .page-btn {
    transition: none !important;
  }
}
</style>
