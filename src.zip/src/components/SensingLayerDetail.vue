<template>
  <div class="sensing-layer-detail">
    <!-- 顶部数据总览区 -->
    <div class="top-overview">
      <div class="overview-header">
        <h1 class="section-title">传感层・多模态数据采集与流入</h1>
        <div class="control-buttons">
          <button class="btn-control" :class="{ active: isAnimationRunning }" @click="toggleAnimation">
            {{ isAnimationRunning ? '暂停流入动画' : '启动流入动画' }}
          </button>
          <div class="data-type-filter">
            <label>筛选数据类型：</label>
            <select v-model="selectedDataType" @change="handleDataTypeFilter">
              <option value="all">全部</option>
              <option value="stress">应力</option>
              <option value="microseismic">微震</option>
              <option value="infrared">红外</option>
            </select>
          </div>
        </div>
      </div>
      <div class="overview-cards">
        <div class="card combined-card">
          <div class="card-row">
            <div class="card-item flow-rate">
              <div class="card-title">实时流入速率</div>
              <div class="card-value" :class="{ updating: isUpdating }">
                {{ flowRate }}MB/s
              </div>
            </div>
            <div class="card-item success-rate">
              <div class="card-title">流入成功率</div>
              <div class="rate-circle small">
                <div class="rate-value">{{ successRate }}%</div>
                <svg class="progress-ring" width="60" height="60">
                  <circle
                    class="progress-ring-bg"
                    cx="30"
                    cy="30"
                    r="25"
                  />
                  <circle
                    class="progress-ring-fill"
                    cx="30"
                    cy="30"
                    r="25"
                    :stroke-dasharray="smallCircumference"
                    :stroke-dashoffset="smallDashOffset"
                  />
                </svg>
              </div>
              <div class="failure-info small" v-if="failureRate > 0">
                <span class="failure-text">钻孔 2# 数据丢包 {{ failureRate }}%</span>
              </div>
            </div>
          </div>
          <div class="card-item total-flow">
            <div class="card-title">累计流入量</div>
            <div class="flow-comparison">
              <div class="today">
                <span class="label">今日</span>
                <span class="value">{{ todayFlow }}GB</span>
              </div>
              <div class="vs">vs</div>
              <div class="yesterday">
                <span class="label">昨日</span>
                <span class="value">{{ yesterdayFlow }}GB</span>
              </div>
            </div>
            <div class="flow-chart">
              <canvas ref="flowChart"></canvas>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- 中央流入链路可视化区 -->
    <div class="central-visualization">
      <div class="flow-path-container">
        <!-- 机器人→钻孔 -->
        <div class="flow-section robot-to-drill">
          <div class="section-label">机器人 → 钻孔</div>
          <div class="flow-path">
            <div class="source-node robot-node">
              <div class="node-icon">🤖</div>
              <div class="node-label">监测机器人</div>
            </div>
            <div class="data-flow" :class="{ active: isAnimationRunning }">
              <div class="flow-particle" v-for="i in 15" :key="i"></div>
            </div>
            <div class="target-node drill-node">
              <div class="node-icon">⛏️</div>
              <div class="node-label">钻孔采集点</div>
              <div class="data-types">
                <span class="data-type stress">应力</span>
                <span class="data-type microseismic">微震</span>
                <span class="data-type infrared">红外</span>
              </div>
            </div>
          </div>
          <div class="flow-description">应力 / 微震 / 红外数据采集 → 边缘预处理</div>
        </div>

        <!-- 预处理→平台 -->
        <div class="flow-section preprocess-to-platform">
          <div class="section-label">预处理 → 平台</div>
          <div class="flow-path">
            <div class="source-node preprocess-node">
              <div class="node-icon">🔄</div>
              <div class="node-label">边缘预处理</div>
            </div>
            <div class="multi-channel-flow">
              <div class="channel stress-channel" :class="{ active: isAnimationRunning, error: stressDataError }">
                <div class="flow-particle" v-for="i in 8" :key="i"></div>
                <div class="channel-label">应力数据</div>
              </div>
              <div class="channel microseismic-channel" :class="{ active: isAnimationRunning, error: microseismicDataError }">
                <div class="flow-particle" v-for="i in 8" :key="i"></div>
                <div class="channel-label">微震数据</div>
              </div>
              <div class="channel infrared-channel" :class="{ active: isAnimationRunning, error: infraredDataError }">
                <div class="flow-particle" v-for="i in 8" :key="i"></div>
                <div class="channel-label">红外数据</div>
              </div>
            </div>
            <div class="target-node platform-node">
              <div class="node-icon">🖥️</div>
              <div class="node-label">数据平台</div>
            </div>
          </div>
          <div class="flow-description">压缩率 30%、传输延迟 32ms</div>
        </div>
      </div>

      <!-- 流入链路拓扑图 -->
      <div class="flow-topology small">
        <div class="topology-header">
          <h3>流入链路拓扑图</h3>
          <button class="btn-refresh" @click="refreshTopology">刷新</button>
        </div>
        <div class="topology-container">
          <div class="topology-layer">
            <div class="layer-label">钻孔层</div>
            <div class="node drill-topology-node" v-for="i in 5" :key="i" :class="getNodeStatusClass(i)">
              <div class="node-circle small"></div>
              <div class="node-label small">钻孔 {{ i }}#</div>
            </div>
          </div>
          <div class="topology-layer">
            <div class="layer-label">边缘节点层</div>
            <div class="node edge-node" v-for="i in 2" :key="i">
              <div class="node-circle small"></div>
              <div class="node-label small">边缘节点 {{ i }}</div>
            </div>
          </div>
          <div class="topology-layer">
            <div class="layer-label">平台服务器层</div>
            <div class="node server-node">
              <div class="node-circle small"></div>
              <div class="node-label small">数据平台</div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- 底部流入明细监控区 -->
    <div class="bottom-monitoring">
      <div class="monitoring-section data-type-details">
        <h3 class="section-title">分类型流入明细</h3>
        <div class="data-type-table">
          <div class="table-header">
            <div class="col data-type">数据类型</div>
            <div class="col flow-rate">实时流入量</div>
            <div class="col delay">延迟</div>
            <div class="col packet-loss">丢包率</div>
          </div>
          <div class="table-row" v-for="type in dataTypes" :key="type.id">
            <div class="col data-type">{{ type.name }}</div>
            <div class="col flow-rate">{{ type.flowRate }}KB/s</div>
            <div class="col delay">{{ type.delay }}ms</div>
            <div class="col packet-loss" :class="{ warning: type.packetLoss > 0 }">
              {{ type.packetLoss }}%
            </div>
          </div>
        </div>
      </div>

      <div class="monitoring-section error-logs">
        <h3 class="section-title">流入异常日志</h3>
        <div class="logs-container">
          <div class="log-item" v-for="log in errorLogs" :key="log.id" :class="log.severity || 'medium'">
            <div class="log-time">{{ log.time }}</div>
            <div class="log-content">
              <div class="log-type">{{ log.dataType }}</div>
              <div class="log-reason">{{ log.reason }}</div>
              <div class="log-status" :class="log.status">{{ log.statusText }}</div>
            </div>
          </div>
        </div>
      </div>

      <div class="monitoring-section config-panel">
        <h3 class="section-title">流入配置</h3>
        <div class="config-form">
          <div class="config-item">
            <label>数据采样频率：</label>
            <input type="number" v-model.number="config.sampleRate" min="1" max="100" @change="updateConfig">
            <span class="unit">Hz</span>
          </div>
          <div class="config-item">
            <label>压缩策略：</label>
            <select v-model="config.compression" @change="updateConfig">
              <option value="none">无压缩</option>
              <option value="light">轻度压缩</option>
              <option value="medium">中度压缩</option>
              <option value="heavy">重度压缩</option>
            </select>
          </div>
          <div class="config-item">
            <label>上传阈值：</label>
            <input type="number" v-model.number="config.uploadThreshold" min="1" max="1000" @change="updateConfig">
            <span class="unit">KB</span>
          </div>
          <button class="btn-apply" @click="applyConfig">应用配置</button>
        </div>
      </div>
    </div>

    <!-- 流入回放功能 -->
    <div class="replay-controls">
      <div class="replay-header" @click="toggleReplayExpanded">
        <h3>流入回放</h3>
        <div class="toggle-icon">{{ isReplayExpanded ? '▼' : '▶' }}</div>
      </div>
      <div v-if="isReplayExpanded" class="replay-content">
        <div class="replay-slider">
          <input type="range" v-model.number="replayProgress" min="0" max="60" step="1">
          <span class="replay-time">{{ replayProgress }}:00</span>
        </div>
        <div class="replay-buttons">
          <button class="btn-replay" @click="startReplay">开始回放</button>
          <button class="btn-pause" @click="pauseReplay">暂停</button>
          <button class="btn-reset" @click="resetReplay">重置</button>
        </div>
      </div>
    </div>

    <!-- 返回按钮 -->
    <button class="btn-back" @click="handleBack">返回</button>
  </div>
</template>

<script setup>
import { ref, computed, onMounted, onUnmounted } from 'vue'

const emit = defineEmits(['back'])

// 状态管理
const isAnimationRunning = ref(true)
const selectedDataType = ref('all')
const isUpdating = ref(false)
const replayProgress = ref(0)
const isReplaying = ref(false)
const isReplayExpanded = ref(true)

// 数据
const flowRate = ref(2.4)
const todayFlow = ref(182)
const yesterdayFlow = ref(178)
const successRate = ref(99.2)
const failureRate = ref(0.8)

// 数据类型详情
const dataTypes = ref([
  { id: 1, name: '应力', flowRate: 850, delay: 15, packetLoss: 0 },
  { id: 2, name: '微震', flowRate: 620, delay: 22, packetLoss: 0.3 },
  { id: 3, name: '红外', flowRate: 480, delay: 18, packetLoss: 0 }
])

// 错误日志
const errorLogs = ref([
  { id: 1, time: '14:32:15', dataType: '微震', reason: '工业环网波动', status: 'resolved', statusText: '已恢复' },
  { id: 2, time: '14:28:45', dataType: '应力', reason: '传感器离线', status: 'resolved', statusText: '已恢复' },
  { id: 3, time: '14:25:30', dataType: '红外', reason: '数据压缩失败', status: 'resolved', statusText: '已恢复' }
])

// 配置
const config = ref({
  sampleRate: 50,
  compression: 'medium',
  uploadThreshold: 100
})

// 错误状态
const stressDataError = ref(false)
const microseismicDataError = ref(false)
const infraredDataError = ref(false)

// 计算属性
const circumference = computed(() => 2 * Math.PI * 35)
const dashOffset = computed(() => {
  const progress = successRate.value / 100
  return circumference.value * (1 - progress)
})

const smallCircumference = computed(() => 2 * Math.PI * 25)
const smallDashOffset = computed(() => {
  const progress = successRate.value / 100
  return smallCircumference.value * (1 - progress)
})

// 方法
function handleBack() {
  emit('back')
}

function toggleAnimation() {
  isAnimationRunning.value = !isAnimationRunning.value
}

function handleDataTypeFilter() {
  console.log('筛选数据类型:', selectedDataType.value)
}

function refreshTopology() {
  console.log('刷新拓扑图')
}

function getNodeStatusClass(nodeId) {
  if (nodeId === 2) return 'error'
  if (nodeId === 4) return 'warning'
  return 'normal'
}

function updateConfig() {
  console.log('更新配置:', config.value)
}

function applyConfig() {
  console.log('应用配置:', config.value)
}

function startReplay() {
  isReplaying.value = true
  console.log('开始回放')
}

function pauseReplay() {
  isReplaying.value = false
  console.log('暂停回放')
}

function resetReplay() {
  isReplaying.value = false
  replayProgress.value = 0
  console.log('重置回放')
}

function toggleReplayExpanded() {
  isReplayExpanded.value = !isReplayExpanded.value
}

// 模拟数据更新
let updateInterval = null

function startDataUpdates() {
  updateInterval = setInterval(() => {
    isUpdating.value = true
    
    // 模拟实时流入速率变化
    flowRate.value = (flowRate.value + (Math.random() - 0.5) * 0.5).toFixed(1)
    
    // 模拟今日流入量增加
    todayFlow.value += Math.random() * 0.1
    todayFlow.value = Math.round(todayFlow.value * 10) / 10
    
    // 随机模拟数据错误
    if (Math.random() > 0.95) {
      const errorType = Math.floor(Math.random() * 3)
      if (errorType === 0) stressDataError.value = true
      if (errorType === 1) microseismicDataError.value = true
      if (errorType === 2) infraredDataError.value = true
      
      // 3秒后恢复
      setTimeout(() => {
        stressDataError.value = false
        microseismicDataError.value = false
        infraredDataError.value = false
      }, 3000)
    }
    
    setTimeout(() => {
      isUpdating.value = false
    }, 500)
  }, 2000) // 核心流入指标刷新频率≤2秒
}

// 组件生命周期
onMounted(() => {
  startDataUpdates()
  console.log('传感层详情页面加载完成')
})

onUnmounted(() => {
  if (updateInterval) {
    clearInterval(updateInterval)
  }
})
</script>

<style scoped>
.sensing-layer-detail {
  width: 100%;
  min-height: 100vh;
  display: flex;
  flex-direction: column;
  background-color: #0F172A;
  color: #FFFFFF;
  position: relative;
  overflow-y: auto;
  overflow-x: hidden;
  scroll-behavior: smooth;
  height: 100vh;
}

/* 顶部数据总览区 */
.top-overview {
  min-height: 120px;
  background-color: rgba(15, 23, 42, 0.95);
  border-bottom: 1px solid rgba(255, 255, 255, 0.1);
  padding: 10px 20px;
  display: flex;
  flex-direction: column;
  justify-content: center;
}

.overview-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 10px;
}

.section-title {
  font-size: 16px;
  font-weight: 600;
  color: #06B6D4;
  margin: 0;
}

.control-buttons {
  display: flex;
  align-items: center;
  gap: 12px;
}

.btn-control {
  padding: 6px 12px;
  border: 1px solid rgba(255, 255, 255, 0.3);
  background-color: rgba(255, 255, 255, 0.1);
  color: #FFFFFF;
  border-radius: 4px;
  cursor: pointer;
  font-size: 12px;
  transition: all 0.3s ease;
}

.btn-control:hover {
  background-color: rgba(6, 182, 212, 0.2);
  border-color: #06B6D4;
}

.btn-control.active {
  background-color: rgba(6, 182, 212, 0.3);
  border-color: #06B6D4;
}

.data-type-filter {
  display: flex;
  align-items: center;
  gap: 8px;
}

.data-type-filter label {
  font-size: 14px;
  color: rgba(255, 255, 255, 0.8);
}

.data-type-filter select {
  padding: 6px 12px;
  background-color: rgba(255, 255, 255, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.3);
  color: #FFFFFF;
  border-radius: 4px;
  font-size: 14px;
}

.overview-cards {
  width: 100%;
}

.card.combined-card {
  width: 100%;
  padding: 12px;
  background-color: rgba(255, 255, 255, 0.05);
  border-radius: 6px;
  border: 1px solid rgba(255, 255, 255, 0.1);
}

.card-row {
  display: flex;
  gap: 12px;
  margin-bottom: 12px;
}

.card-item {
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 6px;
  border-radius: 4px;
  background-color: rgba(255, 255, 255, 0.02);
}

.card-item.flow-rate {
  align-items: flex-start;
}

.card-item.success-rate {
  align-items: center;
}

.card-item.total-flow {
  width: 100%;
  flex-direction: column;
  align-items: center;
}

.card-title {
  font-size: 10px;
  color: rgba(255, 255, 255, 0.8);
  margin-bottom: 4px;
  align-self: flex-start;
}

.card-value {
  font-size: 18px;
  font-weight: 700;
  color: #00D9C0;
  animation: pulse 2s infinite;
}

.card-value.updating {
  animation: none;
}

.flow-comparison {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-bottom: 6px;
}

.today, .yesterday {
  display: flex;
  flex-direction: column;
  align-items: center;
}

.today .value {
  color: #00D9C0;
  font-weight: 700;
}

.yesterday .value {
  color: rgba(255, 255, 255, 0.6);
}

.vs {
  color: rgba(255, 255, 255, 0.4);
  font-size: 14px;
}

.flow-chart {
  height: 20px;
  width: 100%;
  position: relative;
}

.rate-circle {
  position: relative;
  width: 80px;
  height: 80px;
  margin: 0 auto;
}

.rate-circle.small {
  width: 50px;
  height: 50px;
}

.rate-value {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  font-size: 12px;
  font-weight: 700;
  color: #00D9C0;
  text-align: center;
}

.rate-circle.small .rate-value {
  font-size: 10px;
  text-align: center;
}

.progress-ring {
  transform: rotate(-90deg);
}

.progress-ring-bg {
  fill: none;
  stroke: rgba(255, 255, 255, 0.1);
  stroke-width: 4;
}

.progress-ring-fill {
  fill: none;
  stroke: #00D9C0;
  stroke-width: 4;
  stroke-linecap: round;
  transition: stroke-dashoffset 0.5s ease;
}

.failure-info {
  margin-top: 8px;
  text-align: center;
  width: 100%;
}

.failure-info.small {
  margin-top: 4px;
}

.failure-text {
  color: #EF4444;
  font-size: 12px;
}

.failure-info.small .failure-text {
  font-size: 10px;
}

/* 中央流入链路可视化区 */
.central-visualization {
  min-height: 300px;
  display: flex;
  padding: 10px 15px;
  gap: 12px;
  overflow: hidden;
}

.flow-path-container {
  flex: 3;
  display: flex;
  flex-direction: column;
  gap: 20px;
  justify-content: center;
}

.flow-section {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 8px;
}

.section-label {
  font-size: 13px;
  font-weight: 600;
  color: #FFFFFF;
}

.flow-path {
  display: flex;
  align-items: center;
  gap: 15px;
  width: 100%;
}

.source-node, .target-node {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 3px;
  min-width: 70px;
}

.node-icon {
  font-size: 20px;
}

.node-label {
  font-size: 11px;
  font-weight: 500;
  color: #FFFFFF;
}

.data-types {
  display: flex;
  gap: 3px;
  margin-top: 3px;
}

.data-type {
  padding: 1px 3px;
  border-radius: 4px;
  font-size: 7px;
  font-weight: 500;
}

.data-type.stress {
  background-color: rgba(6, 182, 212, 0.2);
  color: #06B6D4;
}

.data-type.microseismic {
  background-color: rgba(59, 130, 246, 0.2);
  color: #3B82F6;
}

.data-type.infrared {
  background-color: rgba(16, 185, 129, 0.2);
  color: #10B981;
}

.data-flow {
  flex: 1;
  height: 2px;
  background-color: rgba(255, 255, 255, 0.1);
  position: relative;
  overflow: hidden;
}

.data-flow.active {
  background-color: rgba(0, 217, 192, 0.3);
}

.flow-particle {
  position: absolute;
  top: 50%;
  left: -6px;
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background-color: #00D9C0;
  transform: translateY(-50%);
  animation: flow 3s linear infinite;
}

.flow-particle:nth-child(2) { animation-delay: 0.3s; }
.flow-particle:nth-child(3) { animation-delay: 0.6s; }
.flow-particle:nth-child(4) { animation-delay: 0.9s; }
.flow-particle:nth-child(5) { animation-delay: 1.2s; }
.flow-particle:nth-child(6) { animation-delay: 1.5s; }
.flow-particle:nth-child(7) { animation-delay: 1.8s; }
.flow-particle:nth-child(8) { animation-delay: 2.1s; }

.multi-channel-flow {
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: 3px;
  height: 45px;
  justify-content: center;
}

.channel {
  height: 2px;
  background-color: rgba(255, 255, 255, 0.1);
  position: relative;
  overflow: hidden;
  border-radius: 1px;
}

.channel.active {
  opacity: 1;
}

.channel.error {
  background-color: rgba(239, 68, 68, 0.3);
  animation: error-blink 1s infinite;
}

.channel.error .flow-particle {
  background-color: #EF4444;
}

.stress-channel.active {
  background-color: rgba(6, 182, 212, 0.3);
}

.stress-channel .flow-particle {
  background-color: #06B6D4;
}

.microseismic-channel.active {
  background-color: rgba(59, 130, 246, 0.3);
}

.microseismic-channel .flow-particle {
  background-color: #3B82F6;
}

.infrared-channel.active {
  background-color: rgba(16, 185, 129, 0.3);
}

.infrared-channel .flow-particle {
  background-color: #10B981;
}

.channel-label {
  position: absolute;
  right: -60px;
  top: 50%;
  transform: translateY(-50%);
  font-size: 10px;
  color: rgba(255, 255, 255, 0.8);
}

.flow-description {
  font-size: 9px;
  color: rgba(255, 255, 255, 0.6);
  text-align: center;
}

/* 流入链路拓扑图 */
.flow-topology {
  flex: 1;
  background-color: rgba(15, 23, 42, 0.7);
  border-radius: 10px;
  border: 1px solid rgba(255, 255, 255, 0.1);
  padding: 14px;
  backdrop-filter: blur(10px);
  overflow-y: auto;
}

.flow-topology.small {
  flex: 0.6;
  padding: 12px;
}

.topology-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 12px;
}

.topology-header h3 {
  font-size: 12px;
  font-weight: 600;
  color: #FFFFFF;
  margin: 0;
}

.btn-refresh {
  padding: 3px 8px;
  background-color: rgba(255, 255, 255, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.3);
  color: #FFFFFF;
  border-radius: 3px;
  font-size: 10px;
  cursor: pointer;
  transition: all 0.3s ease;
}

.btn-refresh:hover {
  background-color: rgba(6, 182, 212, 0.2);
  border-color: #06B6D4;
}

.topology-container {
  display: flex;
  flex-direction: column;
  gap: 20px;
  align-items: center;
}

.topology-layer {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 8px;
}

.layer-label {
  font-size: 11px;
  font-weight: 500;
  color: rgba(255, 255, 255, 0.8);
  margin-bottom: 4px;
}

.topology-layer .node {
  display: flex;
  align-items: center;
  gap: 4px;
  margin-bottom: 8px;
}

.node-circle {
  width: 14px;
  height: 14px;
  border-radius: 50%;
  transition: all 0.3s ease;
}

.node-circle.small {
  width: 10px;
  height: 10px;
}

.node.normal .node-circle {
  background-color: #10B981;
  box-shadow: 0 0 6px rgba(16, 185, 129, 0.5);
}

.node.warning .node-circle {
  background-color: #F59E0B;
  box-shadow: 0 0 6px rgba(245, 158, 11, 0.5);
}

.node.error .node-circle {
  background-color: #EF4444;
  box-shadow: 0 0 6px rgba(239, 68, 68, 0.5);
  animation: error-blink 1s infinite;
}

.node-label {
  font-size: 12px;
  font-weight: 500;
  color: #FFFFFF;
}

.node-label.small {
  font-size: 10px;
}

/* 底部流入明细监控区 */
.bottom-monitoring {
  min-height: 300px;
  background-color: rgba(15, 23, 42, 0.95);
  border-top: 1px solid rgba(255, 255, 255, 0.1);
  padding: 20px 30px;
  display: flex;
  gap: 20px;
  overflow: hidden;
}

.monitoring-section {
  flex: 1;
  background-color: rgba(255, 255, 255, 0.05);
  border-radius: 8px;
  border: 1px solid rgba(255, 255, 255, 0.1);
  padding: 16px;
  overflow-y: auto;
}

.monitoring-section .section-title {
  font-size: 14px;
  font-weight: 600;
  color: #FFFFFF;
  margin: 0 0 16px 0;
}

.data-type-table {
  width: 100%;
}

.table-header {
  display: flex;
  border-bottom: 1px solid rgba(255, 255, 255, 0.1);
  padding-bottom: 8px;
  margin-bottom: 8px;
}

.table-row {
  display: flex;
  padding: 8px 0;
  border-bottom: 1px solid rgba(255, 255, 255, 0.05);
}

.table-row:hover {
  background-color: rgba(255, 255, 255, 0.05);
}

.col {
  flex: 1;
  font-size: 12px;
}

.col.data-type {
  font-weight: 500;
  color: #FFFFFF;
}

.col.flow-rate {
  color: #00D9C0;
}

.col.delay {
  color: rgba(255, 255, 255, 0.8);
}

.col.packet-loss.warning {
  color: #F59E0B;
}

.logs-container {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.log-item {
  padding: 8px;
  background-color: rgba(255, 255, 255, 0.05);
  border-radius: 4px;
  border-left: 4px solid transparent;
}

.log-item.high {
  border-left-color: #EF4444;
  background-color: rgba(239, 68, 68, 0.1);
}

.log-item.medium {
  border-left-color: #F59E0B;
  background-color: rgba(245, 158, 11, 0.1);
}

.log-item.low {
  border-left-color: #10B981;
  background-color: rgba(16, 185, 129, 0.1);
}

.log-time {
  font-size: 10px;
  color: rgba(255, 255, 255, 0.5);
  margin-bottom: 4px;
}

.log-content {
  display: flex;
  flex-direction: column;
  gap: 2px;
}

.log-type {
  font-size: 12px;
  font-weight: 500;
  color: #FFFFFF;
}

.log-reason {
  font-size: 11px;
  color: rgba(255, 255, 255, 0.7);
}

.log-status {
  font-size: 10px;
  padding: 2px 6px;
  border-radius: 10px;
  align-self: flex-start;
}

.log-status.resolved {
  background-color: rgba(16, 185, 129, 0.2);
  color: #10B981;
}

.log-status.pending {
  background-color: rgba(245, 158, 11, 0.2);
  color: #F59E0B;
}

.config-form {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.config-item {
  display: flex;
  align-items: center;
  gap: 8px;
}

.config-item label {
  font-size: 12px;
  color: rgba(255, 255, 255, 0.8);
  min-width: 100px;
}

.config-item input {
  flex: 1;
  padding: 4px 8px;
  background-color: rgba(255, 255, 255, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.3);
  color: #FFFFFF;
  border-radius: 4px;
  font-size: 12px;
}

.config-item select {
  flex: 1;
  padding: 4px 8px;
  background-color: rgba(255, 255, 255, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.3);
  color: #FFFFFF;
  border-radius: 4px;
  font-size: 12px;
}

.unit {
  font-size: 12px;
  color: rgba(255, 255, 255, 0.6);
  min-width: 30px;
}

.btn-apply {
  padding: 6px 12px;
  background-color: rgba(6, 182, 212, 0.2);
  border: 1px solid #06B6D4;
  color: #06B6D4;
  border-radius: 4px;
  font-size: 12px;
  cursor: pointer;
  transition: all 0.3s ease;
  align-self: flex-start;
}

.btn-apply:hover {
  background-color: rgba(6, 182, 212, 0.3);
}

/* 流入回放功能 */
.replay-controls {
  position: fixed;
  bottom: 20px;
  right: 20px;
  background-color: rgba(15, 23, 42, 0.9);
  border: 1px solid rgba(255, 255, 255, 0.1);
  border-radius: 8px;
  padding: 14px;
  backdrop-filter: blur(10px);
  z-index: 10;
  min-width: 200px;
}

.replay-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  cursor: pointer;
  padding-bottom: 8px;
  border-bottom: 1px solid rgba(255, 255, 255, 0.1);
  margin-bottom: 8px;
}

.replay-header h3 {
  font-size: 14px;
  font-weight: 600;
  color: #FFFFFF;
  margin: 0;
}

.toggle-icon {
  font-size: 10px;
  color: rgba(255, 255, 255, 0.7);
  transition: transform 0.3s ease;
}

.replay-content {
  transition: all 0.3s ease;
}

.replay-slider {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-bottom: 12px;
  margin-top: 8px;
}

.replay-slider input {
  flex: 1;
}

.replay-time {
  font-size: 12px;
  color: rgba(255, 255, 255, 0.8);
  min-width: 40px;
}

.replay-buttons {
  display: flex;
  gap: 8px;
}

.btn-replay, .btn-pause, .btn-reset {
  padding: 4px 8px;
  background-color: rgba(255, 255, 255, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.3);
  color: #FFFFFF;
  border-radius: 4px;
  font-size: 12px;
  cursor: pointer;
  transition: all 0.3s ease;
}

.btn-replay:hover, .btn-pause:hover, .btn-reset:hover {
  background-color: rgba(6, 182, 212, 0.2);
  border-color: #06B6D4;
}

/* 返回按钮 */
.btn-back {
  position: absolute;
  top: 20px;
  left: 20px;
  padding: 8px 16px;
  background-color: rgba(255, 255, 255, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.3);
  color: #FFFFFF;
  border-radius: 6px;
  cursor: pointer;
  transition: all 0.3s ease;
  z-index: 10;
}

.btn-back:hover {
  background-color: rgba(6, 182, 212, 0.2);
  border-color: #06B6D4;
}

/* 动画效果 */
@keyframes flow {
  0% {
    left: -10px;
    opacity: 0;
  }
  10% {
    opacity: 1;
  }
  90% {
    opacity: 1;
  }
  100% {
    left: 100%;
    opacity: 0;
  }
}

@keyframes pulse {
  0%, 100% {
    opacity: 1;
  }
  50% {
    opacity: 0.6;
  }
}

@keyframes error-blink {
  0%, 100% {
    opacity: 1;
  }
  50% {
    opacity: 0.5;
  }
}

/* 响应式设计 */
@media (max-width: 1200px) {
  .central-visualization {
    flex-direction: column;
  }
  
  .flow-topology {
    flex: none;
    height: 300px;
  }
  
  .bottom-monitoring {
    flex-direction: column;
    height: auto;
    min-height: 200px;
  }
  
  .replay-controls {
    position: relative;
    bottom: auto;
    right: auto;
    margin-top: 20px;
  }
}

@media (max-width: 768px) {
  .top-overview {
    padding: 0 15px;
  }
  
  .overview-header {
    flex-direction: column;
    align-items: flex-start;
    gap: 10px;
  }
  
  .overview-cards {
    flex-direction: column;
    align-items: stretch;
    gap: 10px;
  }
  
  .central-visualization {
    padding: 15px;
    gap: 15px;
  }
  
  .flow-path {
    flex-direction: column;
    gap: 20px;
  }
  
  .multi-channel-flow {
    width: 100%;
  }
  
  .bottom-monitoring {
    padding: 15px;
    gap: 15px;
  }
  
  .replay-controls {
    padding: 12px;
  }
}

/* 滚动条样式 */
::-webkit-scrollbar {
  width: 6px;
}

::-webkit-scrollbar-track {
  background: rgba(255, 255, 255, 0.05);
  border-radius: 3px;
}

::-webkit-scrollbar-thumb {
  background: rgba(255, 255, 255, 0.2);
  border-radius: 3px;
}

::-webkit-scrollbar-thumb:hover {
  background: rgba(255, 255, 255, 0.3);
}
</style>