<template>
  <div class="data-layer-detail">
    <!-- 顶部流程总控区 -->
    <div class="top-control-panel">
      <div class="panel-header">
        <h1 class="section-title">数据层・多维度数据处理与可视化</h1>
        <div class="control-buttons">
          <button class="btn-control" :class="{ active: isProcessing }" @click="toggleProcessing">
            {{ isProcessing ? '暂停处理' : '开始处理' }}
          </button>
          <button class="btn-control" @click="resetProcess">重置流程</button>
        </div>
      </div>
      <div class="stats-cards">
        <div class="stat-card">
          <div class="stat-title">待处理数据量</div>
          <div class="stat-value">{{ pendingDataAmount }}GB</div>
        </div>
        <div class="stat-card">
          <div class="stat-title">融合完成率</div>
          <div class="stat-value">{{ fusionCompletionRate }}%</div>
          <div class="progress-bar">
            <div class="progress-fill" :style="{ width: fusionCompletionRate + '%' }"></div>
          </div>
        </div>
        <div class="stat-card">
          <div class="stat-title">处理速度</div>
          <div class="stat-value">{{ processingSpeed }}MB/s</div>
        </div>
        <div class="stat-card">
          <div class="stat-title">异常数量</div>
          <div class="stat-value" :class="{ warning: errorCount > 0 }">{{ errorCount }}</div>
        </div>
      </div>
    </div>

    <!-- 中央多维度可视化区 -->
    <div class="central-visualization">
      <!-- 数据处理流程图 -->
      <div class="flow-diagram">
        <h3 class="diagram-title">数据处理流程</h3>
        <div class="flow-steps">
          <div class="flow-step" :class="{ active: currentStep >= 1, completed: currentStep > 1 }">
            <div class="step-icon">🧹</div>
            <div class="step-label">数据清洗</div>
          </div>
          <div class="flow-arrow">→</div>
          <div class="flow-step" :class="{ active: currentStep >= 2, completed: currentStep > 2 }">
            <div class="step-icon">📏</div>
            <div class="step-label">数据对齐</div>
          </div>
          <div class="flow-arrow">→</div>
          <div class="flow-step" :class="{ active: currentStep >= 3, completed: currentStep > 3 }">
            <div class="step-icon">🔍</div>
            <div class="step-label">特征提取</div>
          </div>
          <div class="flow-arrow">→</div>
          <div class="flow-step" :class="{ active: currentStep >= 4, completed: currentStep > 4 }">
            <div class="step-icon">🔄</div>
            <div class="step-label">数据融合</div>
          </div>
        </div>
      </div>

      <!-- 数据清洗对比 -->
      <div class="data-comparison">
        <div class="comparison-header">
          <h3 class="chart-title">清洗前后数据对比</h3>
          <button class="toggle-btn" @click="toggleChartType">
            {{ currentChartType === 'stress' ? '切换到微震' : '切换到应力' }}
          </button>
        </div>
        <div class="comparison-content">
          <div class="comparison-charts">
            <div class="chart-container">
              <div class="chart-header">清洗前</div>
              <div class="bar-chart">
                <div class="chart-data" v-if="currentChartType === 'stress'">
                  <div class="chart-label">应力 (MPa)</div>
                  <div class="bar-container">
                    <div class="bar" style="height: 15.2%; left: 0%"><div class="bar-tooltip">应力: 15.2</div></div>
                    <div class="bar" style="height: 18.7%; left: 5%"><div class="bar-tooltip">应力: 18.7</div></div>
                    <div class="bar" style="height: 32.1%; left: 10%"><div class="bar-tooltip">应力: 32.1</div></div>
                    <div class="bar" style="height: 16.5%; left: 15%"><div class="bar-tooltip">应力: 16.5</div></div>
                    <div class="bar" style="height: 19.2%; left: 20%"><div class="bar-tooltip">应力: 19.2</div></div>
                    <div class="bar" style="height: 0%; left: 25%"><div class="bar-tooltip">应力: 缺失</div></div>
                    <div class="bar" style="height: 14.8%; left: 30%"><div class="bar-tooltip">应力: 14.8</div></div>
                    <div class="bar" style="height: 21.3%; left: 35%"><div class="bar-tooltip">应力: 21.3</div></div>
                    <div class="bar" style="height: 15.5%; left: 40%"><div class="bar-tooltip">应力: 15.5</div></div>
                    <div class="bar" style="height: 18.9%; left: 45%"><div class="bar-tooltip">应力: 18.9</div></div>
                    <div class="bar" style="height: 17.6%; left: 50%"><div class="bar-tooltip">应力: 17.6</div></div>
                    <div class="bar" style="height: 16.7%; left: 55%"><div class="bar-tooltip">应力: 16.7</div></div>
                    <div class="bar" style="height: 19.5%; left: 60%"><div class="bar-tooltip">应力: 19.5</div></div>
                    <div class="bar" style="height: 20.1%; left: 65%"><div class="bar-tooltip">应力: 20.1</div></div>
                    <div class="bar" style="height: 14.9%; left: 70%"><div class="bar-tooltip">应力: 14.9</div></div>
                    <div class="bar" style="height: 21.5%; left: 75%"><div class="bar-tooltip">应力: 21.5</div></div>
                    <div class="bar" style="height: 0%; left: 80%"><div class="bar-tooltip">应力: 0.0</div></div>
                    <div class="bar" style="height: 19.0%; left: 85%"><div class="bar-tooltip">应力: 19.0</div></div>
                    <div class="bar" style="height: 17.8%; left: 90%"><div class="bar-tooltip">应力: 17.8</div></div>
                    <div class="bar" style="height: 16.8%; left: 95%"><div class="bar-tooltip">应力: 16.8</div></div>
                  </div>
                  <div class="chart-axis">
                    <div class="x-axis">时间序列</div>
                    <div class="y-axis">应力 (MPa)</div>
                  </div>
                </div>
                <div class="chart-data" v-else>
                  <div class="chart-label">微震 (counts)</div>
                  <div class="bar-container">
                    <div class="bar" style="height: 12.5%; left: 0%"><div class="bar-tooltip">微震: 125.6</div></div>
                    <div class="bar" style="height: 9.8%; left: 5%"><div class="bar-tooltip">微震: 98.3</div></div>
                    <div class="bar" style="height: 15.6%; left: 10%"><div class="bar-tooltip">微震: 156.8</div></div>
                    <div class="bar" style="height: 58.9%; left: 15%"><div class="bar-tooltip">微震: 5890.2</div></div>
                    <div class="bar" style="height: 8.9%; left: 20%"><div class="bar-tooltip">微震: 89.5</div></div>
                    <div class="bar" style="height: 10.2%; left: 25%"><div class="bar-tooltip">微震: 102.4</div></div>
                    <div class="bar" style="height: 7.8%; left: 30%"><div class="bar-tooltip">微震: 78.6</div></div>
                    <div class="bar" style="height: 13.2%; left: 35%"><div class="bar-tooltip">微震: 132.7</div></div>
                    <div class="bar" style="height: 12.1%; left: 40%"><div class="bar-tooltip">微震: 121.8</div></div>
                    <div class="bar" style="height: 10.5%; left: 45%"><div class="bar-tooltip">微震: 105.2</div></div>
                    <div class="bar" style="height: 14.5%; left: 50%"><div class="bar-tooltip">微震: 145.9</div></div>
                    <div class="bar" style="height: 9.2%; left: 55%"><div class="bar-tooltip">微震: 92.4</div></div>
                    <div class="bar" style="height: 8.7%; left: 60%"><div class="bar-tooltip">微震: 87.3</div></div>
                    <div class="bar" style="height: 10.8%; left: 65%"><div class="bar-tooltip">微震: 108.6</div></div>
                    <div class="bar" style="height: 7.9%; left: 70%"><div class="bar-tooltip">微震: 79.2</div></div>
                    <div class="bar" style="height: 13.5%; left: 75%"><div class="bar-tooltip">微震: 135.1</div></div>
                    <div class="bar" style="height: 11.8%; left: 80%"><div class="bar-tooltip">微震: 118.5</div></div>
                    <div class="bar" style="height: 10.7%; left: 85%"><div class="bar-tooltip">微震: 107.5</div></div>
                    <div class="bar" style="height: 10.0%; left: 90%"><div class="bar-tooltip">微震: 100.0</div></div>
                    <div class="bar" style="height: 9.5%; left: 95%"><div class="bar-tooltip">微震: 95.7</div></div>
                  </div>
                  <div class="chart-axis">
                    <div class="x-axis">时间序列</div>
                    <div class="y-axis">微震 (counts)</div>
                  </div>
                </div>
              </div>
            </div>
            <div class="chart-container" v-if="fusionCompletionRate >= 45">
              <div class="chart-header">清洗后</div>
              <div class="bar-chart">
                <div class="chart-data" v-if="currentChartType === 'stress'">
                  <div class="chart-label">应力 (MPa)</div>
                  <div class="bar-container">
                    <div class="bar" style="height: 15.2%; left: 0%"><div class="bar-tooltip">应力: 15.2</div></div>
                    <div class="bar" style="height: 18.7%; left: 5%"><div class="bar-tooltip">应力: 18.7</div></div>
                    <div class="bar" style="height: 32.1%; left: 10%"><div class="bar-tooltip">应力: 32.1</div></div>
                    <div class="bar" style="height: 16.5%; left: 15%"><div class="bar-tooltip">应力: 16.5</div></div>
                    <div class="bar" style="height: 19.2%; left: 20%"><div class="bar-tooltip">应力: 19.2</div></div>
                    <div class="bar" style="height: 18.5%; left: 25%"><div class="bar-tooltip">应力: 18.5</div></div>
                    <div class="bar" style="height: 14.8%; left: 30%"><div class="bar-tooltip">应力: 14.8</div></div>
                    <div class="bar" style="height: 21.3%; left: 35%"><div class="bar-tooltip">应力: 21.3</div></div>
                    <div class="bar" style="height: 15.5%; left: 40%"><div class="bar-tooltip">应力: 15.5</div></div>
                    <div class="bar" style="height: 18.9%; left: 45%"><div class="bar-tooltip">应力: 18.9</div></div>
                    <div class="bar" style="height: 17.6%; left: 50%"><div class="bar-tooltip">应力: 17.6</div></div>
                    <div class="bar" style="height: 16.7%; left: 55%"><div class="bar-tooltip">应力: 16.7</div></div>
                    <div class="bar" style="height: 19.5%; left: 60%"><div class="bar-tooltip">应力: 19.5</div></div>
                    <div class="bar" style="height: 20.1%; left: 65%"><div class="bar-tooltip">应力: 20.1</div></div>
                    <div class="bar" style="height: 14.9%; left: 70%"><div class="bar-tooltip">应力: 14.9</div></div>
                    <div class="bar" style="height: 21.5%; left: 75%"><div class="bar-tooltip">应力: 21.5</div></div>
                    <div class="bar" style="height: 15.0%; left: 80%"><div class="bar-tooltip">应力: 15.0</div></div>
                    <div class="bar" style="height: 19.0%; left: 85%"><div class="bar-tooltip">应力: 19.0</div></div>
                    <div class="bar" style="height: 17.8%; left: 90%"><div class="bar-tooltip">应力: 17.8</div></div>
                    <div class="bar" style="height: 16.8%; left: 95%"><div class="bar-tooltip">应力: 16.8</div></div>
                  </div>
                  <div class="chart-axis">
                    <div class="x-axis">时间序列</div>
                    <div class="y-axis">应力 (MPa)</div>
                  </div>
                </div>
                <div class="chart-data" v-else>
                  <div class="chart-label">微震 (counts)</div>
                  <div class="bar-container">
                    <div class="bar" style="height: 12.5%; left: 0%"><div class="bar-tooltip">微震: 125.6</div></div>
                    <div class="bar" style="height: 9.8%; left: 5%"><div class="bar-tooltip">微震: 98.3</div></div>
                    <div class="bar" style="height: 15.6%; left: 10%"><div class="bar-tooltip">微震: 156.8</div></div>
                    <div class="bar" style="height: 12.0%; left: 15%"><div class="bar-tooltip">微震: 120.0</div></div>
                    <div class="bar" style="height: 8.9%; left: 20%"><div class="bar-tooltip">微震: 89.5</div></div>
                    <div class="bar" style="height: 10.2%; left: 25%"><div class="bar-tooltip">微震: 102.4</div></div>
                    <div class="bar" style="height: 7.8%; left: 30%"><div class="bar-tooltip">微震: 78.6</div></div>
                    <div class="bar" style="height: 13.2%; left: 35%"><div class="bar-tooltip">微震: 132.7</div></div>
                    <div class="bar" style="height: 12.1%; left: 40%"><div class="bar-tooltip">微震: 121.8</div></div>
                    <div class="bar" style="height: 10.5%; left: 45%"><div class="bar-tooltip">微震: 105.2</div></div>
                    <div class="bar" style="height: 14.5%; left: 50%"><div class="bar-tooltip">微震: 145.9</div></div>
                    <div class="bar" style="height: 9.2%; left: 55%"><div class="bar-tooltip">微震: 92.4</div></div>
                    <div class="bar" style="height: 8.7%; left: 60%"><div class="bar-tooltip">微震: 87.3</div></div>
                    <div class="bar" style="height: 10.8%; left: 65%"><div class="bar-tooltip">微震: 108.6</div></div>
                    <div class="bar" style="height: 7.9%; left: 70%"><div class="bar-tooltip">微震: 79.2</div></div>
                    <div class="bar" style="height: 13.5%; left: 75%"><div class="bar-tooltip">微震: 135.1</div></div>
                    <div class="bar" style="height: 11.8%; left: 80%"><div class="bar-tooltip">微震: 118.5</div></div>
                    <div class="bar" style="height: 10.7%; left: 85%"><div class="bar-tooltip">微震: 107.5</div></div>
                    <div class="bar" style="height: 10.0%; left: 90%"><div class="bar-tooltip">微震: 100.0</div></div>
                    <div class="bar" style="height: 9.5%; left: 95%"><div class="bar-tooltip">微震: 95.7</div></div>
                  </div>
                  <div class="chart-axis">
                    <div class="x-axis">时间序列</div>
                    <div class="y-axis">微震 (counts)</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <!-- 数据表格 -->
          <div class="data-table">
            <h4 class="table-title" v-if="fusionCompletionRate < 100">清洗前原始数据</h4>
            <h4 class="table-title" v-else>清洗后数据</h4>
            <div class="table-container">
              <table v-if="fusionCompletionRate < 100">
                <thead>
                  <tr>
                    <th>时间</th>
                    <th>钻孔编号</th>
                    <th>应力</th>
                    <th>微震</th>
                    <th>位移</th>
                    <th>温度</th>
                    <th>湿度</th>
                    <th>CH4</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>2026-03-23 10:00:00</td>
                    <td>ZK21205-01</td>
                    <td>15.2</td>
                    <td>125.6</td>
                    <td>1.2</td>
                    <td>28.5</td>
                    <td>88.2</td>
                    <td>0.32</td>
                  </tr>
                  <tr>
                    <td>2026-03-23 10:00:10</td>
                    <td>ZK21205-02</td>
                    <td>18.7</td>
                    <td>98.3</td>
                    <td>9.5</td>
                    <td>29.1</td>
                    <td>89.5</td>
                    <td>0.28</td>
                  </tr>
                  <tr>
                    <td>2026-03-23 10:00:20</td>
                    <td>ZK21205-03</td>
                    <td>32.1</td>
                    <td>156.8</td>
                    <td>2.1</td>
                    <td>27.8</td>
                    <td>90.1</td>
                    <td>0.45</td>
                  </tr>
                  <tr>
                    <td>2026-03-23 10:00:30</td>
                    <td>ZK21205-04</td>
                    <td>16.5</td>
                    <td>5890.2</td>
                    <td>1.8</td>
                    <td>30.2</td>
                    <td>87.6</td>
                    <td>0.36</td>
                  </tr>
                  <tr>
                    <td>2026-03-23 10:00:40</td>
                    <td>ZK21205-05</td>
                    <td>19.2</td>
                    <td>89.5</td>
                    <td>2.5</td>
                    <td>18.3</td>
                    <td>91.3</td>
                    <td>0.51</td>
                  </tr>
                  <tr>
                    <td>2026-03-23 10:00:50</td>
                    <td>ZK21205-06</td>
                    <td>缺失</td>
                    <td>102.4</td>
                    <td>1.9</td>
                    <td>28.9</td>
                    <td>86.8</td>
                    <td>0.29</td>
                  </tr>
                  <tr>
                    <td>2026-03-23 10:01:00</td>
                    <td>ZK21205-07</td>
                    <td>14.8</td>
                    <td>78.6</td>
                    <td>1.5</td>
                    <td>29.5</td>
                    <td>98.7</td>
                    <td>0.38</td>
                  </tr>
                  <tr>
                    <td>2026-03-23 10:01:10</td>
                    <td>ZK21205-08</td>
                    <td>21.3</td>
                    <td>132.7</td>
                    <td>2.3</td>
                    <td>30.0</td>
                    <td>89.2</td>
                    <td>0.95</td>
                  </tr>
                  <tr>
                    <td>2026-03-23 10:01:20</td>
                    <td>ZK21205-01</td>
                    <td>15.5</td>
                    <td>121.8</td>
                    <td>1.3</td>
                    <td>28.7</td>
                    <td>88.5</td>
                    <td>0.33</td>
                  </tr>
                  <tr>
                    <td>2026-03-23 10:01:30</td>
                    <td>ZK21205-02</td>
                    <td>18.9</td>
                    <td>105.2</td>
                    <td>1.7</td>
                    <td>29.3</td>
                    <td>89.8</td>
                    <td>0.27</td>
                  </tr>
                  <tr>
                    <td>2026-03-23 10:01:40</td>
                    <td>ZK21205-03</td>
                    <td>17.6</td>
                    <td>145.9</td>
                    <td>2.2</td>
                    <td>28.0</td>
                    <td>90.3</td>
                    <td>0.46</td>
                  </tr>
                  <tr>
                    <td>2026-03-23 10:01:50</td>
                    <td>ZK21205-04</td>
                    <td>16.7</td>
                    <td>92.4</td>
                    <td>1.9</td>
                    <td>30.1</td>
                    <td>87.8</td>
                    <td>0.35</td>
                  </tr>
                  <tr>
                    <td>2026-03-23 10:02:00</td>
                    <td>ZK21205-05</td>
                    <td>19.5</td>
                    <td>87.3</td>
                    <td>2.6</td>
                    <td>29.0</td>
                    <td>91.5</td>
                    <td>0.52</td>
                  </tr>
                  <tr>
                    <td>2026-03-23 10:02:10</td>
                    <td>ZK21205-06</td>
                    <td>20.1</td>
                    <td>108.6</td>
                    <td>2.0</td>
                    <td>29.1</td>
                    <td>87.0</td>
                    <td>0.30</td>
                  </tr>
                  <tr>
                    <td>2026-03-23 10:02:20</td>
                    <td>ZK21205-07</td>
                    <td>14.9</td>
                    <td>79.2</td>
                    <td>-0.5</td>
                    <td>29.6</td>
                    <td>88.0</td>
                    <td>0.39</td>
                  </tr>
                  <tr>
                    <td>2026-03-23 10:02:30</td>
                    <td>ZK21205-08</td>
                    <td>21.5</td>
                    <td>135.1</td>
                    <td>2.4</td>
                    <td>30.2</td>
                    <td>89.4</td>
                    <td>0.41</td>
                  </tr>
                  <tr>
                    <td>2026-03-23 10:02:40</td>
                    <td>ZK21205-01</td>
                    <td>0.0</td>
                    <td>118.5</td>
                    <td>1.4</td>
                    <td>28.8</td>
                    <td>88.7</td>
                    <td>0.34</td>
                  </tr>
                  <tr>
                    <td>2026-03-23 10:02:50</td>
                    <td>ZK21205-02</td>
                    <td>19.0</td>
                    <td>107.5</td>
                    <td>1.8</td>
                    <td>29.4</td>
                    <td>90.0</td>
                    <td>0.26</td>
                  </tr>
                  <tr>
                    <td>2026-03-23 10:03:00</td>
                    <td>ZK21205-03</td>
                    <td>17.8</td>
                    <td>0.0</td>
                    <td>2.3</td>
                    <td>28.1</td>
                    <td>90.5</td>
                    <td>0.47</td>
                  </tr>
                  <tr>
                    <td>2026-03-23 10:03:10</td>
                    <td>ZK21205-04</td>
                    <td>16.8</td>
                    <td>95.7</td>
                    <td>2.0</td>
                    <td>30.3</td>
                    <td>88.0</td>
                    <td>0.36</td>
                  </tr>
                </tbody>
              </table>
              <table v-else>
                <thead>
                  <tr>
                    <th>时间</th>
                    <th>钻孔编号</th>
                    <th>应力</th>
                    <th>微震</th>
                    <th>位移</th>
                    <th>温度</th>
                    <th>湿度</th>
                    <th>CH4</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>2026-03-23 10:00:00</td>
                    <td>ZK21205-01</td>
                    <td>15.2</td>
                    <td>125.6</td>
                    <td>1.2</td>
                    <td>28.5</td>
                    <td>88.2</td>
                    <td>0.32</td>
                  </tr>
                  <tr>
                    <td>2026-03-23 10:00:10</td>
                    <td>ZK21205-02</td>
                    <td>18.7</td>
                    <td>98.3</td>
                    <td>9.5</td>
                    <td>29.1</td>
                    <td>89.5</td>
                    <td>0.28</td>
                  </tr>
                  <tr>
                    <td>2026-03-23 10:00:20</td>
                    <td>ZK21205-03</td>
                    <td>32.1</td>
                    <td>156.8</td>
                    <td>2.1</td>
                    <td>27.8</td>
                    <td>90.1</td>
                    <td>0.45</td>
                  </tr>
                  <tr>
                    <td>2026-03-23 10:00:30</td>
                    <td>ZK21205-04</td>
                    <td>16.5</td>
                    <td>120.0</td>
                    <td>1.8</td>
                    <td>30.2</td>
                    <td>87.6</td>
                    <td>0.36</td>
                  </tr>
                  <tr>
                    <td>2026-03-23 10:00:40</td>
                    <td>ZK21205-05</td>
                    <td>19.2</td>
                    <td>89.5</td>
                    <td>2.5</td>
                    <td>29.0</td>
                    <td>91.3</td>
                    <td>0.51</td>
                  </tr>
                  <tr>
                    <td>2026-03-23 10:00:50</td>
                    <td>ZK21205-06</td>
                    <td>18.5</td>
                    <td>102.4</td>
                    <td>1.9</td>
                    <td>28.9</td>
                    <td>86.8</td>
                    <td>0.29</td>
                  </tr>
                  <tr>
                    <td>2026-03-23 10:01:00</td>
                    <td>ZK21205-07</td>
                    <td>14.8</td>
                    <td>78.6</td>
                    <td>1.5</td>
                    <td>29.5</td>
                    <td>88.7</td>
                    <td>0.38</td>
                  </tr>
                  <tr>
                    <td>2026-03-23 10:01:10</td>
                    <td>ZK21205-08</td>
                    <td>21.3</td>
                    <td>132.7</td>
                    <td>2.3</td>
                    <td>30.0</td>
                    <td>89.2</td>
                    <td>0.41</td>
                  </tr>
                  <tr>
                    <td>2026-03-23 10:01:20</td>
                    <td>ZK21205-01</td>
                    <td>15.5</td>
                    <td>121.8</td>
                    <td>1.3</td>
                    <td>28.7</td>
                    <td>88.5</td>
                    <td>0.33</td>
                  </tr>
                  <tr>
                    <td>2026-03-23 10:01:30</td>
                    <td>ZK21205-02</td>
                    <td>18.9</td>
                    <td>105.2</td>
                    <td>1.7</td>
                    <td>29.3</td>
                    <td>89.8</td>
                    <td>0.27</td>
                  </tr>
                  <tr>
                    <td>2026-03-23 10:01:40</td>
                    <td>ZK21205-03</td>
                    <td>17.6</td>
                    <td>145.9</td>
                    <td>2.2</td>
                    <td>28.0</td>
                    <td>90.3</td>
                    <td>0.46</td>
                  </tr>
                  <tr>
                    <td>2026-03-23 10:01:50</td>
                    <td>ZK21205-04</td>
                    <td>16.7</td>
                    <td>92.4</td>
                    <td>1.9</td>
                    <td>30.1</td>
                    <td>87.8</td>
                    <td>0.35</td>
                  </tr>
                  <tr>
                    <td>2026-03-23 10:02:00</td>
                    <td>ZK21205-05</td>
                    <td>19.5</td>
                    <td>87.3</td>
                    <td>2.6</td>
                    <td>29.0</td>
                    <td>91.5</td>
                    <td>0.52</td>
                  </tr>
                  <tr>
                    <td>2026-03-23 10:02:10</td>
                    <td>ZK21205-06</td>
                    <td>20.1</td>
                    <td>108.6</td>
                    <td>2.0</td>
                    <td>29.1</td>
                    <td>87.0</td>
                    <td>0.30</td>
                  </tr>
                  <tr>
                    <td>2026-03-23 10:02:20</td>
                    <td>ZK21205-07</td>
                    <td>14.9</td>
                    <td>79.2</td>
                    <td>1.5</td>
                    <td>29.6</td>
                    <td>88.0</td>
                    <td>0.39</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- 底部特征与质量监控区 -->
      <div class="bottom-monitoring">
        <!-- 数据质量 -->
        <div class="monitoring-section quality-metrics">
          <h3 class="section-title">数据质量</h3>
          <div class="quality-indicators">
            <div class="quality-item">
              <div class="quality-label">完整性</div>
              <div class="quality-bar">
                <div class="quality-fill" :style="{ width: dataQuality.completeness + '%' }"></div>
              </div>
              <div class="quality-value">{{ dataQuality.completeness }}%</div>
            </div>
            <div class="quality-item">
              <div class="quality-label">一致性</div>
              <div class="quality-bar">
                <div class="quality-fill" :style="{ width: dataQuality.consistency + '%' }"></div>
              </div>
              <div class="quality-value">{{ dataQuality.consistency }}%</div>
            </div>
            <div class="quality-item">
              <div class="quality-label">准确性</div>
              <div class="quality-bar">
                <div class="quality-fill" :style="{ width: dataQuality.accuracy + '%' }"></div>
              </div>
              <div class="quality-value">{{ dataQuality.accuracy }}%</div>
            </div>
          </div>
        </div>

        <!-- 异常明细 -->
        <div class="monitoring-section error-details">
          <h3 class="section-title">异常明细</h3>
          <div class="error-list">
            <div class="error-item" v-for="error in errorDetails" :key="error.id">
              <div class="error-time">{{ error.time }}</div>
              <div class="error-message">{{ error.message }}</div>
              <div class="error-severity" :class="error.severity">{{ error.severity }}</div>
            </div>
          </div>
        </div>
      </div>

    <!-- 返回按钮 -->
    <button class="btn-back" @click="handleBack">返回</button>
  </div>
</template>

<script setup>
import { ref, onMounted, onUnmounted } from 'vue'

const emit = defineEmits(['back'])

// 状态管理
const isProcessing = ref(false)
const currentStep = ref(1)
const pendingDataAmount = ref(128)
const fusionCompletionRate = ref(0)
const processingSpeed = ref(1.8)
const errorCount = ref(3)
const currentChartType = ref('stress') // 'stress' 或 'microseism'

// 数据质量
const dataQuality = ref({
  completeness: 92,
  consistency: 88,
  accuracy: 95
})

// 错误明细
const errorDetails = ref([
  { id: 1, time: '14:32:15', message: '数据格式异常', severity: 'warning' },
  { id: 2, time: '14:28:45', message: '缺失值过多', severity: 'error' },
  { id: 3, time: '14:25:30', message: '异常值检测', severity: 'warning' }
])

// 配置
const config = ref({
  cleaningThreshold: 30,
  featureDimensions: 5,
  fusionMethod: 'weighted'
})

// 图表引用
const beforeChart = ref(null)
const afterChart = ref(null)
const scatterChart = ref(null)
const radarChart = ref(null)
const featureChart = ref(null)

// 方法
function handleBack() {
  emit('back')
}

function toggleProcessing() {
  isProcessing.value = !isProcessing.value
  if (isProcessing.value) {
    startProcessing()
  }
}

function resetProcess() {
  isProcessing.value = false
  currentStep.value = 1
  fusionCompletionRate.value = 0
  errorCount.value = 0
}

function startProcessing() {
  const processInterval = setInterval(() => {
    if (!isProcessing.value) {
      clearInterval(processInterval)
      return
    }
    
    // 模拟处理进度
    fusionCompletionRate.value += 1
    if (fusionCompletionRate.value >= 100) {
      fusionCompletionRate.value = 100
      isProcessing.value = false
      clearInterval(processInterval)
    }
    
    // 模拟步骤更新
    if (fusionCompletionRate.value >= 25 && currentStep.value === 1) currentStep.value = 2
    if (fusionCompletionRate.value >= 50 && currentStep.value === 2) currentStep.value = 3
    if (fusionCompletionRate.value >= 75 && currentStep.value === 3) currentStep.value = 4
    if (fusionCompletionRate.value === 100 && currentStep.value === 4) currentStep.value = 5
  }, 500)
}

function updateConfig() {
  console.log('更新配置:', config.value)
}

function applyConfig() {
  console.log('应用配置:', config.value)
}

function toggleChartType() {
  currentChartType.value = currentChartType.value === 'stress' ? 'microseism' : 'stress'
}

// 模拟数据更新
let updateInterval = null

function startDataUpdates() {
  updateInterval = setInterval(() => {
    // 模拟处理速度变化
    processingSpeed.value = (processingSpeed.value + (Math.random() - 0.5) * 0.3).toFixed(1)
    
    // 模拟待处理数据量减少
    if (isProcessing.value && pendingDataAmount.value > 0) {
      pendingDataAmount.value -= 0.5
      pendingDataAmount.value = Math.max(0, pendingDataAmount.value)
    }
  }, 5000) // 核心指标刷新频率≤5秒
}

// 组件生命周期
onMounted(() => {
  startDataUpdates()
  console.log('数据层详情页面加载完成')
  // 这里可以添加图表初始化代码
})

onUnmounted(() => {
  if (updateInterval) {
    clearInterval(updateInterval)
  }
})
</script>

<style scoped>
.data-layer-detail {
  width: 100%;
  height: 100vh;
  display: flex;
  flex-direction: column;
  background-color: #0F172A;
  color: #FFFFFF;
  position: relative;
  overflow-y: auto;
  overflow-x: hidden;
  scroll-behavior: smooth;
}

/* 顶部流程总控区 */
.top-control-panel {
  min-height: 120px;
  background-color: rgba(15, 23, 42, 0.95);
  border-bottom: 1px solid rgba(255, 255, 255, 0.1);
  padding: 10px 20px;
  display: flex;
  flex-direction: column;
  justify-content: center;
}

.panel-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 10px;
}

.section-title {
  font-size: 16px;
  font-weight: 600;
  color: #06B6D4;
  margin: 0;
}

.control-buttons {
  display: flex;
  align-items: center;
  gap: 12px;
}

.btn-control {
  padding: 6px 12px;
  border: 1px solid rgba(255, 255, 255, 0.3);
  background-color: rgba(255, 255, 255, 0.1);
  color: #FFFFFF;
  border-radius: 4px;
  cursor: pointer;
  font-size: 12px;
  transition: all 0.3s ease;
}

.btn-control:hover {
  background-color: rgba(6, 182, 212, 0.2);
  border-color: #06B6D4;
}

.btn-control.active {
  background-color: rgba(6, 182, 212, 0.3);
  border-color: #06B6D4;
}

.stats-cards {
  display: flex;
  gap: 15px;
  flex-wrap: wrap;
}

.stat-card {
  flex: 1;
  min-width: 150px;
  padding: 10px;
  background-color: rgba(255, 255, 255, 0.05);
  border-radius: 6px;
  border: 1px solid rgba(255, 255, 255, 0.1);
}

.stat-title {
  font-size: 10px;
  color: rgba(255, 255, 255, 0.8);
  margin-bottom: 4px;
}

.stat-value {
  font-size: 18px;
  font-weight: 700;
  color: #00D9C0;
}

.stat-value.warning {
  color: #F59E0B;
}

.progress-bar {
  height: 4px;
  background-color: rgba(255, 255, 255, 0.1);
  border-radius: 2px;
  margin-top: 6px;
  overflow: hidden;
}

.progress-fill {
  height: 100%;
  background-color: #06B6D4;
  border-radius: 2px;
  transition: width 0.3s ease;
}

/* 中央多维度可视化区 */
.central-visualization {
  min-height: 300px;
  display: flex;
  flex-direction: column;
  padding: 10px 15px;
  gap: 12px;
}

.flow-diagram {
  background-color: rgba(15, 23, 42, 0.7);
  border-radius: 8px;
  border: 1px solid rgba(255, 255, 255, 0.1);
  padding: 15px;
  margin-bottom: 10px;
}

.diagram-title {
  font-size: 14px;
  font-weight: 600;
  color: #FFFFFF;
  margin: 0 0 15px 0;
}

.flow-steps {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 10px;
}

.flow-step {
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 10px;
  background-color: rgba(255, 255, 255, 0.05);
  border-radius: 6px;
  transition: all 0.3s ease;
}

.flow-step.active {
  background-color: rgba(6, 182, 212, 0.2);
  border: 1px solid rgba(6, 182, 212, 0.3);
}

.flow-step.completed {
  background-color: rgba(16, 185, 129, 0.2);
  border: 1px solid rgba(16, 185, 129, 0.3);
}

.step-icon {
  font-size: 20px;
  margin-bottom: 5px;
}

.step-label {
  font-size: 11px;
  color: #FFFFFF;
  text-align: center;
}

.flow-arrow {
  color: rgba(255, 255, 255, 0.5);
  font-size: 16px;
  font-weight: bold;
}

.data-comparison {
  background-color: rgba(15, 23, 42, 1);
  border-radius: 8px;
  border: 1px solid rgba(255, 255, 255, 0.1);
  padding: 15px;
  margin-bottom: 10px;
  width: 100%;
  box-sizing: border-box;
  position: relative;
  z-index: 1;
}

.multi-dimensional {
  background-color: rgba(15, 23, 42, 0.7);
  border-radius: 8px;
  border: 1px solid rgba(255, 255, 255, 0.1);
  padding: 15px;
  margin-bottom: 10px;
}

.chart-title {
  font-size: 14px;
  font-weight: 600;
  color: #FFFFFF;
  margin: 0 0 15px 0;
}

.comparison-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 15px;
}

.toggle-btn {
  padding: 6px 12px;
  background-color: rgba(6, 182, 212, 0.2);
  border: 1px solid #06B6D4;
  color: #06B6D4;
  border-radius: 4px;
  font-size: 12px;
  cursor: pointer;
  transition: all 0.3s ease;
}

.toggle-btn:hover {
  background-color: rgba(6, 182, 212, 0.3);
}

.comparison-content {
  max-height: 600px;
  overflow-y: auto;
  overflow-x: hidden;
  scroll-behavior: smooth;
  width: 100%;
}

.comparison-charts {
  display: flex;
  gap: 10px;
  height: 400px;
  margin-bottom: 20px;
  width: 100%;
}

.chart-container {
  flex: 1;
  background-color: rgba(255, 255, 255, 0.02);
  border-radius: 6px;
  padding: 5px;
  display: flex;
  flex-direction: column;
  width: 100%;
  box-sizing: border-box;
}

.data-table {
  margin-top: 20px;
  background-color: rgba(15, 23, 42, 0.7);
  border-radius: 8px;
  border: 1px solid rgba(255, 255, 255, 0.1);
  padding: 15px;
}

.table-title {
  font-size: 14px;
  font-weight: 600;
  color: #FFFFFF;
  margin: 0 0 15px 0;
}

.table-container {
  overflow-x: auto;
  max-height: 400px;
  overflow-y: auto;
}

.table-container table {
  width: 100%;
  border-collapse: collapse;
  font-size: 12px;
}

.table-container th {
  background-color: rgba(6, 182, 212, 0.1);
  backdrop-filter: blur(10px);
  -webkit-backdrop-filter: blur(10px);
  color: #06B6D4;
  font-weight: 600;
  padding: 8px;
  text-align: left;
  border-bottom: 1px solid rgba(255, 255, 255, 0.1);
  position: sticky;
  top: 0;
  z-index: 1;
}

.table-container td {
  padding: 6px 8px;
  border-bottom: 1px solid rgba(255, 255, 255, 0.05);
  color: rgba(255, 255, 255, 0.8);
}

.table-container tr:hover {
  background-color: rgba(255, 255, 255, 0.05);
}

/* 滚动条样式 */
.comparison-content::-webkit-scrollbar,
.table-container::-webkit-scrollbar {
  width: 6px;
  height: 6px;
}

.comparison-content::-webkit-scrollbar-track,
.table-container::-webkit-scrollbar-track {
  background: rgba(255, 255, 255, 0.05);
  border-radius: 3px;
}

.comparison-content::-webkit-scrollbar-thumb,
.table-container::-webkit-scrollbar-thumb {
  background: rgba(255, 255, 255, 0.2);
  border-radius: 3px;
}

.comparison-content::-webkit-scrollbar-thumb:hover,
.table-container::-webkit-scrollbar-thumb:hover {
  background: rgba(255, 255, 255, 0.3);
}

.chart-container {
  flex: 1;
  background-color: rgba(255, 255, 255, 0.02);
  border-radius: 6px;
  padding: 5px;
  display: flex;
  flex-direction: column;
  width: 100%;
  box-sizing: border-box;
}

.chart-header {
  font-size: 12px;
  color: rgba(255, 255, 255, 0.8);
  margin-bottom: 5px;
  text-align: center;
}

.bar-chart,
.scatter-chart,
.radar-chart {
  flex: 1;
  background-color: rgba(255, 255, 255, 0.03);
  border-radius: 4px;
  display: flex;
  flex-direction: column;
  padding: 0;
  color: rgba(255, 255, 255, 0.5);
  font-size: 12px;
  width: 100%;
  height: 100%;
}

.chart-data {
  margin-bottom: 5px;
  flex: 1;
  display: flex;
  flex-direction: column;
  width: 100%;
  height: 100%;
}

.chart-label {
  font-size: 11px;
  color: rgba(255, 255, 255, 0.8);
  margin-bottom: 5px;
  padding: 0 5px;
}

.bar-container {
  position: relative;
  flex: 1;
  background-color: rgba(255, 255, 255, 0.02);
  border-radius: 3px;
  overflow: hidden;
  margin-bottom: 5px;
  width: 100%;
  height: 100%;
}

.bar {
  position: absolute;
  bottom: 0;
  width: 8px;
  background-color: #06B6D4;
  border-radius: 4px 4px 0 0;
  transition: height 0.3s ease, background-color 0.3s ease, width 0.3s ease;
  cursor: pointer;
}

.bar:hover {
  background-color: #00D9C0;
  width: 10px;
}

.bar-tooltip {
  position: absolute;
  bottom: 100%;
  left: 50%;
  transform: translateX(-50%);
  background-color: rgba(0, 0, 0, 0.8);
  color: #FFFFFF;
  padding: 4px 8px;
  border-radius: 4px;
  font-size: 10px;
  white-space: nowrap;
  opacity: 0;
  pointer-events: none;
  transition: opacity 0.3s ease;
  z-index: 10;
}

.bar:hover .bar-tooltip {
  opacity: 1;
}

.bar-container::before {
  content: '';
  position: absolute;
  bottom: 0;
  left: 0;
  right: 0;
  height: 1px;
  background-color: rgba(255, 255, 255, 0.2);
}

.chart-axis {
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-size: 10px;
  color: rgba(255, 255, 255, 0.6);
  margin-top: 5px;
}

.x-axis {
  flex: 1;
  text-align: center;
}

.y-axis {
  writing-mode: vertical-rl;
  text-orientation: mixed;
  transform: rotate(180deg);
  white-space: nowrap;
}

/* 底部特征与质量监控区 */
.bottom-monitoring {
  min-height: 200px;
  background-color: rgba(15, 23, 42, 1);
  border-top: 1px solid rgba(255, 255, 255, 0.1);
  padding: 20px 30px;
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 20px;
  position: relative;
  z-index: 2;
}

.monitoring-section {
  background-color: rgba(255, 255, 255, 0.05);
  border-radius: 8px;
  border: 1px solid rgba(255, 255, 255, 0.1);
  padding: 16px;
  overflow-y: auto;
  max-height: 150px;
  position: relative;
  z-index: 3;
}

.monitoring-section .section-title {
  font-size: 14px;
  font-weight: 600;
  color: #FFFFFF;
  margin: 0 0 16px 0;
}

.bar-chart {
  height: 150px;
  background-color: rgba(255, 255, 255, 0.03);
  border-radius: 4px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: rgba(255, 255, 255, 0.5);
  font-size: 12px;
}

.quality-indicators {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.quality-item {
  display: flex;
  align-items: center;
  gap: 10px;
}

.quality-label {
  font-size: 12px;
  color: rgba(255, 255, 255, 0.8);
  min-width: 60px;
}

.quality-bar {
  flex: 1;
  height: 6px;
  background-color: rgba(255, 255, 255, 0.1);
  border-radius: 3px;
  overflow: hidden;
}

.quality-fill {
  height: 100%;
  background-color: #10B981;
  border-radius: 3px;
  transition: width 0.3s ease;
}

.quality-value {
  font-size: 12px;
  font-weight: 500;
  color: #10B981;
  min-width: 40px;
  text-align: right;
}

.error-list {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.error-item {
  padding: 8px;
  background-color: rgba(255, 255, 255, 0.05);
  border-radius: 4px;
  border-left: 4px solid transparent;
}

.error-item.error {
  border-left-color: #EF4444;
  background-color: rgba(239, 68, 68, 0.1);
}

.error-item.warning {
  border-left-color: #F59E0B;
  background-color: rgba(245, 158, 11, 0.1);
}

.error-time {
  font-size: 10px;
  color: rgba(255, 255, 255, 0.5);
  margin-bottom: 4px;
}

.error-message {
  font-size: 12px;
  color: #FFFFFF;
  margin-bottom: 4px;
}

.error-severity {
  font-size: 10px;
  padding: 2px 6px;
  border-radius: 10px;
  align-self: flex-start;
}

.error-severity.error {
  background-color: rgba(239, 68, 68, 0.2);
  color: #EF4444;
}

.error-severity.warning {
  background-color: rgba(245, 158, 11, 0.2);
  color: #F59E0B;
}

.config-form {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.config-item {
  display: flex;
  align-items: center;
  gap: 8px;
}

.config-item label {
  font-size: 12px;
  color: rgba(255, 255, 255, 0.8);
  min-width: 80px;
}

.config-item input {
  flex: 1;
  padding: 4px 8px;
  background-color: rgba(255, 255, 255, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.3);
  color: #FFFFFF;
  border-radius: 4px;
  font-size: 12px;
}

.config-item select {
  flex: 1;
  padding: 4px 8px;
  background-color: rgba(255, 255, 255, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.3);
  color: #FFFFFF;
  border-radius: 4px;
  font-size: 12px;
}

.unit {
  font-size: 12px;
  color: rgba(255, 255, 255, 0.6);
  min-width: 30px;
}

.btn-apply {
  padding: 6px 12px;
  background-color: rgba(6, 182, 212, 0.2);
  border: 1px solid #06B6D4;
  color: #06B6D4;
  border-radius: 4px;
  font-size: 12px;
  cursor: pointer;
  transition: all 0.3s ease;
  align-self: flex-start;
}

.btn-apply:hover {
  background-color: rgba(6, 182, 212, 0.3);
}

/* 返回按钮 */
.btn-back {
  position: absolute;
  top: 20px;
  left: 20px;
  padding: 8px 16px;
  background-color: rgba(255, 255, 255, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.3);
  color: #FFFFFF;
  border-radius: 6px;
  cursor: pointer;
  transition: all 0.3s ease;
  z-index: 10;
  font-size: 12px;
}

.btn-back:hover {
  background-color: rgba(6, 182, 212, 0.2);
  border-color: #06B6D4;
}

/* 响应式设计 */
@media (max-width: 1200px) {
  .bottom-monitoring {
    grid-template-columns: 1fr;
  }
  
  .comparison-charts,
  .feature-charts {
    flex-direction: column;
    height: 400px;
  }
}

@media (max-width: 768px) {
  .top-control-panel {
    padding: 10px 15px;
  }
  
  .central-visualization {
    padding: 10px 15px;
  }
  
  .bottom-monitoring {
    padding: 15px;
  }
  
  .flow-steps {
    flex-direction: column;
    gap: 15px;
  }
  
  .flow-arrow {
    transform: rotate(90deg);
  }
}

/* 滚动条样式 */
::-webkit-scrollbar {
  width: 6px;
}

::-webkit-scrollbar-track {
  background: rgba(255, 255, 255, 0.05);
  border-radius: 3px;
}

::-webkit-scrollbar-thumb {
  background: rgba(255, 255, 255, 0.2);
  border-radius: 3px;
}

::-webkit-scrollbar-thumb:hover {
  background: rgba(255, 255, 255, 0.3);
}
</style>