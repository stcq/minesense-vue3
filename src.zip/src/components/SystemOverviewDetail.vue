<template>
  <div class="system-overview-detail">
    <!-- 顶部通栏 -->
    <div class="top-bar">
      <div class="logo-section">
        <div class="logo">MineSense · 智能矿压系统</div>
        <div class="breadcrumb">系统概览 > 详情</div>
      </div>
      <div class="top-controls">
        <button class="btn-back" @click="handleBack">返回</button>
        <button class="btn-refresh" @click="handleRefresh">刷新</button>
        <div class="system-status">
          <span class="status-indicator online"></span>
          <span>系统运行正常</span>
        </div>
      </div>
    </div>

    <!-- 系统健康度仪表盘 -->
    <div class="health-dashboard">
      <div class="dashboard-title">系统全链路综合健康度</div>
      <div class="health-score">
        <div class="score-circle">
          <div class="score-value">92</div>
          <div class="score-label">综合健康度</div>
        </div>
        <div class="health-items">
          <div class="health-item" :class="{ healthy: healthStatus.sensing.status === 'healthy' }">
            <div class="health-item-title">传感层</div>
            <div class="health-item-value">{{ healthStatus.sensing.score }}%</div>
            <div class="health-item-status">{{ healthStatus.sensing.statusText }}</div>
          </div>
          <div class="health-item" :class="{ healthy: healthStatus.data.status === 'healthy' }">
            <div class="health-item-title">数据层</div>
            <div class="health-item-value">{{ healthStatus.data.score }}%</div>
            <div class="health-item-status">{{ healthStatus.data.statusText }}</div>
          </div>
          <div class="health-item" :class="{ healthy: healthStatus.model.status === 'healthy' }">
            <div class="health-item-title">模型层</div>
            <div class="health-item-value">{{ healthStatus.model.score }}%</div>
            <div class="health-item-status">{{ healthStatus.model.statusText }}</div>
          </div>
          <div class="health-item" :class="{ healthy: healthStatus.decision.status === 'healthy' }">
            <div class="health-item-title">决策执行层</div>
            <div class="health-item-value">{{ healthStatus.decision.score }}%</div>
            <div class="health-item-status">{{ healthStatus.decision.statusText }}</div>
          </div>
        </div>
      </div>
    </div>

    <!-- 主内容区域 -->
    <div class="main-content-area">
      <!-- 左侧大区 -->
      <div class="left-section">
        <!-- 矿井拓扑地图 -->
        <div class="section-card mine-map" :class="{ expanded: isMapExpanded }">
          <div class="section-title">
            <span>矿井拓扑地图</span>
            <button class="btn-expand" @click="handleMapExpand">展开</button>
          </div>
          <div class="map-container">
            <svg class="mine-topology-map" width="100%" height="100%" viewBox="0 0 800 300">
              
              <!-- 矿井地面结构 -->
              <g class="map-node" id="surface-control">
                <rect x="350" y="20" width="100" height="30" rx="5" fill="#1E293B" stroke="#94A3B8" stroke-width="1"/>
                <text x="400" y="40" text-anchor="middle" fill="#FFFFFF" font-size="12">地面控制中心</text>
              </g>
              
              <!-- 主井 -->
              <g class="map-node" id="main-shaft">
                <rect x="380" y="50" width="40" height="60" rx="2" fill="#1E293B" stroke="#94A3B8" stroke-width="1"/>
                <text x="400" y="85" text-anchor="middle" fill="#FFFFFF" font-size="10">主井</text>
              </g>
              
              <!-- 副井 -->
              <g class="map-node" id="auxiliary-shaft">
                <rect x="330" y="50" width="40" height="60" rx="2" fill="#1E293B" stroke="#94A3B8" stroke-width="1"/>
                <text x="350" y="85" text-anchor="middle" fill="#FFFFFF" font-size="10">副井</text>
              </g>
              
              <!-- 回风井 -->
              <g class="map-node" id="return-air-shaft">
                <rect x="430" y="50" width="40" height="60" rx="2" fill="#1E293B" stroke="#94A3B8" stroke-width="1"/>
                <text x="450" y="85" text-anchor="middle" fill="#FFFFFF" font-size="10">回风井</text>
              </g>
              
              <!-- 井底车场 -->
              <g class="map-node" id="shaft-station">
                <rect x="250" y="110" width="250" height="40" rx="5" fill="#1E293B" stroke="#94A3B8" stroke-width="1"/>
                <text x="375" y="135" text-anchor="middle" fill="#FFFFFF" font-size="12">井底车场</text>
              </g>
              
              <!-- 运输大巷 -->
              <g class="map-node" id="transport-roadway">
                <rect x="100" y="150" width="450" height="30" rx="5" fill="#1E293B" stroke="#94A3B8" stroke-width="1"/>
                <text x="325" y="170" text-anchor="middle" fill="#FFFFFF" font-size="12">运输大巷</text>
              </g>
              
              <!-- 回风大巷 -->
              <g class="map-node" id="return-air-roadway">
                <rect x="100" y="220" width="450" height="30" rx="5" fill="#1E293B" stroke="#94A3B8" stroke-width="1"/>
                <text x="325" y="240" text-anchor="middle" fill="#FFFFFF" font-size="12">回风大巷</text>
              </g>
              
              <!-- 采掘工作面1 -->
              <g class="map-node" id="working-face-1203">
                <rect x="560" y="150" width="120" height="60" rx="5" fill="#1E293B" stroke="#94A3B8" stroke-width="1"/>
                <text x="620" y="180" text-anchor="middle" fill="#FFFFFF" font-size="12">1203工作面</text>
              </g>
              
              <!-- 采掘工作面2 -->
              <g class="map-node" id="working-face-1205">
                <rect x="560" y="220" width="120" height="60" rx="5" fill="#1E293B" stroke="#94A3B8" stroke-width="1"/>
                <text x="620" y="250" text-anchor="middle" fill="#FFFFFF" font-size="12">1205工作面</text>
              </g>
              
              <!-- 硐室 -->
              <g class="map-node" id="chamber">
                <rect x="100" y="180" width="80" height="30" rx="5" fill="#1E293B" stroke="#94A3B8" stroke-width="1"/>
                <text x="140" y="200" text-anchor="middle" fill="#FFFFFF" font-size="10">硐室</text>
              </g>
              
              <!-- 连接巷道 -->
              <line x1="375" y1="110" x2="375" y2="150" stroke="#94A3B8" stroke-width="1"/>
              <line x1="180" y1="180" x2="180" y2="220" stroke="#94A3B8" stroke-width="1"/>
              <line x1="550" y1="165" x2="560" y2="165" stroke="#94A3B8" stroke-width="1"/>
              <line x1="550" y1="235" x2="560" y2="235" stroke="#94A3B8" stroke-width="1"/>
              
              <!-- 通风系统 -->
              <g class="map-node system-node" id="ventilation-system">
                <path class="system-path" d="M450 110 L470 110 L470 220 L680 220" stroke="#3B82F6" stroke-width="1" fill="none"/>
                <circle cx="470" cy="110" r="3" fill="#3B82F6"/>
                <text x="490" y="105" fill="#3B82F6" font-size="10">通风系统</text>
              </g>
              
              <!-- 供电系统 -->
              <g class="map-node system-node" id="power-system">
                <path class="system-path" d="M300 110 L300 130 L200 130 L200 220" stroke="#F59E0B" stroke-width="1" fill="none"/>
                <circle cx="300" cy="110" r="3" fill="#F59E0B"/>
                <text x="310" y="105" fill="#F59E0B" font-size="10">供电系统</text>
              </g>
              
              <!-- 排水系统 -->
              <g class="map-node system-node" id="drainage-system">
                <path class="system-path" d="M400 110 L400 130 L250 130 L250 220" stroke="#06B6D4" stroke-width="1" fill="none"/>
                <circle cx="400" cy="110" r="3" fill="#06B6D4"/>
                <text x="410" y="105" fill="#06B6D4" font-size="10">排水系统</text>
              </g>
              
              <!-- 监控系统 -->
              <g class="map-node system-node" id="monitoring-system">
                <path class="system-path" d="M350 110 L350 130 L150 130 L150 220" stroke="#EC4899" stroke-width="1" fill="none"/>
                <circle cx="350" cy="110" r="3" fill="#EC4899"/>
                <text x="360" y="105" fill="#EC4899" font-size="10">监控系统</text>
              </g>
              
              <!-- 机器人1 - 正常状态 -->
              <g class="robot-indicator map-node" id="robot-1">
                <circle cx="200" cy="165" r="8" fill="#10B981" stroke="#FFFFFF" stroke-width="1"/>
                <text x="200" y="168" text-anchor="middle" fill="#FFFFFF" font-size="8">R1</text>
                <text x="220" y="165" fill="#10B981" font-size="10">正常</text>
              </g>
              
              <!-- 机器人2 - 故障状态 -->
              <g class="robot-indicator map-node" id="robot-2">
                <circle cx="300" cy="165" r="8" fill="#EF4444" stroke="#FFFFFF" stroke-width="1"/>
                <text x="300" y="168" text-anchor="middle" fill="#FFFFFF" font-size="8">R2</text>
                <text x="320" y="165" fill="#EF4444" font-size="10">故障</text>
              </g>
              
              <!-- 机器人3 - 待机状态 -->
              <g class="robot-indicator map-node" id="robot-3">
                <circle cx="400" cy="165" r="8" fill="#F59E0B" stroke="#FFFFFF" stroke-width="1"/>
                <text x="400" y="168" text-anchor="middle" fill="#FFFFFF" font-size="8">R3</text>
                <text x="420" y="165" fill="#F59E0B" font-size="10">待机</text>
              </g>
              
              <!-- 机器人4 - 作业中状态 -->
              <g class="robot-indicator map-node" id="robot-4">
                <circle cx="500" cy="165" r="8" fill="#06B6D4" stroke="#FFFFFF" stroke-width="1"/>
                <text x="500" y="168" text-anchor="middle" fill="#FFFFFF" font-size="8">R4</text>
                <text x="520" y="165" fill="#06B6D4" font-size="10">作业中</text>
              </g>
              
              <!-- 机器人5 - 正常状态 -->
              <g class="robot-indicator map-node" id="robot-5">
                <circle cx="600" cy="180" r="8" fill="#10B981" stroke="#FFFFFF" stroke-width="1"/>
                <text x="600" y="183" text-anchor="middle" fill="#FFFFFF" font-size="8">R5</text>
                <text x="620" y="180" fill="#10B981" font-size="10">正常</text>
              </g>
              
              <!-- 机器人6 - 作业中状态 -->
              <g class="robot-indicator map-node" id="robot-6">
                <circle cx="600" cy="250" r="8" fill="#06B6D4" stroke="#FFFFFF" stroke-width="1"/>
                <text x="600" y="253" text-anchor="middle" fill="#FFFFFF" font-size="8">R6</text>
                <text x="620" y="250" fill="#06B6D4" font-size="10">作业中</text>
              </g>
              
              <!-- 弹出信息框 -->
              <g id="info-tooltip" class="info-tooltip" style="display: none;">
                <rect x="0" y="0" width="180" height="80" rx="5" fill="rgba(15, 23, 42, 0.95)" stroke="#06B6D4" stroke-width="1"/>
                <text x="10" y="20" fill="#FFFFFF" font-size="12" class="tooltip-title"></text>
                <text x="10" y="40" fill="#94A3B8" font-size="10" class="tooltip-param1"></text>
                <text x="10" y="55" fill="#94A3B8" font-size="10" class="tooltip-param2"></text>
                <text x="10" y="70" fill="#94A3B8" font-size="10" class="tooltip-param3"></text>
              </g>
            </svg>
          </div>
        </div>

        <!-- 五层架构动态流转流程图 -->
        <div class="section-card architecture-flow">
          <div class="section-title">
            <span>五层架构动态流转流程</span>
            <button class="btn-expand">展开</button>
          </div>
          <div class="flow-container">
            <div class="flow-item sensing">
              <div class="flow-icon">🔍</div>
              <div class="flow-title">传感层</div>
              <div class="flow-status">正常</div>
            </div>
            <div class="flow-arrow">→</div>
            <div class="flow-item data">
              <div class="flow-icon">💾</div>
              <div class="flow-title">数据层</div>
              <div class="flow-status">正常</div>
            </div>
            <div class="flow-arrow">→</div>
            <div class="flow-item model">
              <div class="flow-icon">🤖</div>
              <div class="flow-title">模型层</div>
              <div class="flow-status">正常</div>
            </div>
            <div class="flow-arrow">→</div>
            <div class="flow-item decision">
              <div class="flow-icon">⚡</div>
              <div class="flow-title">决策层</div>
              <div class="flow-status">正常</div>
            </div>
            <div class="flow-arrow">→</div>
            <div class="flow-item execution">
              <div class="flow-icon">✅</div>
              <div class="flow-title">执行层</div>
              <div class="flow-status">正常</div>
            </div>
          </div>
        </div>
      </div>

      <!-- 右侧小区 -->
      <div class="right-section">
        <!-- 核心数据指标看板 -->
        <div class="section-card metrics-board">
          <div class="section-title">核心数据指标</div>
          <div class="metrics-grid">
            <div class="metric-item">
              <div class="metric-title">实时监测节点</div>
              <div class="metric-value">42</div>
              <div class="metric-unit">个</div>
            </div>
            <div class="metric-item">
              <div class="metric-title">数据采集频率</div>
              <div class="metric-value">10</div>
              <div class="metric-unit">秒/次</div>
            </div>
            <div class="metric-item">
              <div class="metric-title">设备在线率</div>
              <div class="metric-value">98.5</div>
              <div class="metric-unit">%</div>
            </div>
            <div class="metric-item">
              <div class="metric-title">风险预警数</div>
              <div class="metric-value" :class="{ warning: riskAlerts > 0 }">3</div>
              <div class="metric-unit">个</div>
            </div>
            <div class="metric-item">
              <div class="metric-title">AI决策准确率</div>
              <div class="metric-value">94.6</div>
              <div class="metric-unit">%</div>
            </div>
            <div class="metric-item">
              <div class="metric-title">系统响应时间</div>
              <div class="metric-value">120</div>
              <div class="metric-unit">ms</div>
            </div>
          </div>
        </div>

        <!-- 实时预警列表 -->
        <div class="section-card alerts-list">
          <div class="section-title">
            <span>实时预警列表</span>
            <span class="alerts-count">{{ riskAlerts }}</span>
          </div>
          <div class="alerts-container">
            <div v-for="alert in alerts" :key="alert.id" class="alert-item" :class="alert.priority">
              <div class="alert-icon">{{ alert.icon }}</div>
              <div class="alert-content">
                <div class="alert-title">{{ alert.title }}</div>
                <div class="alert-description">{{ alert.description }}</div>
                <div class="alert-time">{{ alert.time }}</div>
              </div>
              <div class="alert-actions">
                <button class="btn-detail">详情</button>
                <button class="btn-handle">处理</button>
              </div>
            </div>
          </div>
        </div>

        <!-- AI模型状态 -->
        <div class="section-card ai-status">
          <div class="section-title">AI模型状态</div>
          <div class="ai-models">
            <div class="ai-model-item" v-for="model in aiModels" :key="model.id">
              <div class="ai-model-name">{{ model.name }}</div>
              <div class="ai-model-status" :class="model.status">
                <div class="status-dot"></div>
                <span>{{ model.statusText }}</span>
              </div>
              <div class="ai-model-accuracy">准确率: {{ model.accuracy }}%</div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- 底部状态栏 -->
    <div class="bottom-status-bar">
      <div class="status-item">
        <span class="status-label">系统运行时间:</span>
        <span class="status-value">{{ systemUptime }}</span>
      </div>
      <div class="status-item">
        <span class="status-label">最后刷新时间:</span>
        <span class="status-value">{{ lastRefreshTime }}</span>
      </div>
      <div class="status-item">
        <span class="status-label">数据采集点:</span>
        <span class="status-value">{{ dataCollectionPoints }}</span>
      </div>
      <div class="status-item">
        <span class="status-label">系统版本:</span>
        <span class="status-value">v1.0.0</span>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, onUnmounted, computed } from 'vue'

const emit = defineEmits(['back'])

// 健康状态数据
const healthStatus = ref({
  sensing: { score: 95, status: 'healthy', statusText: '运行正常' },
  data: { score: 92, status: 'healthy', statusText: '运行正常' },
  model: { score: 94, status: 'healthy', statusText: '运行正常' },
  decision: { score: 88, status: 'healthy', statusText: '运行正常' }
})

// 展开状态
const isMapExpanded = ref(false)

// 预警数据
const alerts = ref([
  {
    id: 1,
    icon: '⚠️',
    title: '应力异常',
    description: '工作面1203区域应力值超过预警阈值',
    time: '2026-03-22 14:32:15',
    priority: 'high'
  },
  {
    id: 2,
    icon: '🔔',
    title: '设备离线',
    description: '传感器SN-20230105离线',
    time: '2026-03-22 14:28:45',
    priority: 'medium'
  },
  {
    id: 3,
    icon: '⚠️',
    title: '温度异常',
    description: '回采通道温度异常升高',
    time: '2026-03-22 14:25:30',
    priority: 'medium'
  }
])

// AI模型状态
const aiModels = ref([
  { id: 1, name: '应力预测模型', status: 'active', statusText: '运行中', accuracy: 94.6 },
  { id: 2, name: '风险评估模型', status: 'active', statusText: '运行中', accuracy: 92.3 },
  { id: 3, name: '充填效果模型', status: 'active', statusText: '运行中', accuracy: 89.7 }
])

// 计算属性
const riskAlerts = computed(() => alerts.value.length)
const systemUptime = ref('270天 14小时 32分钟')
const lastRefreshTime = ref('2026-03-22 14:35:00')
const dataCollectionPoints = ref('42个')

// 方法
function handleBack() {
  emit('back')
}

function handleRefresh() {
  // 模拟刷新操作
  lastRefreshTime.value = new Date().toLocaleString()
  console.log('系统刷新')
}

// 处理地图展开/收起
function handleMapExpand() {
  isMapExpanded.value = !isMapExpanded.value
  // 重置地图位置和缩放
  resetMapTransform()
  console.log(`地图${isMapExpanded.value ? '展开' : '收起'}`)
}

// 节点参数数据
const nodeParams = {
  'surface-control': {
    title: '地面控制中心',
    params: [
      '运行状态: 正常',
      '在线设备: 42台',
      '系统负载: 35%'
    ]
  },
  'main-shaft': {
    title: '主井',
    params: [
      '运行状态: 正常',
      '提升速度: 8m/s',
      '负载: 1200kg'
    ]
  },
  'auxiliary-shaft': {
    title: '副井',
    params: [
      '运行状态: 正常',
      '提升速度: 6m/s',
      '人员运输: 20人/次'
    ]
  },
  'return-air-shaft': {
    title: '回风井',
    params: [
      '运行状态: 正常',
      '风速: 3.2m/s',
      '瓦斯浓度: 0.3%'
    ]
  },
  'shaft-station': {
    title: '井底车场',
    params: [
      '运行状态: 正常',
      '车辆数量: 8辆',
      '人员数量: 12人'
    ]
  },
  'transport-roadway': {
    title: '运输大巷',
    params: [
      '运行状态: 正常',
      '运输量: 2400t/h',
      '巷道温度: 22°C'
    ]
  },
  'return-air-roadway': {
    title: '回风大巷',
    params: [
      '运行状态: 正常',
      '风速: 2.8m/s',
      '瓦斯浓度: 0.2%'
    ]
  },
  'working-face-1203': {
    title: '1203工作面',
    params: [
      '运行状态: 生产中',
      '煤产量: 1200t/h',
      '人员数量: 15人'
    ]
  },
  'working-face-1205': {
    title: '1205工作面',
    params: [
      '运行状态: 准备中',
      '煤产量: 0t/h',
      '人员数量: 8人'
    ]
  },
  'chamber': {
    title: '硐室',
    params: [
      '运行状态: 正常',
      '设备数量: 12台',
      '维护状态: 良好'
    ]
  },
  'ventilation-system': {
    title: '通风系统',
    params: [
      '运行状态: 正常',
      '风机功率: 250kW',
      '风量: 12000m³/min'
    ]
  },
  'power-system': {
    title: '供电系统',
    params: [
      '运行状态: 正常',
      '电压: 10kV',
      '负载率: 65%'
    ]
  },
  'drainage-system': {
    title: '排水系统',
    params: [
      '运行状态: 正常',
      '排水量: 500m³/h',
      '水位: 1.2m'
    ]
  },
  'monitoring-system': {
    title: '监控系统',
    params: [
      '运行状态: 正常',
      '监控点: 128个',
      '数据传输: 正常'
    ]
  },
  'robot-1': {
    title: '机器人R1',
    params: [
      '状态: 正常',
      '位置: 运输大巷',
      '电量: 85%'
    ]
  },
  'robot-2': {
    title: '机器人R2',
    params: [
      '状态: 故障',
      '位置: 运输大巷',
      '故障原因: 传感器故障'
    ]
  },
  'robot-3': {
    title: '机器人R3',
    params: [
      '状态: 待机',
      '位置: 运输大巷',
      '电量: 92%'
    ]
  },
  'robot-4': {
    title: '机器人R4',
    params: [
      '状态: 作业中',
      '位置: 运输大巷',
      '任务: 巡检'
    ]
  },
  'robot-5': {
    title: '机器人R5',
    params: [
      '状态: 正常',
      '位置: 1203工作面',
      '电量: 78%'
    ]
  },
  'robot-6': {
    title: '机器人R6',
    params: [
      '状态: 作业中',
      '位置: 1205工作面',
      '任务: 环境监测'
    ]
  }
}

// 显示信息提示框
function showTooltip(event, nodeId) {
  const tooltip = document.getElementById('info-tooltip')
  if (!tooltip) {
    console.error('Tooltip element not found')
    return
  }
  
  const params = nodeParams[nodeId]
  if (!params) {
    console.error('Params not found for node:', nodeId)
    return
  }
  
  // 设置提示框内容
  const titleElement = tooltip.querySelector('.tooltip-title')
  const param1Element = tooltip.querySelector('.tooltip-param1')
  const param2Element = tooltip.querySelector('.tooltip-param2')
  const param3Element = tooltip.querySelector('.tooltip-param3')
  
  if (titleElement) titleElement.textContent = params.title
  if (param1Element) param1Element.textContent = params.params[0]
  if (param2Element) param2Element.textContent = params.params[1]
  if (param3Element) param3Element.textContent = params.params[2]
  
  // 计算鼠标位置
  const svg = event.currentTarget.closest('svg')
  if (!svg) {
    console.error('SVG element not found')
    return
  }
  
  const point = svg.createSVGPoint()
  point.x = event.clientX
  point.y = event.clientY
  
  try {
    const transformedPoint = point.matrixTransform(svg.getScreenCTM().inverse())
    
    // 设置提示框位置
    tooltip.setAttribute('transform', `translate(${transformedPoint.x + 10}, ${transformedPoint.y - 90})`)
    tooltip.style.display = 'block'
  } catch (error) {
    console.error('Error calculating tooltip position:', error)
    // 备用位置
    tooltip.setAttribute('transform', 'translate(10, 10)')
    tooltip.style.display = 'block'
  }
}

// 隐藏信息提示框
function hideTooltip() {
  const tooltip = document.getElementById('info-tooltip')
  if (tooltip) {
    tooltip.style.display = 'none'
  }
}

// 移动信息提示框
function handleTooltipMove(event) {
  const tooltip = document.getElementById('info-tooltip')
  if (!tooltip || tooltip.style.display === 'none') return
  
  // 计算鼠标位置
  const svg = event.currentTarget.closest('svg')
  if (!svg) return
  
  const point = svg.createSVGPoint()
  point.x = event.clientX
  point.y = event.clientY
  
  try {
    const transformedPoint = point.matrixTransform(svg.getScreenCTM().inverse())
    tooltip.setAttribute('transform', `translate(${transformedPoint.x + 10}, ${transformedPoint.y - 90})`)
  } catch (error) {
    // 忽略错误，保持tooltip在当前位置
  }
}

// 拖拽和缩放相关变量
const isDragging = ref(false)
const startX = ref(0)
const startY = ref(0)
const currentX = ref(0)
const currentY = ref(0)
const scale = ref(1)

// 处理鼠标按下事件（开始拖拽）
function handleMouseDown(event) {
  if (!isMapExpanded.value) return
  isDragging.value = true
  startX.value = event.clientX - currentX.value
  startY.value = event.clientY - currentY.value
}

// 处理鼠标移动事件（拖拽中）
function handleMouseMove(event) {
  if (!isDragging.value || !isMapExpanded.value) return
  currentX.value = event.clientX - startX.value
  currentY.value = event.clientY - startY.value
  updateMapTransform()
}

// 处理鼠标释放事件（结束拖拽）
function handleMouseUp() {
  isDragging.value = false
}

// 处理滚轮事件（缩放）
function handleWheel(event) {
  if (!isMapExpanded.value) return
  event.preventDefault()
  
  const delta = event.deltaY > 0 ? 0.9 : 1.1
  const newScale = Math.max(0.5, Math.min(3, scale.value * delta))
  scale.value = newScale
  updateMapTransform()
}

// 更新地图变换
function updateMapTransform() {
  const map = document.querySelector('.mine-topology-map')
  if (map) {
    map.style.transform = `translate(${currentX.value}px, ${currentY.value}px) scale(${scale.value})`
  }
}

// 重置地图位置和缩放
function resetMapTransform() {
  currentX.value = 0
  currentY.value = 0
  scale.value = 1
  updateMapTransform()
}

// 组件挂载时的初始化
onMounted(() => {
  // 为所有地图节点添加事件监听器
  const nodes = document.querySelectorAll('.map-node')
  nodes.forEach(node => {
    node.addEventListener('mouseenter', (e) => showTooltip(e, node.id))
    node.addEventListener('mousemove', handleTooltipMove)
    node.addEventListener('mouseleave', hideTooltip)
  })
  
  // 为地图容器添加拖拽和缩放事件监听器
  const mapContainer = document.querySelector('.map-container')
  if (mapContainer) {
    mapContainer.addEventListener('mousedown', handleMouseDown)
    mapContainer.addEventListener('mousemove', handleMouseMove)
    mapContainer.addEventListener('mouseup', handleMouseUp)
    mapContainer.addEventListener('mouseleave', handleMouseUp)
    mapContainer.addEventListener('wheel', handleWheel, { passive: false })
  }
  
  console.log('系统概览详情页面加载完成')
})

// 组件卸载时清理事件监听器
onUnmounted(() => {
  const nodes = document.querySelectorAll('.map-node')
  nodes.forEach(node => {
    node.removeEventListener('mouseenter', showTooltip)
    node.removeEventListener('mousemove', handleTooltipMove)
    node.removeEventListener('mouseleave', hideTooltip)
  })
  
  const mapContainer = document.querySelector('.map-container')
  if (mapContainer) {
    mapContainer.removeEventListener('mousedown', handleMouseDown)
    mapContainer.removeEventListener('mousemove', handleMouseMove)
    mapContainer.removeEventListener('mouseup', handleMouseUp)
    mapContainer.removeEventListener('mouseleave', handleMouseUp)
    mapContainer.removeEventListener('wheel', handleWheel)
  }
})
</script>

<style scoped>
.system-overview-detail {
  width: 100%;
  height: 100vh;
  display: flex;
  flex-direction: column;
  background-color: #0F172A;
  color: #FFFFFF;
}

/* 顶部通栏 */
.top-bar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0 30px;
  height: 70px;
  background-color: rgba(15, 23, 42, 0.95);
  border-bottom: 1px solid rgba(255, 255, 255, 0.1);
  backdrop-filter: blur(10px);
}

.logo-section {
  display: flex;
  flex-direction: column;
}

.logo {
  font-size: 20px;
  font-weight: 600;
  color: #06B6D4;
}

.breadcrumb {
  font-size: 12px;
  color: rgba(255, 255, 255, 0.6);
  margin-top: 2px;
}

.top-controls {
  display: flex;
  align-items: center;
  gap: 16px;
}

.btn-back, .btn-refresh {
  padding: 8px 16px;
  border: 1px solid rgba(255, 255, 255, 0.3);
  background-color: rgba(255, 255, 255, 0.1);
  color: #FFFFFF;
  border-radius: 6px;
  cursor: pointer;
  transition: all 0.3s ease;
}

.btn-back:hover, .btn-refresh:hover {
  background-color: rgba(6, 182, 212, 0.2);
  border-color: #06B6D4;
}

.system-status {
  display: flex;
  align-items: center;
  gap: 8px;
}

.status-indicator {
  width: 8px;
  height: 8px;
  border-radius: 50%;
}

.status-indicator.online {
  background-color: #10B981;
  box-shadow: 0 0 10px rgba(16, 185, 129, 0.5);
}

/* 健康度仪表盘 */
.health-dashboard {
  padding: 24px 30px;
  background-color: rgba(15, 23, 42, 0.7);
  border-bottom: 1px solid rgba(255, 255, 255, 0.1);
}

.dashboard-title {
  font-size: 18px;
  font-weight: 600;
  margin-bottom: 20px;
  color: #FFFFFF;
}

.health-score {
  display: flex;
  align-items: center;
  gap: 40px;
}

.score-circle {
  width: 120px;
  height: 120px;
  border-radius: 50%;
  background: conic-gradient(#06B6D4 0deg 331.2deg, rgba(255, 255, 255, 0.1) 331.2deg 360deg);
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  position: relative;
}

.score-circle::before {
  content: '';
  position: absolute;
  width: 100px;
  height: 100px;
  border-radius: 50%;
  background-color: #0F172A;
}

.score-value {
  font-size: 32px;
  font-weight: 700;
  color: #06B6D4;
  z-index: 1;
}

.score-label {
  font-size: 12px;
  color: rgba(255, 255, 255, 0.6);
  z-index: 1;
  margin-top: 4px;
}

.health-items {
  display: flex;
  gap: 30px;
  flex: 1;
}

.health-item {
  flex: 1;
  padding: 16px;
  background-color: rgba(255, 255, 255, 0.05);
  border-radius: 8px;
  border: 1px solid rgba(255, 255, 255, 0.1);
  transition: all 0.3s ease;
}

.health-item:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(6, 182, 212, 0.15);
}

.health-item.healthy {
  border-color: rgba(16, 185, 129, 0.5);
}

.health-item-title {
  font-size: 14px;
  color: rgba(255, 255, 255, 0.8);
  margin-bottom: 8px;
}

.health-item-value {
  font-size: 24px;
  font-weight: 700;
  color: #06B6D4;
  margin-bottom: 4px;
}

.health-item-status {
  font-size: 12px;
  color: #10B981;
}

/* 主内容区域 */
.main-content-area {
  display: flex;
  flex: 1;
  padding: 24px 30px;
  gap: 24px;
  overflow: hidden;
}

.left-section {
  flex: 2;
  display: flex;
  flex-direction: column;
  gap: 24px;
  overflow-y: auto;
}

.right-section {
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: 24px;
  overflow-y: auto;
}

.section-card {
  background-color: rgba(15, 23, 42, 0.7);
  border-radius: 12px;
  border: 1px solid rgba(255, 255, 255, 0.1);
  padding: 20px;
  backdrop-filter: blur(10px);
}

.section-title {
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-size: 16px;
  font-weight: 600;
  margin-bottom: 16px;
  color: #FFFFFF;
}

.btn-expand {
  background: none;
  border: none;
  color: rgba(255, 255, 255, 0.6);
  font-size: 12px;
  cursor: pointer;
  transition: color 0.3s ease;
}

.btn-expand:hover {
  color: #06B6D4;
}

/* 矿井拓扑地图 */
.map-container {
  min-height: 300px;
  height: 100%;
  background-color: rgba(255, 255, 255, 0.05);
  border-radius: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  overflow: hidden;
}

.mine-topology-map {
  transition: transform 0.3s ease;
}

.mine-topology-map:hover {
  transform: scale(1.02);
}

/* 机器人状态指示器 */
.robot-indicator {
  cursor: pointer;
  transition: all 0.3s ease;
}

.robot-indicator:hover {
  filter: brightness(1.2);
  transform: scale(1.1);
}

/* 系统路径动画 */
@keyframes pulse-flow {
  0% {
    opacity: 0.3;
  }
  50% {
    opacity: 1;
  }
  100% {
    opacity: 0.3;
  }
}

.system-path {
  animation: pulse-flow 3s infinite;
}

/* 地图节点悬停效果 */
.map-node {
  cursor: pointer;
  transition: all 0.3s ease;
}

.map-node:hover {
  filter: brightness(1.2);
  transform: scale(1.02);
}

/* 信息提示框 */
.info-tooltip {
  pointer-events: none;
  z-index: 1000;
  position: relative;
}

.info-tooltip rect {
  backdrop-filter: blur(10px);
}

/* 展开状态 */
.mine-map.expanded .map-container {
  height: 600px;
}

.mine-map.expanded .mine-topology-map {
  transform: scale(1.5);
  transition: transform 0.5s ease;
}

.mine-map.expanded .btn-expand {
  color: #06B6D4;
}

.mine-map.expanded .btn-expand::after {
  content: ' (收起)';
  font-size: 10px;
}

/* 系统节点特殊样式 */
.system-node:hover path {
  stroke-width: 2;
}

/* 机器人节点特殊样式 */
.robot-indicator:hover circle {
  r: 10;
  filter: drop-shadow(0 0 5px currentColor);
}

.map-placeholder {
  text-align: center;
  color: rgba(255, 255, 255, 0.6);
}

.map-icon {
  font-size: 48px;
  margin-bottom: 12px;
}

.map-text {
  font-size: 16px;
  margin-bottom: 8px;
}

.map-info {
  font-size: 12px;
}

/* 五层架构流程图 */
.flow-container {
  display: flex;
  align-items: center;
  justify-content: space-between;
  flex-wrap: wrap;
  gap: 16px;
  padding: 20px 0;
}

.flow-item {
  flex: 1;
  min-width: 120px;
  padding: 16px;
  background-color: rgba(255, 255, 255, 0.05);
  border-radius: 8px;
  text-align: center;
  transition: all 0.3s ease;
}

.flow-item:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(6, 182, 212, 0.15);
}

.flow-item.sensing {
  border-left: 4px solid #06B6D4;
}

.flow-item.data {
  border-left: 4px solid #3B82F6;
}

.flow-item.model {
  border-left: 4px solid #10B981;
}

.flow-item.decision {
  border-left: 4px solid #F59E0B;
}

.flow-item.execution {
  border-left: 4px solid #EC4899;
}

.flow-icon {
  font-size: 24px;
  margin-bottom: 8px;
}

.flow-title {
  font-size: 14px;
  font-weight: 500;
  margin-bottom: 4px;
  color: #FFFFFF;
}

.flow-status {
  font-size: 12px;
  color: #10B981;
}

.flow-arrow {
  font-size: 20px;
  color: rgba(255, 255, 255, 0.4);
  margin: 0 8px;
}

/* 核心数据指标看板 */
.metrics-grid {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 16px;
}

.metric-item {
  padding: 16px;
  background-color: rgba(255, 255, 255, 0.05);
  border-radius: 8px;
  text-align: center;
  transition: all 0.3s ease;
}

.metric-item:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(6, 182, 212, 0.15);
}

.metric-title {
  font-size: 12px;
  color: rgba(255, 255, 255, 0.8);
  margin-bottom: 8px;
}

.metric-value {
  font-size: 24px;
  font-weight: 700;
  color: #06B6D4;
  margin-bottom: 4px;
}

.metric-value.warning {
  color: #F59E0B;
  animation: pulse 2s infinite;
}

.metric-unit {
  font-size: 12px;
  color: rgba(255, 255, 255, 0.6);
}

/* 实时预警列表 */
.alerts-count {
  background-color: #EF4444;
  color: #FFFFFF;
  font-size: 12px;
  padding: 2px 8px;
  border-radius: 10px;
  font-weight: 500;
}

.alerts-container {
  max-height: 300px;
  overflow-y: auto;
}

.alert-item {
  display: flex;
  align-items: flex-start;
  gap: 12px;
  padding: 12px;
  background-color: rgba(255, 255, 255, 0.05);
  border-radius: 8px;
  margin-bottom: 12px;
  border-left: 4px solid transparent;
  transition: all 0.3s ease;
}

.alert-item:hover {
  background-color: rgba(255, 255, 255, 0.08);
}

.alert-item.high {
  border-left-color: #EF4444;
  background-color: rgba(239, 68, 68, 0.1);
}

.alert-item.medium {
  border-left-color: #F59E0B;
  background-color: rgba(245, 158, 11, 0.1);
}

.alert-item.low {
  border-left-color: #10B981;
  background-color: rgba(16, 185, 129, 0.1);
}

.alert-icon {
  font-size: 20px;
  margin-top: 2px;
}

.alert-content {
  flex: 1;
}

.alert-title {
  font-size: 14px;
  font-weight: 500;
  color: #FFFFFF;
  margin-bottom: 4px;
}

.alert-description {
  font-size: 12px;
  color: rgba(255, 255, 255, 0.7);
  margin-bottom: 8px;
}

.alert-time {
  font-size: 10px;
  color: rgba(255, 255, 255, 0.5);
}

.alert-actions {
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.btn-detail, .btn-handle {
  padding: 4px 8px;
  font-size: 10px;
  border-radius: 4px;
  border: none;
  cursor: pointer;
  transition: all 0.3s ease;
}

.btn-detail {
  background-color: rgba(6, 182, 212, 0.2);
  color: #06B6D4;
}

.btn-handle {
  background-color: rgba(16, 185, 129, 0.2);
  color: #10B981;
}

.btn-detail:hover, .btn-handle:hover {
  opacity: 0.8;
}

/* AI模型状态 */
.ai-models {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.ai-model-item {
  padding: 12px;
  background-color: rgba(255, 255, 255, 0.05);
  border-radius: 8px;
  transition: all 0.3s ease;
}

.ai-model-item:hover {
  background-color: rgba(255, 255, 255, 0.08);
}

.ai-model-name {
  font-size: 14px;
  font-weight: 500;
  color: #FFFFFF;
  margin-bottom: 4px;
}

.ai-model-status {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 12px;
  margin-bottom: 4px;
}

.status-dot {
  width: 8px;
  height: 8px;
  border-radius: 50%;
}

.ai-model-status.active .status-dot {
  background-color: #10B981;
  box-shadow: 0 0 8px rgba(16, 185, 129, 0.5);
}

.ai-model-status.active span {
  color: #10B981;
}

.ai-model-accuracy {
  font-size: 12px;
  color: rgba(255, 255, 255, 0.7);
}

/* 底部状态栏 */
.bottom-status-bar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0 30px;
  height: 40px;
  background-color: rgba(15, 23, 42, 0.95);
  border-top: 1px solid rgba(255, 255, 255, 0.1);
  backdrop-filter: blur(10px);
}

.status-item {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 12px;
}

.status-label {
  color: rgba(255, 255, 255, 0.6);
}

.status-value {
  color: #FFFFFF;
  font-weight: 500;
}

/* 动画效果 */
@keyframes pulse {
  0%, 100% {
    opacity: 1;
  }
  50% {
    opacity: 0.6;
  }
}

/* 响应式设计 */
@media (max-width: 1200px) {
  .health-score {
    flex-direction: column;
    align-items: flex-start;
    gap: 24px;
  }
  
  .health-items {
    width: 100%;
  }
  
  .main-content-area {
    flex-direction: column;
  }
  
  .left-section, .right-section {
    flex: none;
  }
  
  .flow-container {
    flex-direction: column;
    align-items: stretch;
  }
  
  .flow-arrow {
    transform: rotate(90deg);
    margin: 8px 0;
  }
}

@media (max-width: 768px) {
  .top-bar {
    padding: 0 15px;
  }
  
  .health-dashboard {
    padding: 16px 15px;
  }
  
  .main-content-area {
    padding: 16px 15px;
    gap: 16px;
  }
  
  .section-card {
    padding: 16px;
  }
  
  .metrics-grid {
    grid-template-columns: 1fr;
  }
  
  .bottom-status-bar {
    padding: 0 15px;
    flex-wrap: wrap;
    height: auto;
    padding: 8px 15px;
    gap: 8px;
  }
  
  .status-item {
    flex: 1;
    min-width: 150px;
  }
}

/* 滚动条样式 */
::-webkit-scrollbar {
  width: 6px;
}

::-webkit-scrollbar-track {
  background: rgba(255, 255, 255, 0.05);
  border-radius: 3px;
}

::-webkit-scrollbar-thumb {
  background: rgba(255, 255, 255, 0.2);
  border-radius: 3px;
}

::-webkit-scrollbar-thumb:hover {
  background: rgba(255, 255, 255, 0.3);
}
</style>