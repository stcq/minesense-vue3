<template>
  <div class="model-layer-detail">
    <!-- 顶部标题和返回按钮 -->
    <div class="top-header">
      <h1 class="section-title">模型层・参数设置与训练</h1>
      <button class="btn-back" @click="handleBack">返回</button>
    </div>

    <!-- 主内容区 -->
    <div class="main-content">
      <!-- 核心操作区 -->
      <div class="core-operation-area">
        <h2 class="area-title">核心操作区</h2>
        
        <!-- 基础配置 -->
        <div class="config-section">
          <h3 class="section-subtitle">基础配置</h3>
          <div class="config-grid">
            <!-- 模型 + 任务双选下拉 -->
            <div class="config-item">
              <label>模型与任务</label>
              <select v-model="modelConfig.modelType" class="select-input">
                <option value="model1">模型1 (分类/回归/时序预测)</option>
                <option value="model2">模型2 (分类/回归/时序预测)</option>
                <option value="model3">模型3 (分类/回归)</option>
              </select>
            </div>
            
            <!-- 数据集选择 -->
            <div class="config-item">
              <label>数据集版本</label>
              <select v-model="modelConfig.datasetVersion" class="select-input">
                <option value="v1.0">v1.0 (10,000 样本)</option>
                <option value="v1.1">v1.1 (12,500 样本)</option>
                <option value="v2.0">v2.0 (15,000 样本)</option>
              </select>
            </div>
            
            <!-- 数据集划分 -->
            <div class="config-item">
              <label>数据集划分</label>
              <div class="split-config">
                <input type="number" v-model.number="modelConfig.trainSplit" min="0" max="100" class="number-input">
                <span>:</span>
                <input type="number" v-model.number="modelConfig.valSplit" min="0" max="100" class="number-input">
                <span>:</span>
                <input type="number" v-model.number="modelConfig.testSplit" min="0" max="100" class="number-input">
              </div>
            </div>
            
            <!-- 数据导入 -->
            <div class="config-item">
              <label>数据导入</label>
              <div class="file-upload">
                <input type="file" id="data-upload" class="file-input" @change="handleDataUpload">
                <label for="data-upload" class="file-label">
                  {{ uploadedDataFile ? uploadedDataFile.name : '选择数据文件' }}
                </label>
              </div>
            </div>
            
            <!-- 模型文件导入 -->
            <div class="config-item">
              <label>模型文件导入</label>
              <div class="file-upload">
                <input type="file" id="model-upload" class="file-input" @change="handleModelUpload">
                <label for="model-upload" class="file-label">
                  {{ uploadedModelFile ? uploadedModelFile.name : '选择模型文件' }}
                </label>
              </div>
            </div>
          </div>
        </div>

        <!-- 关键参数调试 -->
        <div class="params-section">
          <h3 class="section-subtitle">关键参数调试</h3>
          
          <!-- 标签页 -->
          <div class="tabs">
            <button class="tab-btn" :class="{ active: activeTab === 'general' }" @click="activeTab = 'general'">通用训练参数</button>
            <button class="tab-btn" :class="{ active: activeTab === 'model' }" @click="activeTab = 'model'">模型结构参数</button>
          </div>

          <!-- 通用训练参数 -->
          <div class="tab-content" v-if="activeTab === 'general'">
            <div class="params-grid">
              <div class="param-item">
                <div class="label-with-tooltip">
                  <label>批次大小</label>
                  <div class="tooltip-icon" @click="toggleTooltip('batchSize')">i</div>
                  <div class="tooltip-content" v-if="showTooltips.batchSize">
                    批次大小决定了每次训练时同时处理的样本数量。较大的批次可以利用并行计算提高训练速度，但会占用更多显存。
                  </div>
                </div>
                <select v-model="modelConfig.batchSize" class="select-input">
                  <option value="32">32</option>
                  <option value="64">64</option>
                  <option value="128">128</option>
                </select>
                <div class="param-hint">显存预估: {{ getMemoryEstimate() }}</div>
              </div>
              
              <div class="param-item">
                <div class="label-with-tooltip">
                  <label>学习率</label>
                  <div class="tooltip-icon" @click="toggleTooltip('learningRate')">i</div>
                  <div class="tooltip-content" v-if="showTooltips.learningRate">
                    学习率控制模型参数更新的步长。过大的学习率可能导致训练不稳定，过小的学习率可能导致训练速度过慢。
                  </div>
                </div>
                <input type="number" v-model.number="modelConfig.learningRate" step="0.0001" class="number-input">
              </div>
              
              <div class="param-item">
                <div class="label-with-tooltip">
                  <label>学习率衰减</label>
                  <div class="tooltip-icon" @click="toggleTooltip('lrDecay')">i</div>
                  <div class="tooltip-content" v-if="showTooltips.lrDecay">
                    学习率衰减策略用于在训练过程中逐渐减小学习率，有助于模型收敛到更好的结果。余弦衰减是平滑的衰减方式，阶梯衰减是在特定轮次突然减小学习率。
                  </div>
                </div>
                <select v-model="modelConfig.lrDecay" class="select-input">
                  <option value="cosine">余弦衰减</option>
                  <option value="step">阶梯衰减</option>
                </select>
              </div>
              
              <div class="param-item">
                <div class="label-with-tooltip">
                  <label>训练轮数</label>
                  <div class="tooltip-icon" @click="toggleTooltip('epochs')">i</div>
                  <div class="tooltip-content" v-if="showTooltips.epochs">
                    训练轮数是指模型在整个训练数据集上训练的次数。增加轮数可以提高模型性能，但可能导致过拟合。
                  </div>
                </div>
                <input type="number" v-model.number="modelConfig.epochs" min="1" class="number-input">
              </div>
              
              <div class="param-item">
                <div class="label-with-tooltip">
                  <label>早停阈值</label>
                  <div class="tooltip-icon" @click="toggleTooltip('earlyStopping')">i</div>
                  <div class="tooltip-content" v-if="showTooltips.earlyStopping">
                    早停机制在验证集性能不再改善时停止训练，防止过拟合并节省训练时间。
                  </div>
                </div>
                <div class="toggle-switch">
                  <input type="checkbox" v-model="modelConfig.earlyStopping" id="earlyStopping">
                  <label for="earlyStopping"></label>
                </div>
              </div>
              
              <div class="param-item">
                <div class="label-with-tooltip">
                  <label>优化器</label>
                  <div class="tooltip-icon" @click="toggleTooltip('optimizer')">i</div>
                  <div class="tooltip-content" v-if="showTooltips.optimizer">
                    优化器决定了如何根据损失函数更新模型参数。Adam是最常用的优化器，结合了动量和自适应学习率；SGD是基础优化器；RMSprop适用于处理非平稳目标函数。
                  </div>
                </div>
                <select v-model="modelConfig.optimizer" class="select-input">
                  <option value="adam">Adam</option>
                  <option value="sgd">SGD</option>
                  <option value="rmsprop">RMSprop</option>
                </select>
              </div>
              
              <div class="param-item">
                <div class="label-with-tooltip">
                  <label>损失函数</label>
                  <div class="tooltip-icon" @click="toggleTooltip('lossFunction')">i</div>
                  <div class="tooltip-content" v-if="showTooltips.lossFunction">
                    损失函数衡量模型预测与真实值之间的差距。MSE适用于回归任务，MAE对异常值不敏感，交叉熵适用于分类任务。
                  </div>
                </div>
                <select v-model="modelConfig.lossFunction" class="select-input">
                  <option value="mse">均方误差 (MSE)</option>
                  <option value="mae">平均绝对误差 (MAE)</option>
                  <option value="crossentropy">交叉熵</option>
                </select>
              </div>
            </div>
          </div>

          <!-- 模型结构参数 -->
          <div class="tab-content" v-else-if="activeTab === 'model'">
            <div class="params-grid">
              <div class="param-item">
                <div class="label-with-tooltip">
                  <label>卷积核数</label>
                  <div class="tooltip-icon" @click="toggleTooltip('convFilters')">i</div>
                  <div class="tooltip-content" v-if="showTooltips.convFilters">
                    卷积核数决定了模型可以提取的特征数量。更多的卷积核可以提取更丰富的特征，但会增加模型复杂度和计算量。
                  </div>
                </div>
                <input type="number" v-model.number="modelConfig.convFilters" min="16" max="256" step="16" class="number-input">
              </div>
              
              <div class="param-item">
                <div class="label-with-tooltip">
                  <label>LSTM 隐藏层维度</label>
                  <div class="tooltip-icon" @click="toggleTooltip('lstmUnits')">i</div>
                  <div class="tooltip-content" v-if="showTooltips.lstmUnits">
                    LSTM隐藏层维度决定了模型可以捕获的时间依赖关系的复杂度。较大的维度可以捕获更复杂的模式，但会增加计算量和过拟合风险。
                  </div>
                </div>
                <input type="number" v-model.number="modelConfig.lstmUnits" min="32" max="512" step="32" class="number-input">
              </div>
              
              <div class="param-item">
                <div class="label-with-tooltip">
                  <label>Dropout 率</label>
                  <div class="tooltip-icon" @click="toggleTooltip('dropoutRate')">i</div>
                  <div class="tooltip-content" v-if="showTooltips.dropoutRate">
                    Dropout率用于防止过拟合，通过在训练过程中随机丢弃部分神经元来减少模型对训练数据的依赖。
                  </div>
                </div>
                <input type="number" v-model.number="modelConfig.dropoutRate" min="0" max="1" step="0.1" class="number-input">
              </div>
              
              <div class="param-item">
                <div class="label-with-tooltip">
                  <label>融合层维度</label>
                  <div class="tooltip-icon" @click="toggleTooltip('fusionDim')">i</div>
                  <div class="tooltip-content" v-if="showTooltips.fusionDim">
                    融合层维度决定了多模态特征融合的容量。合适的维度可以有效地整合不同来源的特征信息。
                  </div>
                </div>
                <input type="number" v-model.number="modelConfig.fusionDim" min="64" max="256" step="32" class="number-input">
              </div>
              
              <div class="param-item">
                <div class="label-with-tooltip">
                  <label>预警等级权重</label>
                  <div class="tooltip-icon" @click="toggleTooltip('warningWeight')">i</div>
                  <div class="tooltip-content" v-if="showTooltips.warningWeight">
                    预警等级权重用于调整模型对不同预警等级的重视程度。较高的权重会使模型更关注高风险样本。
                  </div>
                </div>
                <input type="number" v-model.number="modelConfig.warningWeight" min="1" max="10" step="0.5" class="number-input">
              </div>
              
              <div class="param-item">
                <div class="label-with-tooltip">
                  <label>多模态特征权重</label>
                  <div class="tooltip-icon" @click="toggleTooltip('modalWeight')">i</div>
                  <div class="tooltip-content" v-if="showTooltips.modalWeight">
                    多模态特征权重用于调整不同模态特征在融合过程中的重要性。
                  </div>
                </div>
                <input type="number" v-model.number="modelConfig.modalWeight" min="0" max="1" step="0.1" class="number-input">
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- 训练监控区 -->
      <div class="training-monitor-area">
        <h2 class="area-title">训练监控区</h2>
        
        <!-- 实时可视化面板 -->
        <div class="visualization-panel">
          <h3 class="section-subtitle">训练曲线</h3>
          <div class="line-chart">
            <div class="chart-header">
              <div class="chart-legend">
                <span class="legend-item">
                  <span class="legend-color accuracy"></span>
                  <span>准确率</span>
                </span>
                <span class="legend-item">
                  <span class="legend-color loss"></span>
                  <span>损失</span>
                </span>
              </div>
            </div>
            <div class="chart-content">
              <div class="chart-grid">
                <div v-for="i in 5" :key="'grid-' + i" class="grid-line"></div>
              </div>
              <div class="chart-lines">
                <!-- 准确率折线 -->
                <div class="chart-line accuracy">
                  <div v-for="(history, index) in trainingHistory" :key="'accuracy-' + index" class="chart-point" :style="{
                    left: (index / (trainingHistory.length - 1)) * 100 + '%',
                    bottom: history.accuracy + '%'
                  }">
                    <div class="point-tooltip">{{ history.accuracy }}%</div>
                  </div>
                  <svg class="line-path" width="100%" height="100%">
                    <polyline :points="getAccuracyPoints()" fill="none" stroke="#06B6D4" stroke-width="2" />
                  </svg>
                </div>
                <!-- 损失折线 -->
                <div class="chart-line loss">
                  <div v-for="(history, index) in trainingHistory" :key="'loss-' + index" class="chart-point" :style="{
                    left: (index / (trainingHistory.length - 1)) * 100 + '%',
                    bottom: (1 - history.loss) * 100 + '%'
                  }">
                    <div class="point-tooltip">{{ history.loss }}</div>
                  </div>
                  <svg class="line-path" width="100%" height="100%">
                    <polyline :points="getLossPoints()" fill="none" stroke="#F59E0B" stroke-width="2" />
                  </svg>
                </div>
              </div>
            </div>
            <div class="chart-axis">
              <div class="x-axis">
                <div v-for="(history, index) in trainingHistory" :key="'x-axis-' + index" class="axis-label">
                  {{ history.name.substring(4) }}
                </div>
              </div>
              <div class="y-axis">
                <div v-for="i in 5" :key="'y-axis-' + i" class="axis-label">
                  {{ 100 - (i - 1) * 20 }}%
                </div>
              </div>
            </div>
          </div>
          
          <div class="progress-section">
            <div class="progress-bar">
              <div class="progress-fill" :style="{ width: trainingProgress + '%' }"></div>
            </div>
            <div class="progress-info">
              <span>进度: {{ trainingProgress }}%</span>
              <span>剩余时间: {{ remainingTime }}</span>
            </div>
          </div>
        </div>

        <!-- 关键数值卡片 -->
        <div class="metrics-cards">
          <div class="metric-card">
            <div class="metric-label">当前轮次</div>
            <div class="metric-value">{{ currentEpoch }}</div>
          </div>
          <div class="metric-card">
            <div class="metric-label">最优指标</div>
            <div class="metric-value">{{ bestMetric }}</div>
          </div>
          <div class="metric-card">
            <div class="metric-label">GPU 使用率</div>
            <div class="metric-value">{{ gpuUsage }}%</div>
          </div>
          <div class="metric-card">
            <div class="metric-label">显存占用</div>
            <div class="metric-value">{{ memoryUsage }}MB</div>
          </div>
        </div>

        <!-- 日志输出 -->
        <div class="log-section">
          <h3 class="section-subtitle">训练日志</h3>
          <div class="log-container">
            <div class="log-item" v-for="(log, index) in logs" :key="index">
              <span class="log-time">{{ log.time }}</span>
              <span class="log-message">{{ log.message }}</span>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- 功能操作区 -->
    <div class="function-operation-area">
      <h2 class="area-title">功能操作区</h2>
      <div class="operation-buttons">
        <button class="btn-primary" @click="toggleTraining">{{ isTraining ? '暂停训练' : '开始训练' }}</button>
        <button class="btn-secondary" @click="stopTraining">终止训练</button>
        <button class="btn-secondary" @click="saveParams">保存参数</button>
        <button class="btn-secondary" @click="loadParams">加载参数</button>
        <button class="btn-secondary" @click="exportModel" v-if="trainingCompleted">导出模型</button>
        <button class="btn-secondary" @click="exportMetrics" v-if="trainingCompleted">导出指标</button>
      </div>
    </div>

    <!-- 轻量化辅助区 -->
    <div class="lightweight-auxiliary-area">
      <div class="auxiliary-section">
        <div class="section-header" @click="toggleHistory">
          <h3 class="section-subtitle">历史训练记录</h3>
          <span class="toggle-icon">{{ showHistory ? '▼' : '▶' }}</span>
        </div>
        <div class="section-content" v-if="showHistory">
          <div class="history-item" v-for="(history, index) in trainingHistory" :key="index">
            <div class="history-header">
              <span class="history-name">{{ history.name }}</span>
              <span class="history-status" :class="history.status">{{ history.status }}</span>
            </div>
            <div class="history-metrics">
              <span>准确率: {{ history.accuracy }}%</span>
              <span>损失: {{ history.loss }}</span>
            </div>
          </div>
        </div>
      </div>

      <div class="auxiliary-section">
        <div class="section-header" @click="toggleOverview">
          <h3 class="section-subtitle">训练结果概览</h3>
          <span class="toggle-icon">{{ showOverview ? '▼' : '▶' }}</span>
        </div>
        <div class="section-content" v-if="showOverview && trainingCompleted">
          <div class="overview-item">
            <div class="overview-label">最优准确率</div>
            <div class="overview-value">{{ bestAccuracy }}%</div>
          </div>
          <div class="overview-item">
            <div class="overview-label">最优损失</div>
            <div class="overview-value">{{ bestLoss }}</div>
          </div>
          <div class="overview-item">
            <div class="overview-label">训练时间</div>
            <div class="overview-value">{{ trainingTime }}</div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue'

const emit = defineEmits(['back'])

// 状态管理
const activeTab = ref('general')
const isTraining = ref(false)
const trainingProgress = ref(0)
const trainingCompleted = ref(false)
const showHistory = ref(false)
const showOverview = ref(false)
const uploadedDataFile = ref(null)
const uploadedModelFile = ref(null)
const showTooltips = ref({
  batchSize: false,
  learningRate: false,
  lrDecay: false,
  epochs: false,
  earlyStopping: false,
  optimizer: false,
  lossFunction: false,
  convFilters: false,
  lstmUnits: false,
  dropoutRate: false,
  fusionDim: false,
  warningWeight: false,
  modalWeight: false
})

// 模型配置
const modelConfig = ref({
  modelType: 'model1',
  datasetVersion: 'v1.0',
  trainSplit: 70,
  valSplit: 20,
  testSplit: 10,
  batchSize: 64,
  learningRate: 0.001,
  lrDecay: 'cosine',
  epochs: 50,
  earlyStopping: true,
  optimizer: 'adam',
  lossFunction: 'mse',
  convFilters: 64,
  lstmUnits: 128,
  dropoutRate: 0.3,
  fusionDim: 128,
  warningWeight: 3,
  modalWeight: 0.7
})

// 训练状态
const currentEpoch = ref(0)
const bestMetric = ref(0)
const gpuUsage = ref(0)
const memoryUsage = ref(0)
const remainingTime = ref('00:00:00')

// 训练历史
const trainingHistory = ref([
  { name: '训练任务 1', status: 'completed', accuracy: 92.5, loss: 0.08 },
  { name: '训练任务 2', status: 'completed', accuracy: 94.2, loss: 0.06 },
  { name: '训练任务 3', status: 'failed', accuracy: 88.7, loss: 0.12 },
  { name: '训练任务 4', status: 'completed', accuracy: 95.1, loss: 0.05 },
  { name: '训练任务 5', status: 'running', accuracy: 0, loss: 0 }
])

// 训练结果
const bestAccuracy = ref(0)
const bestLoss = ref(0)
const trainingTime = ref('00:00:00')

// 日志
const logs = ref([
  { time: '14:30:00', message: '初始化模型...' },
  { time: '14:30:05', message: '加载数据集...' },
  { time: '14:30:10', message: '开始训练...' }
])

// 方法
function handleBack() {
  emit('back')
}

function toggleTraining() {
  isTraining.value = !isTraining.value
  if (isTraining.value) {
    startTraining()
  }
}

function stopTraining() {
  isTraining.value = false
  trainingProgress.value = 0
}

function startTraining() {
  // 初始化训练状态
  currentEpoch.value = 0
  bestMetric.value = 0
  gpuUsage.value = 0
  memoryUsage.value = 0
  remainingTime.value = '00:15:00'
  
  // 模拟训练过程
  const interval = setInterval(() => {
    if (!isTraining.value) {
      clearInterval(interval)
      return
    }
    
    trainingProgress.value += 1
    
    // 模拟训练过程中的状态变化
    if (trainingProgress.value % 10 === 0) {
      // 每10%进度更新一次状态
      currentEpoch.value += Math.floor(Math.random() * 5) + 1
      bestMetric.value = Math.min(95, bestMetric.value + Math.random() * 2)
      gpuUsage.value = Math.floor(Math.random() * 30) + 70 // 70-100%
      memoryUsage.value = Math.floor(Math.random() * 2000) + 6000 // 6000-8000MB
      
      // 更新剩余时间
      const minutes = Math.floor((100 - trainingProgress.value) * 900 / 100 / 60)
      const seconds = Math.floor((100 - trainingProgress.value) * 900 / 100 % 60)
      remainingTime.value = `00:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`
      
      // 添加训练日志
      logs.value.push({ time: new Date().toLocaleTimeString(), message: `训练进度: ${trainingProgress.value}%, 当前轮次: ${currentEpoch.value}, 准确率: ${bestMetric.value.toFixed(1)}%` })
    }
    
    if (trainingProgress.value >= 100) {
      clearInterval(interval)
      isTraining.value = false
      trainingCompleted.value = true
      
      // 训练完成时的最终状态
      currentEpoch.value = 50
      bestMetric.value = 95.6
      gpuUsage.value = 95
      memoryUsage.value = 7500
      remainingTime.value = '00:00:00'
      
      bestAccuracy.value = 95.6
      bestLoss.value = 0.04
      trainingTime.value = '01:23:45'
      logs.value.push({ time: new Date().toLocaleTimeString(), message: '训练完成！' })
    }
  }, 100)
}

function saveParams() {
  // 模拟保存参数
  logs.value.push({ time: new Date().toLocaleTimeString(), message: '参数保存成功！' })
}

function loadParams() {
  // 模拟加载参数
  logs.value.push({ time: new Date().toLocaleTimeString(), message: '参数加载成功！' })
}

function exportModel() {
  // 模拟导出模型
  logs.value.push({ time: new Date().toLocaleTimeString(), message: '模型导出成功！' })
}

function exportMetrics() {
  // 模拟导出指标
  logs.value.push({ time: new Date().toLocaleTimeString(), message: '指标导出成功！' })
}

function toggleHistory() {
  showHistory.value = !showHistory.value
}

function toggleOverview() {
  showOverview.value = !showOverview.value
}

function handleDataUpload(event) {
  const file = event.target.files[0]
  if (file) {
    uploadedDataFile.value = file
    logs.value.push({ time: new Date().toLocaleTimeString(), message: `数据文件上传成功: ${file.name}` })
  }
}

function handleModelUpload(event) {
  const file = event.target.files[0]
  if (file) {
    uploadedModelFile.value = file
    logs.value.push({ time: new Date().toLocaleTimeString(), message: `模型文件上传成功: ${file.name}` })
  }
}

function toggleTooltip(param) {
  showTooltips.value[param] = !showTooltips.value[param]
}

function getMemoryEstimate() {
  // 模拟显存预估
  const batchSize = modelConfig.value.batchSize
  if (batchSize === 32) return '约 2GB'
  if (batchSize === 64) return '约 4GB'
  if (batchSize === 128) return '约 8GB'
  return '未知'
}

function getAccuracyPoints() {
  // 生成准确率折线的SVG路径点
  return trainingHistory.value.map((history, index) => {
    const x = (index / (trainingHistory.value.length - 1)) * 100
    const y = 100 - history.accuracy
    return `${x},${y}`
  }).join(' ')
}

function getLossPoints() {
  // 生成损失折线的SVG路径点
  return trainingHistory.value.map((history, index) => {
    const x = (index / (trainingHistory.value.length - 1)) * 100
    const y = history.loss * 100
    return `${x},${y}`
  }).join(' ')
}
</script>

<style scoped>
.model-layer-detail {
  width: 100%;
  height: 100vh;
  display: flex;
  flex-direction: column;
  background-color: #0F172A;
  color: #FFFFFF;
  overflow-y: auto;
  padding: 20px;
  box-sizing: border-box;
}

.top-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
}

.section-title {
  font-size: 20px;
  font-weight: 600;
  color: #06B6D4;
  margin: 0;
}

.btn-back {
  padding: 8px 16px;
  background-color: rgba(255, 255, 255, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.3);
  color: #FFFFFF;
  border-radius: 6px;
  cursor: pointer;
  transition: all 0.3s ease;
  font-size: 12px;
}

.btn-back:hover {
  background-color: rgba(6, 182, 212, 0.2);
  border-color: #06B6D4;
}

.main-content {
  display: grid;
  grid-template-columns: 1fr 30%;
  gap: 20px;
  margin-bottom: 20px;
  flex: 1;
}

.core-operation-area {
  background-color: rgba(15, 23, 42, 0.7);
  border-radius: 8px;
  border: 1px solid rgba(255, 255, 255, 0.1);
  padding: 20px;
  display: flex;
  flex-direction: column;
  gap: 20px;
}

.training-monitor-area {
  background-color: rgba(15, 23, 42, 0.7);
  border-radius: 8px;
  border: 1px solid rgba(255, 255, 255, 0.1);
  padding: 20px;
  display: flex;
  flex-direction: column;
  gap: 20px;
}

.area-title {
  font-size: 16px;
  font-weight: 600;
  color: #FFFFFF;
  margin: 0 0 15px 0;
}

.section-subtitle {
  font-size: 14px;
  font-weight: 600;
  color: #06B6D4;
  margin: 0 0 10px 0;
}

.config-grid {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 15px;
}

.config-item {
  display: flex;
  flex-direction: column;
  gap: 5px;
}

.config-item label {
  font-size: 12px;
  color: rgba(255, 255, 255, 0.8);
}

.select-input,
.number-input {
  padding: 8px;
  background-color: rgba(255, 255, 255, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.3);
  color: #FFFFFF;
  border-radius: 4px;
  font-size: 12px;
}

.split-config {
  display: flex;
  align-items: center;
  gap: 10px;
}

.split-config input {
  flex: 1;
}

.split-config span {
  color: rgba(255, 255, 255, 0.8);
}

.file-upload {
  position: relative;
  width: 100%;
}

.file-input {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  opacity: 0;
  cursor: pointer;
  z-index: 10;
}

.file-label {
  display: block;
  padding: 8px;
  background-color: rgba(255, 255, 255, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.3);
  color: #FFFFFF;
  border-radius: 4px;
  font-size: 12px;
  text-align: center;
  cursor: pointer;
  transition: all 0.3s ease;
}

.file-label:hover {
  background-color: rgba(6, 182, 212, 0.2);
  border-color: #06B6D4;
}

.label-with-tooltip {
  position: relative;
  display: flex;
  align-items: center;
  gap: 8px;
  margin-bottom: 5px;
}

.tooltip-icon {
  width: 16px;
  height: 16px;
  border-radius: 50%;
  background-color: rgba(6, 182, 212, 0.2);
  color: #06B6D4;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 10px;
  cursor: pointer;
  transition: all 0.3s ease;
}

.tooltip-icon:hover {
  background-color: rgba(6, 182, 212, 0.4);
  transform: scale(1.1);
}

.tooltip-content {
  position: absolute;
  top: 100%;
  left: 0;
  background-color: rgba(0, 0, 0, 0.8);
  color: #FFFFFF;
  padding: 10px;
  border-radius: 4px;
  font-size: 11px;
  width: 250px;
  z-index: 100;
  margin-top: 5px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.3);
  line-height: 1.4;
}

.tooltip-content::before {
  content: '';
  position: absolute;
  top: -5px;
  left: 10px;
  width: 0;
  height: 0;
  border-left: 5px solid transparent;
  border-right: 5px solid transparent;
  border-bottom: 5px solid rgba(0, 0, 0, 0.8);
}

.tabs {
  display: flex;
  gap: 10px;
  margin-bottom: 15px;
}

.tab-btn {
  padding: 8px 16px;
  background-color: rgba(255, 255, 255, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.3);
  color: #FFFFFF;
  border-radius: 4px;
  cursor: pointer;
  transition: all 0.3s ease;
  font-size: 12px;
}

.tab-btn.active {
  background-color: rgba(6, 182, 212, 0.2);
  border-color: #06B6D4;
  color: #06B6D4;
}

.params-grid {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 15px;
}

.param-item {
  display: flex;
  flex-direction: column;
  gap: 5px;
}

.param-item label {
  font-size: 12px;
  color: rgba(255, 255, 255, 0.8);
}

.param-hint {
  font-size: 10px;
  color: rgba(255, 255, 255, 0.5);
  margin-top: 2px;
}

.toggle-switch {
  position: relative;
  width: 40px;
  height: 20px;
}

.toggle-switch input {
  opacity: 0;
  width: 0;
  height: 0;
}

.toggle-switch label {
  position: absolute;
  cursor: pointer;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: rgba(255, 255, 255, 0.1);
  transition: .4s;
  border-radius: 20px;
}

.toggle-switch label:before {
  position: absolute;
  content: "";
  height: 16px;
  width: 16px;
  left: 2px;
  bottom: 2px;
  background-color: white;
  transition: .4s;
  border-radius: 50%;
}

.toggle-switch input:checked + label {
  background-color: #06B6D4;
}

.toggle-switch input:checked + label:before {
  transform: translateX(20px);
}

.visualization-panel {
  background-color: rgba(255, 255, 255, 0.03);
  border-radius: 6px;
  padding: 15px;
  display: flex;
  flex-direction: column;
  gap: 15px;
}

.line-chart {
  height: 200px;
  background-color: rgba(255, 255, 255, 0.03);
  border-radius: 6px;
  padding: 15px;
  display: flex;
  flex-direction: column;
  gap: 10px;
  position: relative;
}

.chart-header {
  display: flex;
  justify-content: flex-end;
}

.chart-legend {
  display: flex;
  gap: 20px;
}

.legend-item {
  display: flex;
  align-items: center;
  gap: 5px;
  font-size: 12px;
  color: rgba(255, 255, 255, 0.8);
}

.legend-color {
  width: 10px;
  height: 10px;
  border-radius: 2px;
}

.legend-color.accuracy {
  background-color: #06B6D4;
}

.legend-color.loss {
  background-color: #F59E0B;
}

.chart-content {
  flex: 1;
  position: relative;
  overflow: hidden;
}

.chart-grid {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  pointer-events: none;
}

.grid-line {
  height: 1px;
  background-color: rgba(255, 255, 255, 0.1);
  width: 100%;
}

.chart-lines {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
}

.chart-line {
  position: relative;
  width: 100%;
  height: 100%;
}

.chart-point {
  position: absolute;
  width: 6px;
  height: 6px;
  border-radius: 50%;
  transform: translate(-50%, 50%);
  cursor: pointer;
  transition: transform 0.2s ease;
}

.chart-point:hover {
  transform: translate(-50%, 50%) scale(1.5);
}

.chart-line.accuracy .chart-point {
  background-color: #06B6D4;
}

.chart-line.loss .chart-point {
  background-color: #F59E0B;
}

.point-tooltip {
  position: absolute;
  bottom: 100%;
  left: 50%;
  transform: translateX(-50%);
  background-color: rgba(0, 0, 0, 0.8);
  color: #FFFFFF;
  padding: 4px 8px;
  border-radius: 4px;
  font-size: 10px;
  white-space: nowrap;
  opacity: 0;
  pointer-events: none;
  transition: opacity 0.3s ease;
  z-index: 10;
  margin-bottom: 5px;
}

.chart-point:hover .point-tooltip {
  opacity: 1;
}

.line-path {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  pointer-events: none;
}

.chart-axis {
  display: flex;
  justify-content: space-between;
  font-size: 10px;
  color: rgba(255, 255, 255, 0.6);
  margin-top: 5px;
}

.x-axis {
  flex: 1;
  display: flex;
  justify-content: space-between;
}

.y-axis {
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  align-items: flex-end;
  height: 100%;
  position: absolute;
  right: 15px;
  top: 15px;
  bottom: 40px;
  pointer-events: none;
}

.axis-label {
  white-space: nowrap;
}

@keyframes pulse {
  0% {
    opacity: 0.6;
  }
  50% {
    opacity: 1;
  }
  100% {
    opacity: 0.6;
  }
}

.progress-section {
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.progress-bar {
  height: 8px;
  background-color: rgba(255, 255, 255, 0.1);
  border-radius: 4px;
  overflow: hidden;
}

.progress-fill {
  height: 100%;
  background-color: #06B6D4;
  border-radius: 4px;
  transition: width 0.3s ease;
}

.progress-info {
  display: flex;
  justify-content: space-between;
  font-size: 12px;
  color: rgba(255, 255, 255, 0.8);
}

.metrics-cards {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 10px;
}

.metric-card {
  background-color: rgba(255, 255, 255, 0.03);
  border-radius: 6px;
  padding: 15px;
  display: flex;
  flex-direction: column;
  gap: 5px;
}

.metric-label {
  font-size: 12px;
  color: rgba(255, 255, 255, 0.8);
}

.metric-value {
  font-size: 16px;
  font-weight: 600;
  color: #06B6D4;
}

.log-section {
  background-color: rgba(255, 255, 255, 0.03);
  border-radius: 6px;
  padding: 15px;
  display: flex;
  flex-direction: column;
  gap: 10px;
  flex: 1;
  min-height: 150px;
}

.log-container {
  flex: 1;
  overflow-y: auto;
  display: flex;
  flex-direction: column;
  gap: 5px;
}

.log-item {
  display: flex;
  gap: 10px;
  font-size: 11px;
  padding: 5px 0;
  border-bottom: 1px solid rgba(255, 255, 255, 0.05);
}

.log-time {
  color: rgba(255, 255, 255, 0.5);
  min-width: 80px;
}

.log-message {
  color: rgba(255, 255, 255, 0.8);
}

.function-operation-area {
  background-color: rgba(15, 23, 42, 0.7);
  border-radius: 8px;
  border: 1px solid rgba(255, 255, 255, 0.1);
  padding: 20px;
  margin-bottom: 20px;
}

.operation-buttons {
  display: flex;
  gap: 15px;
  flex-wrap: wrap;
}

.btn-primary {
  padding: 10px 20px;
  background-color: #06B6D4;
  border: 1px solid #06B6D4;
  color: #FFFFFF;
  border-radius: 6px;
  cursor: pointer;
  transition: all 0.3s ease;
  font-size: 12px;
  font-weight: 500;
}

.btn-primary:hover {
  background-color: rgba(6, 182, 212, 0.8);
}

.btn-secondary {
  padding: 10px 20px;
  background-color: rgba(255, 255, 255, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.3);
  color: #FFFFFF;
  border-radius: 6px;
  cursor: pointer;
  transition: all 0.3s ease;
  font-size: 12px;
}

.btn-secondary:hover {
  background-color: rgba(255, 255, 255, 0.2);
}

.lightweight-auxiliary-area {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 20px;
  margin-bottom: 20px;
}

.auxiliary-section {
  background-color: rgba(15, 23, 42, 0.7);
  border-radius: 8px;
  border: 1px solid rgba(255, 255, 255, 0.1);
  overflow: hidden;
}

.section-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 15px 20px;
  cursor: pointer;
  background-color: rgba(255, 255, 255, 0.03);
  transition: all 0.3s ease;
}

.section-header:hover {
  background-color: rgba(255, 255, 255, 0.05);
}

.toggle-icon {
  font-size: 10px;
  color: rgba(255, 255, 255, 0.5);
  transition: transform 0.3s ease;
}

.section-content {
  padding: 20px;
  display: flex;
  flex-direction: column;
  gap: 15px;
}

.history-item {
  background-color: rgba(255, 255, 255, 0.03);
  border-radius: 6px;
  padding: 15px;
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.history-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.history-name {
  font-size: 12px;
  font-weight: 500;
  color: #FFFFFF;
}

.history-status {
  font-size: 10px;
  padding: 2px 8px;
  border-radius: 10px;
  text-transform: uppercase;
}

.history-status.completed {
  background-color: rgba(16, 185, 129, 0.2);
  color: #10B981;
}

.history-status.failed {
  background-color: rgba(239, 68, 68, 0.2);
  color: #EF4444;
}

.history-status.running {
  background-color: rgba(245, 158, 11, 0.2);
  color: #F59E0B;
}

.history-metrics {
  display: flex;
  gap: 15px;
  font-size: 11px;
  color: rgba(255, 255, 255, 0.8);
}

.overview-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 10px 0;
  border-bottom: 1px solid rgba(255, 255, 255, 0.05);
}

.overview-label {
  font-size: 12px;
  color: rgba(255, 255, 255, 0.8);
}

.overview-value {
  font-size: 14px;
  font-weight: 600;
  color: #06B6D4;
}

/* 滚动条样式 */
::-webkit-scrollbar {
  width: 6px;
  height: 6px;
}

::-webkit-scrollbar-track {
  background: rgba(255, 255, 255, 0.05);
  border-radius: 3px;
}

::-webkit-scrollbar-thumb {
  background: rgba(255, 255, 255, 0.2);
  border-radius: 3px;
}

::-webkit-scrollbar-thumb:hover {
  background: rgba(255, 255, 255, 0.3);
}

/* 响应式设计 */
@media (max-width: 1200px) {
  .main-content {
    grid-template-columns: 1fr;
  }
  
  .lightweight-auxiliary-area {
    grid-template-columns: 1fr;
  }
}

@media (max-width: 768px) {
  .model-layer-detail {
    padding: 10px;
  }
  
  .config-grid,
  .params-grid,
  .metrics-cards {
    grid-template-columns: 1fr;
  }
  
  .operation-buttons {
    flex-direction: column;
  }
  
  .operation-buttons button {
    width: 100%;
  }
}
</style>