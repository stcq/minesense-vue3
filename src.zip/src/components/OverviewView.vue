<template>
  <div class="interface" :class="{ active: isActive }">
    <!-- 顶部导航栏 -->
    <TopNav @demo="handleDemo" @reset="handleReset" />
    
    <!-- 主内容区域 -->
    <div class="main-content">
      <h1 class="main-title" :style="{ color: data.color }">
        {{ data.title }}
      </h1>
      <h2 class="main-subtitle">{{ data.subtitle }}</h2>
      <p class="main-desc">{{ data.description }}</p>
      
      <!-- 数据卡片 -->
      <div class="content-grid">
        <div 
          v-for="(card, index) in data.cards" 
          :key="index"
          class="info-card"
        >
          <h3>{{ card.title }}</h3>
          <p class="data-value" :style="{ color: data.color }">{{ card.value }}</p>
          <p class="data-desc">{{ card.desc }}</p>
        </div>
      </div>
      
      <!-- 主按钮 -->
      <button class="main-btn" :style="{ backgroundColor: data.color }" @click="handleMainButtonClick">
        {{ data.buttonText }}
      </button>
    </div>
  </div>
</template>

<script setup>
import { computed } from 'vue'
import TopNav from './TopNav.vue'

const props = defineProps({
  data: {
    type: Object,
    required: true
  },
  isActive: {
    type: Boolean,
    default: false
  }
})

const emit = defineEmits(['demo', 'reset', 'enter-system', 'view-detail'])

function handleDemo() {
  emit('demo')
}

function handleReset() {
  emit('reset')
}

function handleMainButtonClick() {
  console.log('Main button clicked:', props.data.buttonText)
  // 触发详情页面查看事件
  emit('view-detail', props.data.buttonText)
}
</script>

<style scoped>
.interface {
  min-width: 100%;
  height: 100%;
  display: flex;
  flex-direction: column;
  padding: 20px;
}

.main-content {
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  text-align: center;
  padding: 20px;
}

.main-title {
  font-size: 48px;
  font-weight: 700;
  margin-bottom: 8px;
  color: #FFFFFF;
}

.main-subtitle {
  font-size: 20px;
  font-weight: 400;
  color: rgba(255, 255, 255, 0.6);
  margin-bottom: 24px;
}

.main-desc {
  font-size: 20px;
  line-height: 1.6;
  max-width: 800px;
  margin-bottom: 48px;
  color: rgba(255, 255, 255, 0.9);
}

.content-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 30px;
  margin-bottom: 60px;
  width: 100%;
  max-width: 1200px;
}

.info-card {
  background-color: rgba(255, 255, 255, 0.05);
  border-radius: 12px;
  padding: 30px;
  backdrop-filter: blur(10px);
  border: 1px solid rgba(255, 255, 255, 0.1);
  transition: transform 0.3s ease;
}

.info-card:hover {
  transform: translateY(-5px);
}

.info-card h3 {
  font-size: 18px;
  font-weight: 500;
  color: rgba(255, 255, 255, 0.8);
  margin-bottom: 15px;
}

.data-value {
  font-size: 48px;
  font-weight: 700;
  margin-bottom: 10px;
}

.data-desc {
  font-size: 16px;
  color: rgba(255, 255, 255, 0.7);
}

.main-btn {
  width: 220px;
  height: 60px;
  color: #FFFFFF;
  border: none;
  border-radius: 12px;
  font-size: 18px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s ease;
  box-shadow: 0 0 15px rgba(6, 182, 212, 0.3);
}

.main-btn:hover {
  opacity: 0.9;
  box-shadow: 0 0 20px rgba(6, 182, 212, 0.5);
  transform: translateY(-2px);
}

@media (max-width: 1024px) {
  .content-grid {
    grid-template-columns: repeat(2, 1fr);
  }
}

@media (max-width: 768px) {
  .content-grid {
    grid-template-columns: 1fr;
  }
  
  .main-title {
    font-size: 36px;
  }
  
  .main-subtitle {
    font-size: 16px;
  }
  
  .main-desc {
    font-size: 18px;
  }
}

@media (prefers-reduced-motion: reduce) {
  .info-card,
  .main-btn {
    transition: none !important;
  }
}
</style>
