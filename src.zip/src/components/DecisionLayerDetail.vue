<template>
  <div class="decision-layer-detail">
    <!-- 顶部状态监控栏 -->
    <div class="status-monitor-bar">
      <div class="realtime-dashboard">
        <div class="dashboard-item">
          <span class="item-label">应力</span>
          <span class="item-value">23.5 MPa</span>
        </div>
        <div class="dashboard-item">
          <span class="item-label">微震</span>
          <span class="item-value">156.8 J</span>
        </div>
        <div class="dashboard-item">
          <span class="item-label">位移</span>
          <span class="item-value">2.1 mm</span>
        </div>
        <div class="dashboard-item">
          <span class="item-label">预警状态</span>
          <span class="item-value warning">中度风险</span>
        </div>
      </div>
      <div class="ai-service-status">
        <span class="status-item online">AI 模型在线</span>
        <span class="status-item online">知识库更新完成</span>
        <span class="status-item online">数据接口正常</span>
      </div>
      <div class="task-counts">
        <span class="count-item">待执行: 2</span>
        <span class="count-item">执行中: 1</span>
        <span class="count-item">已完成: 5</span>
      </div>
    </div>

    <!-- 权限与协作模块 -->
    <div class="permission-collaboration">
      <div class="user-role">
        <span>角色: 管理员</span>
      </div>
      <div class="action-buttons">
        <button class="btn-secondary small">分享方案</button>
        <button class="btn-secondary small">查看日志</button>
      </div>
    </div>

    <!-- 主内容区 -->
    <div class="main-content">
      <!-- 左侧：生成式 AI 交互区 -->
      <div class="ai-interaction-area">
        <h2 class="area-title">生成式 AI 交互区</h2>
        
        <!-- 交互模式切换 -->
        <div class="interaction-mode">
          <button class="mode-btn" :class="{ active: interactionMode === 'chat' }" @click="interactionMode = 'chat'">问答模式</button>
          <button class="mode-btn" :class="{ active: interactionMode === 'plan' }" @click="interactionMode = 'plan'">方案生成模式</button>
          <button class="mode-btn" :class="{ active: interactionMode === 'optimize' }" @click="interactionMode = 'optimize'">优化模式</button>
        </div>

        <!-- 会话窗口 -->
        <div class="chat-window">
          <div class="chat-header">
            <h3 class="chat-title">历史对话</h3>
            <div class="chat-controls">
              <button class="btn-small">清空</button>
              <button class="btn-small">导出</button>
            </div>
          </div>
          <div class="chat-messages">
            <div class="chat-message ai-message">
              <div class="message-header">
                <span class="message-role">AI</span>
                <span class="message-time">14:30:00</span>
                <span class="message-tag">日常防控</span>
              </div>
              <div class="message-content">
                根据21205工作面的监测数据，当前应力为23MPa，微震能量为156.8J，判定为中度冲击地压风险。建议采取以下防控措施：1. 在回采巷布置卸压钻孔；2. 加密微震监测频次；3. 调整顶板支护参数。
              </div>
            </div>
            <div class="chat-message user-message">
              <div class="message-header">
                <span class="message-role">用户</span>
                <span class="message-time">14:32:15</span>
              </div>
              <div class="message-content">
                优化上次21205工作面的防控方案
              </div>
            </div>
            <div class="chat-message ai-message">
              <div class="message-header">
                <span class="message-role">AI</span>
                <span class="message-time">14:32:45</span>
                <span class="message-tag">方案优化</span>
              </div>
              <div class="message-content">
                基于历史方案和最新监测数据，优化后的防控方案如下：1. 增加卸压钻孔数量至15个；2. 监测频次调整为每小时一次；3. 增加顶板支护强度。
              </div>
            </div>
          </div>

          <!-- 快捷指令 -->
          <div class="quick-commands">
            <button class="quick-command-btn" @click="sendQuickCommand('冲击地压应急处置')">冲击地压应急处置</button>
            <button class="quick-command-btn" @click="sendQuickCommand('应力超限调控方案')">应力超限调控方案</button>
            <button class="quick-command-btn" @click="sendQuickCommand('多模态数据异常分析')">多模态数据异常分析</button>
          </div>

          <!-- 输入框 -->
          <div class="input-area">
            <input type="text" v-model="userInput" placeholder="请输入您的问题或指令..." class="text-input">
            <div class="input-actions">
              <div class="upload-container">
                <input type="file" ref="fileInput" class="file-input" @change="handleFileUpload">
                <button class="upload-btn" @click="triggerFileInput">
                  <span class="upload-icon">📎</span>
                </button>
                <div v-if="uploadProgress > 0 && uploadProgress < 100" class="upload-progress">
                  <div class="progress-bar">
                    <div class="progress-fill" :style="{ width: uploadProgress + '%' }"></div>
                  </div>
                </div>
                <span v-if="uploadComplete" class="upload-success">上传成功</span>
              </div>
              <button class="send-btn" @click="sendMessage">发送</button>
            </div>
          </div>
        </div>
      </div>

      <!-- 中部：AI 方案智能展示区 -->
      <div class="ai-plan-display-area">
        <h2 class="area-title">AI 方案智能展示区</h2>
        
        <!-- 方案结构化展示 -->
        <div class="plan-structured-display">
          <!-- 方案头部 -->
          <div class="plan-header">
            <div class="plan-core-info">
              <span class="info-item"><strong>适用工作面:</strong> 21205</span>
              <span class="info-item"><strong>灾害类型:</strong> 冲击地压</span>
              <span class="info-item"><strong>风险等级:</strong> 中度</span>
              <span class="info-item"><strong>生成时间:</strong> 2026-03-23 14:32:45</span>
              <span class="info-item"><strong>AI 置信度:</strong> 92%</span>
            </div>
            <div class="plan-actions">
              <button class="btn-secondary" :class="{ active: editMode }" @click="toggleEditMode">{{ editMode ? '保存' : '编辑' }}</button>
              <button class="btn-secondary">版本对比</button>
              <div class="compliance-check-container">
                <button class="btn-secondary" @click="startComplianceCheck">合规性校验</button>
                <div v-if="showComplianceProgress" class="compliance-progress">
                  <div class="progress-bar">
                    <div class="progress-fill" :style="{ width: complianceProgress + '%' }"></div>
                  </div>
                  <span v-if="complianceCompleted" class="compliance-result">方案合规</span>
                </div>
              </div>
            </div>
          </div>

          <!-- 方案主体 -->
          <div class="plan-body">
            <!-- 基础分析层 -->
            <div class="plan-section">
              <h3 class="section-title">基础分析</h3>
              <div class="section-content">
                <p>21205 工作面 ZK21205-03 钻孔应力达 23MPa，微震能量 156.8J，判定为中度冲击地压风险，风险源为回采巷顶板应力集中。</p>
              </div>
            </div>

            <!-- 核心方案层 -->
            <div class="plan-section">
              <h3 class="section-title">核心方案</h3>
              <div class="core-plan-scrollable">
                <!-- 工程措施 -->
                <div class="measure-category">
                  <h4 class="category-title" :contenteditable="editMode">工程措施</h4>
                  <div class="measure-item">
                    <div class="measure-header">
                      <span class="measure-name" :contenteditable="editMode">卸压钻孔布置</span>
                      <span class="priority high" :contenteditable="editMode">优先级: 高</span>
                      <span class="timeliness immediate" :contenteditable="editMode">执行时效: 立即</span>
                    </div>
                    <div class="measure-content">
                      <p :contenteditable="editMode">在回采巷布置15个卸压钻孔，钻孔深度10m，间距3m，孔径75mm。</p>
                    </div>
                  </div>
                  <div class="measure-item">
                    <div class="measure-header">
                      <span class="measure-name" :contenteditable="editMode">顶板支护调整</span>
                      <span class="priority medium" :contenteditable="editMode">优先级: 中</span>
                      <span class="timeliness two-hours" :contenteditable="editMode">执行时效: 2h内</span>
                    </div>
                    <div class="measure-content">
                      <p :contenteditable="editMode">增加顶板支护强度，采用高强度锚杆+锚索联合支护，锚杆间距调整为800mm×800mm。</p>
                    </div>
                  </div>
                </div>

                <!-- 监测措施 -->
                <div class="measure-category">
                  <h4 class="category-title" :contenteditable="editMode">监测措施</h4>
                  <div class="measure-item">
                    <div class="measure-header">
                      <span class="measure-name" :contenteditable="editMode">微震监测加密</span>
                      <span class="priority high" :contenteditable="editMode">优先级: 高</span>
                      <span class="timeliness immediate" :contenteditable="editMode">执行时效: 立即</span>
                    </div>
                    <div class="measure-content">
                      <p :contenteditable="editMode">微震监测频次调整为每小时一次，重点监测回采巷顶板区域。</p>
                    </div>
                  </div>
                  <div class="measure-item">
                    <div class="measure-header">
                      <span class="measure-name" :contenteditable="editMode">应力巡检</span>
                      <span class="priority medium" :contenteditable="editMode">优先级: 中</span>
                      <span class="timeliness twelve-hours" :contenteditable="editMode">执行时效: 12h内</span>
                    </div>
                    <div class="measure-content">
                      <p :contenteditable="editMode">对ZK21205-01至ZK21205-08钻孔进行应力巡检，记录应力变化趋势。</p>
                    </div>
                  </div>
                </div>

                <!-- 人员措施 -->
                <div class="measure-category">
                  <h4 class="category-title" :contenteditable="editMode">人员措施</h4>
                  <div class="measure-item">
                    <div class="measure-header">
                      <span class="measure-name" :contenteditable="editMode">作业区域限员</span>
                      <span class="priority high" :contenteditable="editMode">优先级: 高</span>
                      <span class="timeliness immediate" :contenteditable="editMode">执行时效: 立即</span>
                    </div>
                    <div class="measure-content">
                      <p :contenteditable="editMode">回采巷作业区域限员至5人以下，禁止大型设备同时作业。</p>
                    </div>
                  </div>
                  <div class="measure-item">
                    <div class="measure-header">
                      <span class="measure-name" :contenteditable="editMode">应急撤离路线</span>
                      <span class="priority medium" :contenteditable="editMode">优先级: 中</span>
                      <span class="timeliness two-hours" :contenteditable="editMode">执行时效: 2h内</span>
                    </div>
                    <div class="measure-content">
                      <p :contenteditable="editMode">制定应急撤离路线，在巷道内设置明显标识，组织人员演练。</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <!-- 依据说明层 -->
            <div class="plan-section">
              <h3 class="section-title">依据说明</h3>
              <div class="section-content">
                <ul>
                  <li>基于《煤矿冲击地压防治细则》第32条</li>
                  <li>参考21205工作面历史防控案例</li>
                  <li>模型预警准确率89%的验证结果</li>
                </ul>
              </div>
            </div>

            <!-- 风险提示层 -->
            <div class="plan-section">
              <h3 class="section-title">风险提示</h3>
              <div class="section-content">
                <p>卸压钻孔施工可能导致瓦斯逸出，建议同步监测瓦斯浓度。</p>
                <p>顶板支护调整过程中需注意作业安全，防止顶板冒落。</p>
              </div>
            </div>

            <!-- 方案可视化 -->
            <div class="plan-visualization">
              <h3 class="section-title">方案可视化</h3>
              <div class="visualization-grid">
                <div class="visualization-item">
                  <h4 class="visualization-title">卸压钻孔布置示意图</h4>
                  <div class="visualization-placeholder">
                    <div class="chart-skeleton"></div>
                  </div>
                </div>
                <div class="visualization-item">
                  <h4 class="visualization-title">应力调控目标曲线</h4>
                  <div class="visualization-placeholder">
                    <div class="chart-skeleton"></div>
                  </div>
                </div>
                <div class="visualization-item">
                  <h4 class="visualization-title">执行进度甘特图</h4>
                  <div class="visualization-placeholder">
                    <div class="chart-skeleton"></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- 方案评审模块 -->
        <div class="plan-review-module">
          <h3 class="section-title">方案评审</h3>
          <div class="review-content">
            <div class="review-item">
              <span class="review-label">合规性校验:</span>
              <span class="review-result pass">通过</span>
            </div>
            <div class="review-item">
              <span class="review-label">专家意见:</span>
              <span class="review-result">已接入</span>
            </div>
            <div class="review-item">
              <span class="review-label">可行性评估:</span>
              <span class="review-result">92分</span>
              <span class="review-note">扣分点: 现场设备不足，无法满足每小时巡检要求</span>
            </div>
          </div>
        </div>
      </div>

      <!-- 右侧：决策执行托管区 -->
      <div class="decision-execution-area">
        <h2 class="area-title">决策执行托管区</h2>
        
        <!-- 执行前校验模块 -->
        <div class="execution-check-module">
          <h3 class="section-title">执行前校验</h3>
          <div class="check-content">
            <div class="check-item">
              <span class="check-label">执行条件核验:</span>
              <div class="check-status">
                <span class="status-item satisfied">卸压设备在位</span>
                <span class="status-item satisfied">监测人员已排班</span>
                <span class="status-item pending">现场瓦斯浓度待达标</span>
              </div>
            </div>
            <div class="check-item">
              <span class="check-label">执行范围确认:</span>
              <div class="check-scope">
                <div class="scope-placeholder">
                  <div class="chart-skeleton"></div>
                </div>
              </div>
            </div>
            <div class="check-item">
              <span class="check-label">执行权限验证:</span>
              <span class="check-permission">
                <span class="permission-status granted">权限已确认 (管理员)</span>
              </span>
            </div>
          </div>
        </div>

        <!-- 执行控制模块 -->
        <div class="execution-control-module">
          <h3 class="section-title">执行控制</h3>
          <div class="control-buttons">
            <button class="btn-primary">一键托管执行</button>
            <button class="btn-secondary">分步执行</button>
            <button class="btn-secondary">模拟执行</button>
          </div>
          <div class="execution-params">
            <h4 class="params-title">执行参数微调</h4>
            <div class="param-item">
              <label>巡检频次</label>
              <select class="select-input">
                <option value="1">1小时/次</option>
                <option value="2" selected>2小时/次</option>
                <option value="4">4小时/次</option>
              </select>
            </div>
            <div class="param-item">
              <label>卸压钻孔深度</label>
              <input type="number" value="8" min="5" max="15" class="number-input">
              <span class="param-unit">m</span>
            </div>
          </div>
        </div>

        <!-- 执行监控模块 -->
        <div class="execution-monitor-module">
          <h3 class="section-title">执行监控</h3>
          <div class="monitor-content">
            <div class="progress-item">
              <span class="progress-label">人员撤离</span>
              <div class="progress-bar">
                <div class="progress-fill" style="width: 100%"></div>
              </div>
              <span class="progress-value">100%</span>
            </div>
            <div class="progress-item">
              <span class="progress-label">卸压钻孔施工</span>
              <div class="progress-bar">
                <div class="progress-fill" style="width: 60%"></div>
              </div>
              <span class="progress-value">60%</span>
            </div>
            <div class="progress-item">
              <span class="progress-label">效果监测</span>
              <div class="progress-bar">
                <div class="progress-fill" style="width: 0%"></div>
              </div>
              <span class="progress-value">0%</span>
            </div>
            <div class="emergency-actions">
              <button class="btn-danger">终止执行</button>
              <button class="btn-secondary">回滚</button>
            </div>
          </div>
        </div>

        <!-- 执行结果模块 -->
        <div class="execution-result-module">
          <h3 class="section-title">执行结果</h3>
          <div class="result-content">
            <div class="result-item">
              <span class="result-label">执行状态:</span>
              <span class="result-status running">执行中</span>
            </div>
            <div class="result-item">
              <span class="result-label">开始时间:</span>
              <span class="result-value">2026-03-23 14:45:00</span>
            </div>
            <div class="result-item">
              <span class="result-label">预计完成:</span>
              <span class="result-value">2026-03-23 16:30:00</span>
            </div>
            <button class="btn-secondary">查看复盘报告</button>
            <button class="btn-secondary">归档记录</button>
          </div>
        </div>
      </div>
    </div>

    <!-- 返回按钮 -->
    <button class="btn-back" @click="handleBack">返回</button>
  </div>
</template>

<script setup>
import { ref } from 'vue'

const emit = defineEmits(['back'])

// 状态管理
const interactionMode = ref('chat')
const userInput = ref('')
const editMode = ref(false)
const showComplianceProgress = ref(false)
const complianceProgress = ref(0)
const complianceCompleted = ref(false)
const fileInput = ref(null)
const uploadProgress = ref(0)
const uploadComplete = ref(false)

// 方法
function handleBack() {
  emit('back')
}

function sendMessage() {
  if (userInput.value.trim()) {
    // 模拟发送消息
    console.log('发送消息:', userInput.value)
    userInput.value = ''
  }
}

function sendQuickCommand(command) {
  userInput.value = command
  sendMessage()
}

function toggleEditMode() {
  editMode.value = !editMode.value
}

function startComplianceCheck() {
  // 重置状态
  showComplianceProgress.value = true
  complianceProgress.value = 0
  complianceCompleted.value = false
  
  // 模拟进度条动画
  const interval = setInterval(() => {
    complianceProgress.value += 5
    if (complianceProgress.value >= 100) {
      clearInterval(interval)
      complianceCompleted.value = true
    }
  }, 100)
}

function triggerFileInput() {
  fileInput.value.click()
}

function handleFileUpload(event) {
  const file = event.target.files[0]
  if (file) {
    // 重置上传状态
    uploadProgress.value = 0
    uploadComplete.value = false
    
    // 模拟文件上传进度
    const interval = setInterval(() => {
      uploadProgress.value += 10
      if (uploadProgress.value >= 100) {
        clearInterval(interval)
        uploadComplete.value = true
        // 3秒后清除上传成功提示
        setTimeout(() => {
          uploadComplete.value = false
        }, 3000)
      }
    }, 200)
    
    console.log('上传文件:', file.name)
  }
}
</script>

<style scoped>
.decision-layer-detail {
  width: 100%;
  height: 100vh;
  display: flex;
  flex-direction: column;
  background-color: #0F172A;
  color: #FFFFFF;
  overflow-y: auto;
  padding: 20px;
  box-sizing: border-box;
  position: relative;
}

/* 顶部状态监控栏 */
.status-monitor-bar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  background-color: rgba(15, 23, 42, 0.95);
  border-radius: 8px;
  border: 1px solid rgba(255, 255, 255, 0.1);
  padding: 15px 20px;
  margin-bottom: 20px;
  flex-wrap: wrap;
  gap: 15px;
}

.realtime-dashboard {
  display: flex;
  gap: 20px;
  flex-wrap: wrap;
}

.dashboard-item {
  display: flex;
  flex-direction: column;
  gap: 5px;
}

.item-label {
  font-size: 12px;
  color: rgba(255, 255, 255, 0.6);
}

.item-value {
  font-size: 16px;
  font-weight: 600;
  color: #06B6D4;
}

.item-value.warning {
  color: #F59E0B;
}

.ai-service-status {
  display: flex;
  gap: 15px;
  flex-wrap: wrap;
}

.status-item {
  font-size: 12px;
  padding: 4px 8px;
  border-radius: 12px;
}

.status-item.online {
  background-color: rgba(16, 185, 129, 0.2);
  color: #10B981;
}

.status-item.offline {
  background-color: rgba(239, 68, 68, 0.2);
  color: #EF4444;
}

.task-counts {
  display: flex;
  gap: 15px;
  flex-wrap: wrap;
}

.count-item {
  font-size: 12px;
  color: rgba(255, 255, 255, 0.8);
}

/* 权限与协作模块 */
.permission-collaboration {
  position: absolute;
  top: 20px;
  right: 20px;
  display: flex;
  align-items: center;
  gap: 15px;
  z-index: 10;
}

.user-role {
  font-size: 12px;
  color: rgba(255, 255, 255, 0.8);
}

.action-buttons {
  display: flex;
  gap: 10px;
}

.btn-secondary.small {
  padding: 4px 8px;
  font-size: 10px;
}

/* 主内容区 */
.main-content {
  display: grid;
  grid-template-columns: 30% 50% 20%;
  gap: 20px;
  flex: 1;
  min-height: 0;
}

/* 通用区域样式 */
.area-title {
  font-size: 16px;
  font-weight: 600;
  color: #FFFFFF;
  margin: 0 0 15px 0;
}

/* 左侧：生成式 AI 交互区 */
.ai-interaction-area {
  background-color: rgba(15, 23, 42, 0.7);
  border-radius: 8px;
  border: 1px solid rgba(255, 255, 255, 0.1);
  padding: 20px;
  display: flex;
  flex-direction: column;
  gap: 15px;
  overflow-y: auto;
}

.interaction-mode {
  display: flex;
  gap: 10px;
  margin-bottom: 10px;
}

.mode-btn {
  flex: 1;
  padding: 8px;
  background-color: rgba(255, 255, 255, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.3);
  color: #FFFFFF;
  border-radius: 4px;
  cursor: pointer;
  transition: all 0.3s ease;
  font-size: 12px;
}

.mode-btn.active {
  background-color: rgba(6, 182, 212, 0.2);
  border-color: #06B6D4;
  color: #06B6D4;
}

.chat-window {
  flex: 1;
  display: flex;
  flex-direction: column;
  background-color: rgba(255, 255, 255, 0.03);
  border-radius: 6px;
  overflow: hidden;
}

.chat-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 10px 15px;
  background-color: rgba(255, 255, 255, 0.05);
  border-bottom: 1px solid rgba(255, 255, 255, 0.1);
}

.chat-title {
  font-size: 14px;
  font-weight: 600;
  color: #FFFFFF;
  margin: 0;
}

.chat-controls {
  display: flex;
  gap: 5px;
}

.btn-small {
  padding: 4px 8px;
  background-color: rgba(255, 255, 255, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.3);
  color: #FFFFFF;
  border-radius: 4px;
  cursor: pointer;
  font-size: 10px;
  transition: all 0.3s ease;
}

.btn-small:hover {
  background-color: rgba(6, 182, 212, 0.2);
  border-color: #06B6D4;
}

.chat-messages {
  flex: 1;
  padding: 15px;
  overflow-y: auto;
  display: flex;
  flex-direction: column;
  gap: 15px;
}

.chat-message {
  max-width: 100%;
}

.ai-message .message-content {
  background-color: rgba(6, 182, 212, 0.1);
  border-left: 3px solid #06B6D4;
}

.user-message .message-content {
  background-color: rgba(255, 255, 255, 0.05);
  border-left: 3px solid rgba(255, 255, 255, 0.3);
}

.message-header {
  display: flex;
  align-items: center;
  gap: 10px;
  margin-bottom: 5px;
  font-size: 11px;
}

.message-role {
  font-weight: 600;
  color: #06B6D4;
}

.message-time {
  color: rgba(255, 255, 255, 0.5);
}

.message-tag {
  background-color: rgba(245, 158, 11, 0.2);
  color: #F59E0B;
  padding: 2px 6px;
  border-radius: 10px;
  font-size: 10px;
}

.message-content {
  padding: 10px;
  border-radius: 4px;
  font-size: 12px;
  line-height: 1.4;
  color: rgba(255, 255, 255, 0.9);
}

.quick-commands {
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
  margin-bottom: 10px;
}

.quick-command-btn {
  padding: 8px 12px;
  background-color: rgba(255, 255, 255, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.3);
  color: #FFFFFF;
  border-radius: 4px;
  cursor: pointer;
  font-size: 11px;
  transition: all 0.3s ease;
  flex: 1;
  min-width: 120px;
}

.quick-command-btn:hover {
  background-color: rgba(6, 182, 212, 0.2);
  border-color: #06B6D4;
}

.input-area {
  display: flex;
  gap: 10px;
  margin-top: auto;
}

.text-input {
  flex: 1;
  padding: 10px;
  background-color: rgba(255, 255, 255, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.3);
  color: #FFFFFF;
  border-radius: 4px;
  font-size: 12px;
}

.text-input::placeholder {
  color: rgba(255, 255, 255, 0.5);
}

.input-actions {
  display: flex;
  gap: 5px;
}

.upload-btn {
  padding: 0 12px;
  background-color: rgba(255, 255, 255, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.3);
  color: #FFFFFF;
  border-radius: 4px;
  cursor: pointer;
  transition: all 0.3s ease;
  display: flex;
  align-items: center;
  justify-content: center;
}

.upload-btn:hover {
  background-color: rgba(6, 182, 212, 0.2);
  border-color: #06B6D4;
}

.upload-icon {
  font-size: 14px;
}

.send-btn {
  padding: 0 12px;
  background-color: #06B6D4;
  border: 1px solid #06B6D4;
  color: #FFFFFF;
  border-radius: 4px;
  cursor: pointer;
  transition: all 0.3s ease;
  font-size: 12px;
}

.send-btn:hover {
  background-color: rgba(6, 182, 212, 0.8);
}

/* 中部：AI 方案智能展示区 */
.ai-plan-display-area {
  background-color: rgba(15, 23, 42, 0.7);
  border-radius: 8px;
  border: 1px solid rgba(255, 255, 255, 0.1);
  padding: 20px;
  display: flex;
  flex-direction: column;
  gap: 20px;
  overflow-y: auto;
}

.plan-structured-display {
  background-color: rgba(255, 255, 255, 0.03);
  border-radius: 6px;
  overflow: hidden;
}

.plan-header {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  padding: 15px;
  background-color: rgba(255, 255, 255, 0.05);
  border-bottom: 1px solid rgba(255, 255, 255, 0.1);
  flex-wrap: wrap;
  gap: 15px;
}

.plan-core-info {
  display: flex;
  gap: 15px;
  flex-wrap: wrap;
  font-size: 12px;
}

.info-item {
  color: rgba(255, 255, 255, 0.9);
}

.plan-actions {
  display: flex;
  gap: 10px;
  flex-wrap: wrap;
}

.plan-body {
  padding: 15px;
  display: flex;
  flex-direction: column;
  gap: 15px;
}

.plan-section {
  background-color: rgba(255, 255, 255, 0.02);
  border-radius: 4px;
  padding: 15px;
}

.section-title {
  font-size: 14px;
  font-weight: 600;
  color: #06B6D4;
  margin: 0 0 10px 0;
}

.section-content {
  font-size: 12px;
  line-height: 1.4;
  color: rgba(255, 255, 255, 0.9);
}

.measure-category {
  margin-top: 10px;
  margin-bottom: 15px;
}

.category-title {
  font-size: 13px;
  font-weight: 600;
  color: #FFFFFF;
  margin: 0 0 10px 0;
}

.measure-item {
  background-color: rgba(255, 255, 255, 0.03);
  border-radius: 4px;
  padding: 10px;
  margin-bottom: 10px;
}

.measure-header {
  display: flex;
  align-items: center;
  gap: 15px;
  margin-bottom: 5px;
  flex-wrap: wrap;
}

.measure-name {
  font-size: 12px;
  font-weight: 500;
  color: #FFFFFF;
  flex: 1;
}

.priority {
  font-size: 10px;
  padding: 2px 6px;
  border-radius: 10px;
}

.priority.high {
  background-color: rgba(239, 68, 68, 0.2);
  color: #EF4444;
}

.priority.medium {
  background-color: rgba(245, 158, 11, 0.2);
  color: #F59E0B;
}

.priority.low {
  background-color: rgba(16, 185, 129, 0.2);
  color: #10B981;
}

.timeliness {
  font-size: 10px;
  padding: 2px 6px;
  border-radius: 10px;
}

.timeliness.immediate {
  background-color: rgba(239, 68, 68, 0.2);
  color: #EF4444;
}

.timeliness.two-hours {
  background-color: rgba(245, 158, 11, 0.2);
  color: #F59E0B;
}

.timeliness.twelve-hours {
  background-color: rgba(16, 185, 129, 0.2);
  color: #10B981;
}

.measure-content {
  font-size: 11px;
  line-height: 1.4;
  color: rgba(255, 255, 255, 0.8);
}

.core-plan-scrollable {
  max-height: 300px;
  overflow-y: auto;
  padding-right: 10px;
}

.core-plan-scrollable::-webkit-scrollbar {
  width: 6px;
}

.core-plan-scrollable::-webkit-scrollbar-track {
  background: rgba(255, 255, 255, 0.05);
  border-radius: 3px;
}

.core-plan-scrollable::-webkit-scrollbar-thumb {
  background: rgba(255, 255, 255, 0.2);
  border-radius: 3px;
}

.core-plan-scrollable::-webkit-scrollbar-thumb:hover {
  background: rgba(255, 255, 255, 0.3);
}

/* 编辑模式样式 */
.btn-secondary.active {
  background-color: rgba(6, 182, 212, 0.2);
  border-color: #06B6D4;
  color: #06B6D4;
}

[contenteditable="true"] {
  outline: 1px dashed rgba(6, 182, 212, 0.5);
  background-color: rgba(6, 182, 212, 0.05);
  padding: 2px 4px;
  border-radius: 2px;
}

[contenteditable="true"]:focus {
  outline: 1px solid #06B6D4;
  background-color: rgba(6, 182, 212, 0.1);
}

/* 合规性校验样式 */
.compliance-check-container {
  display: flex;
  align-items: center;
  gap: 10px;
}

.compliance-progress {
  display: flex;
  align-items: center;
  gap: 10px;
  min-width: 200px;
}

.compliance-progress .progress-bar {
  flex: 1;
  height: 6px;
  background-color: rgba(255, 255, 255, 0.1);
  border-radius: 3px;
  overflow: hidden;
}

.compliance-progress .progress-fill {
  height: 100%;
  background-color: #06B6D4;
  border-radius: 3px;
  transition: width 0.3s ease;
}

.compliance-result {
  font-size: 12px;
  color: #10B981;
  font-weight: 500;
}

/* 文件上传样式 */
.upload-container {
  position: relative;
  display: flex;
  align-items: center;
  gap: 10px;
}

.file-input {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  opacity: 0;
  cursor: pointer;
  z-index: -1;
}

.upload-progress {
  width: 100px;
  height: 6px;
  background-color: rgba(255, 255, 255, 0.1);
  border-radius: 3px;
  overflow: hidden;
}

.upload-progress .progress-fill {
  height: 100%;
  background-color: #06B6D4;
  border-radius: 3px;
  transition: width 0.3s ease;
}

.upload-success {
  font-size: 11px;
  color: #10B981;
  font-weight: 500;
}

.section-content ul {
  margin: 0;
  padding-left: 20px;
  list-style-type: disc;
}

.section-content li {
  margin-bottom: 5px;
}

.plan-visualization {
  margin-top: 10px;
}

.visualization-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 15px;
  margin-top: 10px;
}

.visualization-item {
  background-color: rgba(255, 255, 255, 0.03);
  border-radius: 4px;
  padding: 10px;
}

.visualization-title {
  font-size: 11px;
  font-weight: 500;
  color: #FFFFFF;
  margin: 0 0 10px 0;
}

.visualization-placeholder {
  height: 100px;
  background-color: rgba(255, 255, 255, 0.02);
  border-radius: 4px;
  display: flex;
  align-items: center;
  justify-content: center;
}

.chart-skeleton {
  width: 80%;
  height: 60%;
  background-color: rgba(255, 255, 255, 0.1);
  border-radius: 4px;
  animation: pulse 1.5s ease-in-out infinite;
}

.plan-review-module {
  background-color: rgba(255, 255, 255, 0.03);
  border-radius: 6px;
  padding: 15px;
}

.review-content {
  display: flex;
  flex-direction: column;
  gap: 10px;
  font-size: 12px;
}

.review-item {
  display: flex;
  align-items: center;
  gap: 10px;
  flex-wrap: wrap;
}

.review-label {
  color: rgba(255, 255, 255, 0.8);
  min-width: 100px;
}

.review-result {
  font-weight: 500;
}

.review-result.pass {
  color: #10B981;
}

.review-result.fail {
  color: #EF4444;
}

.review-note {
  color: rgba(255, 255, 255, 0.6);
  font-size: 11px;
  margin-left: 10px;
}

/* 右侧：决策执行托管区 */
.decision-execution-area {
  background-color: rgba(15, 23, 42, 0.7);
  border-radius: 8px;
  border: 1px solid rgba(255, 255, 255, 0.1);
  padding: 20px;
  display: flex;
  flex-direction: column;
  gap: 20px;
  overflow-y: auto;
}

.execution-check-module,
.execution-control-module,
.execution-monitor-module,
.execution-result-module {
  background-color: rgba(255, 255, 255, 0.03);
  border-radius: 6px;
  padding: 15px;
}

.check-content,
.control-content,
.monitor-content,
.result-content {
  display: flex;
  flex-direction: column;
  gap: 10px;
  font-size: 12px;
}

.check-item {
  display: flex;
  flex-direction: column;
  gap: 5px;
}

.check-label {
  color: rgba(255, 255, 255, 0.8);
  font-weight: 500;
}

.check-status {
  display: flex;
  gap: 10px;
  flex-wrap: wrap;
}

.status-item {
  font-size: 10px;
  padding: 2px 6px;
  border-radius: 10px;
}

.status-item.satisfied {
  background-color: rgba(16, 185, 129, 0.2);
  color: #10B981;
}

.status-item.pending {
  background-color: rgba(245, 158, 11, 0.2);
  color: #F59E0B;
}

.check-scope {
  margin-top: 5px;
}

.scope-placeholder {
  height: 80px;
  background-color: rgba(255, 255, 255, 0.02);
  border-radius: 4px;
  display: flex;
  align-items: center;
  justify-content: center;
}

.check-permission {
  margin-top: 5px;
}

.permission-status.granted {
  color: #10B981;
}

.permission-status.denied {
  color: #EF4444;
}

.control-buttons {
  display: flex;
  flex-direction: column;
  gap: 10px;
  margin-bottom: 15px;
}

.btn-primary {
  padding: 10px;
  background-color: #06B6D4;
  border: 1px solid #06B6D4;
  color: #FFFFFF;
  border-radius: 4px;
  cursor: pointer;
  transition: all 0.3s ease;
  font-size: 12px;
  font-weight: 500;
}

.btn-primary:hover {
  background-color: rgba(6, 182, 212, 0.8);
}

.btn-secondary {
  padding: 10px;
  background-color: rgba(255, 255, 255, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.3);
  color: #FFFFFF;
  border-radius: 4px;
  cursor: pointer;
  transition: all 0.3s ease;
  font-size: 12px;
}

.btn-secondary:hover {
  background-color: rgba(255, 255, 255, 0.2);
}

.btn-danger {
  padding: 10px;
  background-color: rgba(239, 68, 68, 0.2);
  border: 1px solid #EF4444;
  color: #EF4444;
  border-radius: 4px;
  cursor: pointer;
  transition: all 0.3s ease;
  font-size: 12px;
}

.btn-danger:hover {
  background-color: rgba(239, 68, 68, 0.3);
}

.execution-params {
  margin-top: 15px;
}

.params-title {
  font-size: 12px;
  font-weight: 600;
  color: #FFFFFF;
  margin: 0 0 10px 0;
}

.param-item {
  display: flex;
  align-items: center;
  gap: 10px;
  margin-bottom: 10px;
}

.param-item label {
  font-size: 11px;
  color: rgba(255, 255, 255, 0.8);
  min-width: 80px;
}

.select-input,
.number-input {
  flex: 1;
  padding: 6px;
  background-color: rgba(255, 255, 255, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.3);
  color: #FFFFFF;
  border-radius: 4px;
  font-size: 11px;
}

.param-unit {
  font-size: 11px;
  color: rgba(255, 255, 255, 0.6);
  min-width: 20px;
}

.progress-item {
  display: flex;
  align-items: center;
  gap: 10px;
  margin-bottom: 10px;
}

.progress-label {
  font-size: 11px;
  color: rgba(255, 255, 255, 0.8);
  min-width: 100px;
}

.progress-bar {
  flex: 1;
  height: 6px;
  background-color: rgba(255, 255, 255, 0.1);
  border-radius: 3px;
  overflow: hidden;
}

.progress-fill {
  height: 100%;
  background-color: #06B6D4;
  border-radius: 3px;
  transition: width 0.3s ease;
}

.progress-value {
  font-size: 11px;
  color: rgba(255, 255, 255, 0.8);
  min-width: 40px;
  text-align: right;
}

.emergency-actions {
  display: flex;
  gap: 10px;
  margin-top: 10px;
}

.result-item {
  display: flex;
  align-items: center;
  gap: 10px;
}

.result-label {
  font-size: 11px;
  color: rgba(255, 255, 255, 0.8);
  min-width: 80px;
}

.result-value {
  font-size: 11px;
  color: #FFFFFF;
}

.result-status {
  font-size: 11px;
  padding: 2px 6px;
  border-radius: 10px;
}

.result-status.running {
  background-color: rgba(245, 158, 11, 0.2);
  color: #F59E0B;
}

.result-status.completed {
  background-color: rgba(16, 185, 129, 0.2);
  color: #10B981;
}

.result-status.failed {
  background-color: rgba(239, 68, 68, 0.2);
  color: #EF4444;
}

/* 返回按钮 */
.btn-back {
  position: absolute;
  top: 20px;
  left: 20px;
  padding: 8px 16px;
  background-color: rgba(255, 255, 255, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.3);
  color: #FFFFFF;
  border-radius: 6px;
  cursor: pointer;
  transition: all 0.3s ease;
  z-index: 10;
  font-size: 12px;
}

.btn-back:hover {
  background-color: rgba(6, 182, 212, 0.2);
  border-color: #06B6D4;
}

/* 滚动条样式 */
::-webkit-scrollbar {
  width: 6px;
  height: 6px;
}

::-webkit-scrollbar-track {
  background: rgba(255, 255, 255, 0.05);
  border-radius: 3px;
}

::-webkit-scrollbar-thumb {
  background: rgba(255, 255, 255, 0.2);
  border-radius: 3px;
}

::-webkit-scrollbar-thumb:hover {
  background: rgba(255, 255, 255, 0.3);
}

/* 响应式设计 */
@media (max-width: 1200px) {
  .main-content {
    grid-template-columns: 1fr;
  }
  
  .status-monitor-bar {
    flex-direction: column;
    align-items: flex-start;
  }
  
  .realtime-dashboard,
  .ai-service-status,
  .task-counts {
    width: 100%;
  }
}

@media (max-width: 768px) {
  .decision-layer-detail {
    padding: 10px;
  }
  
  .permission-collaboration {
    position: relative;
    top: 0;
    right: 0;
    margin-bottom: 15px;
    justify-content: space-between;
  }
  
  .visualization-grid {
    grid-template-columns: 1fr;
  }
  
  .control-buttons {
    flex-direction: column;
  }
  
  .btn-primary,
  .btn-secondary,
  .btn-danger {
    width: 100%;
  }
}

@keyframes pulse {
  0% {
    opacity: 0.6;
  }
  50% {
    opacity: 1;
  }
  100% {
    opacity: 0.6;
  }
}
</style>