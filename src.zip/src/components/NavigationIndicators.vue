<template>
  <div class="navigation-indicators">
    <div 
      v-for="index in total" 
      :key="index"
      class="indicator"
      :class="{ active: index - 1 === current }"
      @click="$emit('switch', index - 1)"
    />
  </div>
</template>

<script setup>
defineProps({
  total: {
    type: Number,
    required: true
  },
  current: {
    type: Number,
    required: true
  }
})

defineEmits(['switch'])
</script>

<style scoped>
.navigation-indicators {
  position: absolute;
  bottom: 30px;
  left: 50%;
  transform: translateX(-50%);
  display: flex;
  gap: 12px;
  z-index: 10;
}

.indicator {
  width: 12px;
  height: 12px;
  border-radius: 50%;
  background-color: rgba(255, 255, 255, 0.3);
  cursor: pointer;
  transition: all 0.3s ease;
}

.indicator:hover {
  background-color: rgba(6, 182, 212, 0.6);
}

.indicator.active {
  background-color: #06B6D4;
  transform: scale(1.2);
  box-shadow: 0 0 10px rgba(6, 182, 212, 0.5);
}

@media (prefers-reduced-motion: reduce) {
  .indicator {
    transition: none !important;
  }
}
</style>
