<template>
  <div class="particle-container">
    <div 
      v-for="(particle, index) in particles" 
      :key="index"
      class="particle"
      :style="particle.style"
    />
  </div>
</template>

<script setup>
import { ref, watch, onMounted } from 'vue'

const props = defineProps({
  currentIndex: {
    type: Number,
    required: true
  }
})

const particles = ref([])

// 层级颜色配置
const layerColors = {
  0: { color: '#06B6D4', animation: 'float' },      // 系统概览
  1: { color: '#00D9C0', animation: 'float' },      // 传感层
  2: { color: '#3B82F6', animation: 'float' },      // 数据层
  3: { color: '#10B981', animation: 'pulse' },      // 模型层
  4: { color: 'linear-gradient(135deg, #EF4444, #DC2626)', animation: 'flow' }  // 决策执行层
}

function createParticles() {
  const particleCount = window.innerWidth < 768 ? 50 : 100
  const layerColor = layerColors[props.currentIndex]
  
  // 根据当前界面索引设置基础动画持续时间（秒）
  // 索引越大，持续时间越短，速度越快
  const baseDuration = 15 - (props.currentIndex * 3)
  
  particles.value = Array.from({ length: particleCount }, () => ({
    style: {
      width: `${Math.random() * 5 + 1}px`,
      height: `${Math.random() * 5 + 1}px`,
      left: `${Math.random() * 100}%`,
      top: `${Math.random() * 100}%`,
      backgroundColor: layerColor.color,
      animation: `${layerColor.animation} ${Math.random() * 3 + baseDuration}s ease-in-out infinite`,
      animationDelay: `${Math.random() * 5}s`,
      opacity: Math.random() * 0.5 + 0.3
    }
  }))
}

watch(() => props.currentIndex, () => {
  createParticles()
})

onMounted(() => {
  createParticles()
  window.addEventListener('resize', createParticles)
})
</script>

<style scoped>
.particle-container {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  z-index: -1;
  overflow: hidden;
}

.particle {
  position: absolute;
  border-radius: 50%;
  transition: background-color 0.5s ease;
}

@media (prefers-reduced-motion: reduce) {
  .particle {
    animation: none !important;
    opacity: 0.3 !important;
  }
}

/* 动画定义 */
@keyframes float {
  0%, 100% {
    transform: translateY(0) translateX(0);
  }
  25% {
    transform: translateY(-10px) translateX(5px);
  }
  50% {
    transform: translateY(0) translateX(10px);
  }
  75% {
    transform: translateY(10px) translateX(5px);
  }
}

@keyframes pulse {
  0%, 100% {
    transform: scale(1);
    opacity: 0.3;
  }
  50% {
    transform: scale(1.5);
    opacity: 0.6;
  }
}

@keyframes flow {
  0% {
    transform: translateY(-100%) translateX(0);
    opacity: 0;
  }
  10% {
    opacity: 0.5;
  }
  90% {
    opacity: 0.5;
  }
  100% {
    transform: translateY(100%) translateX(20px);
    opacity: 0;
  }
}
</style>
