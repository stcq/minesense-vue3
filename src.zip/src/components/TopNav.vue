<template>
  <div class="top-nav">
    <div class="logo">MineSense · 智能矿压系统</div>
    <div class="nav-buttons">
      <button 
        class="btn-demo"
        :class="{ active: isDemoRunning }"
        @click="handleDemo"
      >
        {{ isDemoRunning ? '停止演示' : '自动演示' }}
      </button>
      <button class="btn-reset" @click="handleReset">
        重置
      </button>
    </div>
  </div>
</template>

<script setup>
import { ref, onUnmounted } from 'vue'

const emit = defineEmits(['demo', 'reset'])

const isDemoRunning = ref(false)
let demoInterval = null

function handleDemo() {
  if (isDemoRunning.value) {
    stopDemo()
  } else {
    startDemo()
  }
}

function startDemo() {
  isDemoRunning.value = true
  emit('demo', true)
}

function stopDemo() {
  isDemoRunning.value = false
  if (demoInterval) {
    clearInterval(demoInterval)
    demoInterval = null
  }
  emit('demo', false)
}

function handleReset() {
  stopDemo()
  emit('reset')
}

// 暴露方法供父组件控制演示
defineExpose({
  startDemo,
  stopDemo,
  isDemoRunning
})

onUnmounted(() => {
  stopDemo()
})
</script>

<style scoped>
.top-nav {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 15px 30px;
  height: 80px;
}

.logo {
  font-size: 24px;
  font-weight: 600;
  color: #FFFFFF;
}

.nav-buttons {
  display: flex;
  gap: 16px;
}

.btn-demo {
  width: 120px;
  height: 40px;
  border: 2px solid #FFFFFF;
  background: transparent;
  color: #FFFFFF;
  border-radius: 8px;
  font-size: 16px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.3s ease;
}

.btn-demo:hover {
  background-color: rgba(255, 255, 255, 0.1);
}

.btn-demo.active {
  background-color: rgba(6, 182, 212, 0.2);
  border-color: #06B6D4;
}

.btn-reset {
  width: 100px;
  height: 40px;
  background-color: #6B7280;
  color: #FFFFFF;
  border: none;
  border-radius: 8px;
  font-size: 16px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.3s ease;
}

.btn-reset:hover {
  background-color: #4B5563;
}

@media (max-width: 768px) {
  .logo {
    font-size: 20px;
  }
  
  .nav-buttons {
    gap: 12px;
  }
  
  .btn-demo,
  .btn-reset {
    width: auto;
    padding: 0 16px;
    font-size: 14px;
  }
}

@media (prefers-reduced-motion: reduce) {
  .btn-demo,
  .btn-reset {
    transition: none !important;
  }
}
</style>
